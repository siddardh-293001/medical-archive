# The Medical Archive

Predicting 30-day hospital readmission among patients with diabetes: reproducible predictive research, explainability and subgroup fairness.

**Educational research only. Not validated for clinical use. No medical recommendations.**

## Setup

Use Python 3.10–3.12 (development uses 3.12):

```bash
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
make data
make all
make test
make dashboard
```

`python -m src.data_loader download` works in the activated environment. Add `--force` to replace an invalid cache. Both source CSVs may also be placed manually in `data/raw/`. The loader validates schema and computes a SHA-256 manifest. Raw files and model binaries are ignored by Git.

## Design

The encounter-level target is `readmitted == '<30'`; both `>30` and `NO` are negatives. Prediction time is discharge. Patients stay together across the holdout and all cross-validation folds. Thresholds and calibration are chosen using training OOF predictions; the configuration is frozen before test evaluation. There are no dates or hospital IDs, so neither temporal validation nor hospital clustering is possible.

The Medical Archive identity uses warm paper, serif type, compact tables and thin rules. Oxide means the positive outcome; forest means comparison. Charts add labels and line styles so color is never the only signal.

## Data and license

[UCI dataset 296](https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999+2008), CC BY 4.0. Dataset DOI: [10.24432/C5230J](https://doi.org/10.24432/C5230J). Source study: Strack et al. (2014), BioMed Research International, Article 781670, [doi:10.1155/2014/781670](https://doi.org/10.1155/2014/781670). Code is MIT licensed. See `data/README.md`.

## Repository

- `src/`: data, validation, transformations, modeling, evaluation and artifact generation.
- `dashboard/`: saved-artifact-only Streamlit publication.
- `reports/`: aggregate tables, figures, metrics and generated report.
- `docs/`: decisions, availability and dictionary.
- `tests/`: isolated synthetic fixtures and mocked offline tests; opt-in UCI integration test.
- `notebooks/`: thin narrative entry points, no unique modeling logic.

## Commands

`make data`, `quality`, `eda`, `train`, `evaluate`, `explain`, `fairness`, `dashboard`, `test`, `all` match the modules in the Makefile. Training overwrites model artifacts and invalidates downstream results; evaluation otherwise reuses the recorded test evaluation. Run `.venv/bin/python -m pytest -m network` to explicitly test the official network route.

## Metrics and interpretation

Average precision is `sklearn.metrics.average_precision_score`, not trapezoidal PR area; prevalence is its no-skill baseline. ROC-AUC measures ranking; recall measures detected positive encounters; precision measures the positive fraction among flags; specificity measures correctly unflagged negative encounters. Brier score measures squared probability error (lower is better). Thresholds describe hypothetical trade-offs and are not clinically optimal.

Explainability describes model associations and behavior, not causes. Patient-cluster bootstrap intervals account for repeated encounters. Fairness tables require sample sizes and positive counts: demographic parity, equalized odds and calibration represent different criteria and generally conflict when prevalence differs. Historical coding, missingness, coarse race categories and access-related proxies limit interpretation. No fairness result establishes deployment safety.

Only load trusted joblib artifacts: hash verification detects changes but cannot make an untrusted pickle safe. Do not upload real patient information or publish patient-level rows. Future work requires external, current, prospective validation and stakeholder evaluation before any clinical use.

Build status and exact verification evidence: `STATUS.md`. Results are added below only after execution.

<!-- GENERATED RESULTS -->
## Executed results
Generated from `reports/metrics/test.json`; patient-disjoint holdout n=19,718, prevalence 0.111.

| Metric | Frozen holdout estimate and patient-cluster interval |
|---|---|
| ROC-AUC | 0.679 (95% cluster interval 0.664–0.694) |
| Average precision | 0.235 (95% cluster interval 0.214–0.257) |
| Recall | 0.474 (95% cluster interval 0.451–0.504) |
| Precision | 0.209 (95% cluster interval 0.195–0.226) |
| Brier | 0.093 (95% cluster interval 0.090–0.097) |

Selected model: `hist_gradient_boosting`; calibration: `sigmoid`; frozen training threshold: 0.137823. False positives: 3,921; false negatives: 1,150. These research results do not establish clinical utility or deployment safety.

Read [the technical report](reports/final_report.md), [the themed HTML report](reports/final_report.html), [EDA](reports/eda_report.md), [fairness](reports/fairness_report.md), and [decisions](docs/DECISIONS.md). The dashboard is at [localhost:8501](http://127.0.0.1:8501) while `make dashboard` runs.

## Notebook order
After `make all`, read `01_understanding`, `02_exploration`, `03_preprocessing`, `04_validation`, `05_modeling`, `06_evaluation`, `07_explainability_fairness`. They call `src.notebook_support` and display saved aggregates; none contains unique modeling logic. Install `requirements-dev.txt` to run `pytest --nbmake notebooks -o addopts=''`.

## Reproducibility notes
Use `requirements-lock.txt` for the exact tested environment; `requirements.txt` gives compatible ranges. A first full run takes longer than opening the artifact-only dashboard. `make train` includes nested calibration and pre-test freezing. Repeated `make evaluate` reuses the saved result; explicitly retrain to begin a new experiment. Clean-copy verification evidence and any unverified scope are in `STATUS.md`.
