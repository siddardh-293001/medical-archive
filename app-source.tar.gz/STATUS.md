# Build and verification log
The user specification governs stage ordering. Results are generated only by executed code.

## Stage 1 — PASS — 2026-10-24T19:42:51.807754+00:00
make data validated existing manual CSVs and wrote the manifest. Seven offline loader/schema tests passed; one network test skipped by default. Original nested files preserved. Dependency installation succeeded in Python 3.12. Direct real download integration remains to be verified separately.

## Stage 2 — PASS — 2026-10-24T19:42:53.515539+00:00
Generated data-quality, missingness, cardinality, invalid-value and encounter-distribution tables. Exclusion accounting reconciles exactly. Feature availability documented per source column.

Stage 3 gate initially failed: SciPy 1.15.3 macOS native PROPACK library failed to load. No EDA results claimed. Repair: pin SciPy 1.14.x and NumPy below 2.3, then rerun.

## Stage 3 — PASS — 2026-10-24T19:45:28.133096+00:00
Generated aggregate-only EDA tables, Wilson intervals, chi-square/Cramér V, Mann–Whitney/rank-biserial, BH corrections, interpreted report and themed figures. EDA intervals are explicitly descriptive and do not adjust for patient clustering.

## Stage 4 — PASS — 2026-10-24T19:46:04.390827+00:00
Six preprocessing/theme tests passed: target/ID exclusion, mapping-based exclusions, diagnosis groups, deterministic patient separation, unseen category handling, fit-on-train-only imputer stability, probability bounds, shape, palette and contrast/CVD transforms. Features and availability documented. Scaling restricted to logistic regression; skew retained to avoid unsupported distribution assumptions.

## Additional Stage 1 verification — 2026-10-24T19:47:14.998026+00:00
Real UCI network integration passed (1 test, temporary directory). git check-ignore verified raw CSVs, private processed arrays and joblib files are ignored; MANIFEST.json is not ignored.

## Accessibility evidence — 2026-10-24T19:47:20.909125+00:00
Generated full-severity deuteranopia and protanopia simulations of the target figure. Contrast tests pass for body text colors; source bars include categorical labels and comparison hatching. Simulations need visual inspection; no automated readability claim.

## Stage 3 — PASS — 2026-10-24T19:49:06.615331+00:00
Generated aggregate-only EDA tables, Wilson intervals, chi-square/Cramér V, Mann–Whitney/rank-biserial, BH corrections, interpreted report and themed figures. EDA intervals are explicitly descriptive and do not adjust for patient clustering.

## Stage 5 — PASS — 2026-10-24T19:52:12.875747+00:00
All required models, balanced logistic and payer/specialty-drop comparison completed on grouped training OOF predictions. Selected hist_gradient_boosting. Search spaces, parameters, train/validation gaps and times saved. Test outcomes not evaluated. Hyperparameter-selection optimism is documented.

## Stage 6 — PASS — 2026-10-24T19:57:45.891954+00:00
Nested grouped calibration comparison completed; selected sigmoid. Training-only threshold alternatives and cost table saved. Primary and all sensitivity models frozen with hashes and timestamp BEFORE the first test evaluation. No test outcomes were evaluated.

## Stage 6 persistence repair — PASS — 2026-10-24T19:58:36.393997+00:00
CLI __main__ serialization bug caught on load before any test prediction. Corrected module entrypoint and repersisted identical fitted objects with importable class references; hashes and timestamp refrozen. No refitting or test-outcome selection occurred.

## Stage 7 — PASS — 2026-10-24T19:58:51.455565+00:00
Frozen timestamp verified before evaluation. Primary and pre-frozen sensitivities evaluated once; default/frozen metrics, patient-cluster CIs, curves and aggregate tables saved. Private prediction arrays are ignored by Git. AP, recall/precision burden and calibration are emphasized; no clinical utility claim.

## Stage 8 — PASS — 2026-10-24T19:59:54.391678+00:00
Original-column permutation importance, penalized logistic odds ratios, sampled tree SHAP, three anonymous contribution-only examples and PDP/ICE generated from saved models. No raw feature rows or identifiers exported. Penalized coefficient confidence intervals not estimated; limits stated in artifact.

## Stage 9 — PASS — 2026-10-24T20:00:55.456865+00:00
Fairlearn MetricFrame subgroup metrics and patient-cluster intervals generated for age, gender and race (Unknown separate), for primary and without-demographics models. Small-group flags, calibration curves and trade-off discussion saved. No safety or fairness certification claimed.

## Stage 10 — programmatic gates PASS — 2026-10-24T20:02:34.651498+00:00
All six real-artifact pages and all six artifact-absent pages passed Streamlit AppTest with no exceptions. Inference tests passed for hash checks, types, ranges, missing/extra fields, categories and frozen-threshold output. Browser/server verification follows; local socket launch requires sandbox escalation.

## Inference schema refinement — 2026-10-24T20:03:21.356242+00:00
Administrative-code validation now rejects codes absent from training, in addition to numeric range checks. Schema derived only from the saved training partition. Immutable frozen_config.json and all model/evaluation choices are unchanged.

## Stage 10 — PASS — 2026-10-24T20:04:27.066664+00:00
Streamlit server launched and browser overview inspected. Native page navigation and 0.50/frozen threshold toggle verified against saved values. All six pages tested with real artifacts and absent artifact roots. Overview screenshot saved. No raw loader, training or unpickling runs in dashboard.

## Stage 11 — PASS — 2026-10-24T20:04:53.155385+00:00
make test passed Ruff and 53 offline tests; 1 network test deselected by default (previously run and passed separately). CI configured for offline lint/tests and optional manual full-pipeline/notebook execution. No line-coverage percentage measured or claimed. Tests use synthetic records, mocked HTTP and saved-aggregate UI integration checks, never raw patient data.

## Stage 12 — publication generated — 2026-10-24T20:06:39.078336+00:00
README results and technical Markdown/HTML reports generated from saved artifacts. Source references verified. Full clean-source/new-environment walkthrough follows; no completed clean-clone claim yet.

## Notebook verification — PASS with limits — 2026-10-25T00:15:23.973746+00:00
Fixed a CSV suffix parser error exposed by cell execution. All seven notebooks then executed in order as Python cells against real saved aggregates. Full Jupyter/nbmake execution remains unverified: optional dependency installation was not executed because automatic approval review was unavailable due to account usage limits. No unsafe-action determination was made.

## Full notebook-kernel verification — PASS — 2026-10-25T00:17:12.062987+00:00
After the account reset, automatic approval review succeeded for the optional development dependencies and local Jupyter sockets. All seven notebooks passed pytest --nbmake in real kernels (11.01s). This resolves the earlier notebook-kernel verification limitation. Core lock remains separate from the optional requirements-dev-lock.txt.

## Stage 12 — publication generated — 2026-10-25T00:21:39.419364+00:00
README results and technical Markdown/HTML reports generated from saved artifacts. Source references verified. Full clean-source/new-environment walkthrough follows; no completed clean-clone claim yet.

## Fallback integration correction in progress — 2026-10-25T00:23:05.741052+00:00
Real ucimlrepo fallback test retrieved API data but legacy ZIP did not match the primary archive member-name assumptions. No fallback success claimed. Inspecting official legacy member names before fixing; primary download remains verified.

## Real fallback integration — PASS — 2026-10-25T00:24:56.668360+00:00
ucimlrepo data recombination, official legacy mapping acquisition, explicit legacy IDs_mapping.csv case normalization, per-encounter lab None restoration and manifest validation passed on real data in a temporary directory.

## Stage 2 — PASS — 2026-10-25T00:26:57.723533+00:00
Generated data-quality, missingness, cardinality, invalid-value and encounter-distribution tables. Exclusion accounting reconciles exactly. Feature availability documented per source column.

## Stage 12 — clean-source checks PASS — 2026-10-25T00:27:26.995670+00:00
Fresh Python 3.12 virtual environment installed exact locked dependencies from previously downloaded official wheel cache; make data (manual official CSV placement), make all and make test passed in a source-only temporary copy. No actual Git clone: this local repository has no commits/remote. Real automatic UCI download was verified separately. Clean-copy browser launch not repeated; original app server/browser and all AppTest pages were verified. Full Jupyter kernel execution remains unverified for the recorded approval-review availability issue.

## Reproducibility comparison — PASS — 2026-10-25T00:27:48.203468+00:00
Clean-environment primary holdout AUC, AP, precision, recall, F1, specificity, Brier and frozen threshold match the original run within rtol=1e-8, atol=1e-10. Full real Jupyter execution passed for all seven notebooks, resolving the earlier optional-tool review issue. Clean offline suite passed all 58 tests; real download and real ucimlrepo/legacy mapping fallback were verified separately.

## Stage 12 — publication generated — 2026-10-25T00:27:48.816704+00:00
README results and technical Markdown/HTML reports generated from saved artifacts. Source references verified. Full clean-source/new-environment walkthrough follows; no completed clean-clone claim yet.

## Clean environment server — PASS — 2026-10-25T00:27:52.074030+00:00
streamlit run dashboard/app.py started successfully in the fresh environment; health endpoint and app HTML returned HTTP 200. Temporary verification server stopped. The original dashboard remains available at localhost:8501. All six clean-environment page renders passed AppTest in make test.

## Stage 12 — PASS / final verification — 2026-10-25T00:28:45.126486+00:00
Full clean-source/new-venv pipeline, all 58 offline tests, seven real-kernel notebooks, primary official download, real ucimlrepo/legacy mapping fallback, six real-artifact pages, six missing-artifact pages and fresh-environment Streamlit startup/health were verified. Clean holdout metrics match the original exactly for the eight compared metrics. No actual remote Git clone or GitHub Actions run was performed because the new local repository has no remote/commits; the local equivalent checks passed. Reports are Markdown and themed HTML; exported PDF pagination was not verified. No clinical deployment, real patient upload or causal/fairness certification is claimed. Earlier optional notebook approval-review limitation is resolved.

## Render deployment preparation — 2026-10-25T01:01:07.504132+00:00
User requested deployment, then selected Render. Render account connection works and exposes My Workspace. Prepared Dockerfile, strict .dockerignore, lean dashboard runtime requirements and render.yaml; current Render JSON Schema validation passed and 14 dashboard/privacy checks passed. No Git remote, Docker CLI or Render CLI is configured locally. Awaiting source-repository choice and workspace confirmation before service creation. No hosted deployment claimed.
