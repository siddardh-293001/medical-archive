# Medical Archive dashboard
Run `make dashboard` or `.venv/bin/streamlit run dashboard/app.py` from the repository root.
Six native Streamlit pages read saved aggregate tables, metrics and figures; no raw-data loader, training code or model unpickling runs in the dashboard. There is no patient upload or what-if entry form.

Run `make all` to regenerate artifacts. Restart Streamlit or clear its data cache after artifact regeneration. Missing artifacts yield actionable messages. System serif and monospace fonts work offline; no remote fonts are fetched. Metric definitions, sample sizes, pointwise intervals and small-group flags appear next to results.
