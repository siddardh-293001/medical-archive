from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import streamlit as st
from dashboard.views import setup, overview


def overview_page():
    setup("Overview")
    overview()


navigation = st.navigation(
    [
        st.Page(overview_page, title="Overview", default=True),
        st.Page("pages/01_Exploratory_Analysis.py", title="Exploratory Analysis"),
        st.Page("pages/02_Model_Performance.py", title="Model Performance"),
        st.Page("pages/03_Explainability.py", title="Explainability"),
        st.Page("pages/04_Fairness.py", title="Fairness"),
        st.Page("pages/05_Limitations.py", title="Limitations"),
    ]
)
navigation.run()
