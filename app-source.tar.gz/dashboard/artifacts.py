"""No raw-data, training or acquisition imports are permitted here."""

import json
from pathlib import Path
import pandas as pd
from src.config import ROOT

ARTIFACT_ROOT = ROOT


def read_json(relative, root=None):
    path = Path(root or ARTIFACT_ROOT) / relative
    return json.loads(path.read_text()) if path.exists() else None


def read_table(relative, root=None):
    path = Path(root or ARTIFACT_ROOT) / relative
    return pd.read_csv(path) if path.exists() else None


def figure_path(name, root=None):
    path = Path(root or ARTIFACT_ROOT) / "reports/figures" / name
    return path if path.exists() else None
