import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from dashboard import artifacts
from src.theme import streamlit_css, register_plotly, OXIDE, FOREST


@st.cache_data(show_spinner=False)
def json_artifact(path):
    return artifacts.read_json(path)


@st.cache_data(show_spinner=False)
def table_artifact(path):
    return artifacts.read_table(path)


def setup(title):
    st.set_page_config(page_title=f"{title} · Medical Archive", layout="wide", initial_sidebar_state="auto")
    st.markdown(streamlit_css(), unsafe_allow_html=True)
    register_plotly()
    with st.sidebar:
        st.markdown('<div class="archive-label">A clinical research publication</div>', unsafe_allow_html=True)
        st.markdown("## The Medical Archive")
        st.markdown("Diabetes & hospital readmission")
        st.divider()
        st.caption("UCI 296 · 1999–2008")
        st.markdown("**Research edition**")
        st.caption("Saved results only. No patient uploads, retraining or raw-data access.")
        st.divider()
        st.markdown("Educational research. **Not for clinical use.**")
        st.link_button(
            "Dataset & provenance",
            "https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999+2008",
        )


def heading(label, title, description):
    st.markdown(f'<div class="archive-label">{label}</div>', unsafe_allow_html=True)
    st.title(title)
    st.markdown(description)
    st.divider()


def absent(value, command="make train"):
    if value is None:
        st.info(f"No saved artifact is available yet. Run `{command}` first.")
        return True
    return False


def picture(name, caption):
    path = artifacts.figure_path(name)
    if path:
        st.image(str(path), caption=caption, width="stretch")
    else:
        st.info("Figure unavailable. Run `make all` to generate the publication artifacts.")


def archive_table(data, **kwargs):
    config = {}
    for name in data.select_dtypes(include="number"):
        if data[name].dtype.kind in "iu" or name in {"n", "positive", "positive_count"}:
            config[name] = st.column_config.NumberColumn(format="%d")
        else:
            config[name] = st.column_config.NumberColumn(format="%.4f")
    st.dataframe(data, column_config=config, **kwargs)


def ledger(items):
    for column, (label, value, definition) in zip(st.columns(len(items)), items):
        column.metric(label, value, help=definition)


def overview():
    heading(
        "Research dossier / 01",
        "The Medical Archive.",
        "**Predicting 30-day hospital readmission among patients with diabetes.** A study of predictive signal, probability reliability, explanations and subgroup differences.",
    )
    quality = json_artifact("reports/tables/data_quality.json")
    result = json_artifact("reports/metrics/test.json")
    if absent(quality, "make quality"):
        return
    m = result["primary"]["frozen"] if result else {}
    ledger(
        [
            (
                "Encounters",
                f"{quality['modeling_rows']:,}",
                "Discharges after mapping-verified death/hospice exclusions.",
            ),
            ("Unique patients", f"{quality['modeling_patients']:,}", "Patients in the eligible encounter cohort."),
            (
                "Avg. precision",
                f"{m['average_precision']:.3f}" if m else "Pending",
                "Holdout average precision; compare with prevalence, not accuracy.",
            ),
            (
                "ROC–AUC",
                f"{m['roc_auc']:.3f}" if m else "Pending",
                "Holdout ranking discrimination. This does not establish clinical utility.",
            ),
        ]
    )
    st.divider()
    left, right = st.columns([1.05, 1], gap="large")
    with left:
        st.markdown('<div class="archive-label">The research question</div>', unsafe_allow_html=True)
        st.subheader("What can an encounter tell us at discharge?")
        st.write(
            "We examine whether routinely recorded encounter information identifies a higher likelihood of readmission within 30 days—and whether those probabilities are reliable across groups."
        )
        st.write(
            "Patients remain together across validation folds. Calibration and the decision threshold are selected using training data, then frozen before the holdout is evaluated."
        )
        st.markdown(
            '<div class="archive-note">Predictive association is not causation. This historical dataset cannot establish that changing a feature would change readmission.</div>',
            unsafe_allow_html=True,
        )
        if result:
            st.caption(
                f"Heldout encounters n={m['n']:,}; prevalence {m['prevalence']:.1%}. Frozen threshold {result['threshold']:.3f}. Dates are unavailable; this is not temporal validation."
            )
    with right:
        st.markdown('<div class="archive-label">Cohort ledger</div>', unsafe_allow_html=True)
        counts = table_artifact("reports/tables/target_distribution.csv")
        if counts is not None:
            fig = go.Figure()
            for i, row in counts.iterrows():
                name = str(row.iloc[0])
                positive = name == "<30"
                fig.add_trace(
                    go.Bar(
                        x=[name],
                        y=[row["n"]],
                        name="<30 days" if positive else f"Comparison: {name}",
                        marker_color=OXIDE if positive else FOREST,
                        marker_pattern_shape="" if positive else "/",
                        text=[f"n={int(row['n']):,}"],
                        textposition="outside",
                    )
                )
            fig.update_layout(
                title="Recorded outcomes · eligible cohort",
                xaxis_title="Readmission category",
                yaxis_title="Encounters (n)",
                showlegend=False,
                height=330,
            )
            st.plotly_chart(fig, width="stretch")
        st.caption("Fig. 1. >30-day readmissions are negative outcomes for this 30-day prediction task.")
    st.divider()
    st.subheader("A study in six chapters")
    cols = st.columns(3)
    for col, title, text in zip(
        cols,
        ["01 / Understand the cohort", "02 / Measure the signal", "03 / Inspect the limits"],
        [
            "Explore aggregate rates, missingness and utilization. Every displayed number comes from a saved computation.",
            "Compare baselines, discrimination, precision–recall trade-offs and probability calibration.",
            "Read model explanations, subgroup uncertainty and the limits of retrospective prediction.",
        ],
    ):
        col.markdown(f"**{title}**")
        col.write(text)
    st.caption(
        "Source: UCI Diabetes 130-US Hospitals, CC BY 4.0. Original study: Strack et al., 2014. No patient-level rows are displayed."
    )


def exploratory():
    heading(
        "Cohort / 02",
        "Patterns in the record.",
        "Aggregate descriptions of eligible encounters. Group rates are associations; case mix, access, coding and repeated encounters may influence them.",
    )
    table = table_artifact("reports/tables/eda_groups.csv")
    if absent(table, "make eda"):
        return
    a, b = st.columns([2, 1])
    feature = a.selectbox(
        "Explore a recorded attribute", table.feature.unique(), format_func=lambda s: s.replace("_", " ").title()
    )
    minimum = b.number_input("Minimum group encounters", min_value=0, value=0, step=100)
    sub = table[(table.feature == feature) & (table.n >= minimum)].copy()
    if sub.empty:
        st.info("No groups match this sample-size filter.")
    else:
        sub["label"] = sub.apply(lambda r: f"{r['group']} · n={int(r.n):,}", axis=1)
        fig = go.Figure(
            go.Scatter(
                x=sub.rate,
                y=sub.label,
                mode="markers",
                marker=dict(color=OXIDE, size=9),
                error_x=dict(
                    type="data", array=sub.ci_high - sub.rate, arrayminus=(sub.rate - sub.ci_low).clip(lower=0)
                ),
                hovertemplate="%{y}<br>Readmission rate %{x:.1%}<extra></extra>",
            )
        )
        fig.update_layout(
            title=f"30-day readmission by {feature.replace('_', ' ')}",
            xaxis_title="Readmission rate · descriptive Wilson 95% interval",
            yaxis_title="Group and sample size",
            height=max(330, len(sub) * 37),
        )
        fig.update_xaxes(tickformat=".0%")
        st.plotly_chart(fig, width="stretch")
        archive_table(sub[["group", "n", "positive", "rate", "ci_low", "ci_high"]], hide_index=True, width="stretch")
    st.caption(
        "Wilson intervals here are descriptive and treat encounters as independent. Model uncertainty uses patient-level cluster bootstrap."
    )
    with st.expander("Utilization and missingness"):
        picture(
            "eda_utilization.png",
            "Fig. 2. Prior-year visit counts remain unchanged; no current encounter is subtracted.",
        )
        picture(
            "eda_missingness.png",
            "Fig. 3. Missingness uses ? markers. Literal None in laboratory fields means not tested.",
        )
    with st.expander("Exploratory statistics and assumptions"):
        stats = table_artifact("reports/tables/eda_statistics.csv")
        if stats is not None:
            archive_table(stats, hide_index=True, width="stretch")
        st.write(
            "Chi-square/Cramér's V and Mann–Whitney/rank-biserial effects are exploratory. BH correction covers the declared family of tests. Repeated encounters weaken independence assumptions; significance alone does not determine importance."
        )


def performance():
    heading(
        "Validation / 03",
        "How much signal holds up?",
        "Patient-disjoint evaluation of a frozen model. Average precision, false-positive burden and probability reliability matter alongside discrimination.",
    )
    result = json_artifact("reports/metrics/test.json")
    if absent(result, "make evaluate"):
        return
    choice = st.radio("Reported decision rule", ["Frozen training threshold", "Default 0.50"], horizontal=True)
    key = "frozen" if choice.startswith("Frozen") else "default"
    m = result["primary"][key]
    ci = result["primary"]["uncertainty_" + key]
    ledger(
        [
            (
                label,
                f"{m[k]:.3f}",
                f"95% patient-cluster interval {ci['intervals'][k]['low']:.3f}–{ci['intervals'][k]['high']:.3f}",
            )
            for label, k in [
                ("Avg. precision", "average_precision"),
                ("ROC–AUC", "roc_auc"),
                ("Recall", "recall"),
                ("Precision", "precision"),
            ]
        ]
    )
    st.caption(
        f"n={m['n']:,} encounters; {result['test_patients']:,} patients; prevalence {m['prevalence']:.1%}; threshold {m['threshold']:.3f}; Brier {m['brier']:.4f}. Bootstrap replicates: {ci['valid_replicates']}/{ci['requested_replicates']}."
    )
    st.markdown(
        f'<div class="archive-note">At this rule, {m["confusion_matrix"][1][0]:,} positive encounters were missed and {m["confusion_matrix"][0][1]:,} comparison encounters were flagged. This is a hypothetical research trade-off, not an approved clinical threshold.</div>',
        unsafe_allow_html=True,
    )
    picture(
        "test_curves.png", "Fig. 4. ROC, precision–recall with prevalence baseline, and calibration on the holdout."
    )
    with st.expander("Confusion matrices and threshold trade-offs"):
        picture("test_confusion.png", "Fig. 5. Counts at both prespecified rules.")
        picture("test_thresholds.png", "Fig. 6. Descriptive holdout trade-offs; the threshold was not retuned.")
    st.subheader("Training comparison")
    comparison = table_artifact("reports/model_comparison.csv")
    if comparison is not None:
        archive_table(
            comparison[["model", "average_precision", "brier", "fold_ap_sd", "mean_train_ap", "total_seconds"]],
            hide_index=True,
            width="stretch",
        )
    st.caption(
        "Hyperparameter search and OOF comparison share training folds; model selection estimates are optimistic. The heldout results above are the final estimate."
    )
    with st.expander("Prespecified sensitivities"):
        table = table_artifact("reports/tables/test_metrics.csv")
        if table is not None:
            archive_table(table, hide_index=True, width="stretch")
        st.write(
            "First encounter uses supplied file order, not verified chronology. Feature-removal models retain primary hyperparameters and threshold, and fit calibration on their own training OOF predictions."
        )
    with st.expander("Calibration and hypothetical cost ratios"):
        cal = json_artifact("reports/metrics/calibration.json")
        if cal:
            st.write(f"Chosen calibration: {cal['chosen_method']}. Comparison uses nested grouped training CV.")
            archive_table(pd.DataFrame(cal["methods"]).T.drop(columns="confusion_matrix"), width="stretch")
        costs = table_artifact("reports/tables/cost_sensitivity.csv")
        if costs is not None:
            archive_table(costs, hide_index=True, width="stretch")


def explainability():
    heading(
        "Interpretation / 04",
        "What the model attends to.",
        "Explanations describe associations and model behavior. Correlated inputs can share or obscure importance; these are not causal effects.",
    )
    result = json_artifact("reports/metrics/explanations.json")
    if absent(result, "make explain"):
        return
    st.caption(
        f"Permutation sample n={result['permutation_sample_n']:,}; SHAP sample n={result['shap_sample_n']:,}. Sampling seed {result['seed']}."
    )
    picture(
        "permutation_importance.png",
        "Fig. 7. Permuting original columns includes all their derived and one-hot representations. Bars show repeat SD, not confidence intervals.",
    )
    tabs = st.tabs(["Tree SHAP", "Logistic associations", "Feature effects", "Anonymous examples"])
    with tabs[0]:
        picture("shap_importance.png", "Fig. 8. Sampled uncalibrated tree contributions on the log-odds scale.")
        st.write(result["shap_scale"])
    with tabs[1]:
        picture("logistic_coefficients.png", "Fig. 9. Penalized coefficients; numeric predictors are standardized.")
        st.write(result["coefficient_uncertainty"])
    with tabs[2]:
        picture(
            "feature_effects.png",
            "Fig. 10. Partial dependence and ICE describe fitted behavior; changing an input is not an intervention.",
        )
    with tabs[3]:
        for row in result["local_examples"]:
            st.markdown(
                f"**Example {row['example']}** · predicted probability {row['primary_probability']:.1%} · frozen threshold {row['threshold']:.3f}"
            )
            archive_table(
                pd.DataFrame(row["top_contributions_logodds"].items(), columns=["Encoded feature", "SHAP log-odds"]),
                hide_index=True,
                width="stretch",
            )
        st.caption(
            "Only anonymous contribution summaries are shown. SHAP explains the uncalibrated tree; its additive scale does not directly explain the calibration mapping."
        )
    st.write(result["limitations"])


def fairness():
    heading(
        "Subgroups / 05",
        "Reliability is not uniform.",
        "Inspect sample size, prevalence, errors and probability reliability together. No single metric establishes fairness or deployment safety.",
    )
    table = table_artifact("reports/tables/subgroup_metrics.csv")
    info = json_artifact("reports/metrics/fairness.json")
    if absent(info, "make fairness") or absent(table, "make fairness"):
        return
    a, b = st.columns(2)
    feature = a.selectbox("Grouping", ["race", "gender", "age"])
    analysis = b.selectbox(
        "Frozen model", ["primary", "without_demographics"], format_func=lambda x: x.replace("_", " ").title()
    )
    sub = table[(table.feature == feature) & (table.analysis == analysis)]
    archive_table(
        sub[
            [
                "group",
                "n",
                "positive_count",
                "prevalence",
                "selection_rate",
                "recall",
                "fpr",
                "fnr",
                "precision",
                "specificity",
                "roc_auc",
                "calibration_in_large",
                "small_group",
            ]
        ],
        hide_index=True,
        width="stretch",
    )
    if info:
        st.caption(
            f"Flagged below n={info['minimum_encounters']} or {info['minimum_positives']} positive encounters. Blanks denote undefined values. Precision/recall use zero_division=0; interpret flagged groups cautiously."
        )
    st.caption(
        "Calibration-in-the-large = mean predicted probability minus observed prevalence; positive values indicate overprediction."
    )
    metric = st.selectbox("Inspect uncertainty", ["recall", "fpr", "precision", "roc_auc", "calibration_in_large"])
    valid = sub.dropna(subset=[metric, metric + "_low", metric + "_high"])
    labels = [
        f"{r.group}{' *' if r.small_group else ''} · n={int(r.n):,}; +={int(r.positive_count):,}"
        for r in valid.itertuples()
    ]
    fig = go.Figure(
        go.Scatter(
            x=valid[metric],
            y=labels,
            mode="markers",
            marker=dict(color=OXIDE, size=9),
            error_x=dict(
                type="data",
                array=(valid[metric + "_high"] - valid[metric]).clip(lower=0),
                arrayminus=(valid[metric] - valid[metric + "_low"]).clip(lower=0),
            ),
        )
    )
    fig.update_layout(
        title=f"{metric.replace('_', ' ').title()} · pointwise patient-cluster intervals",
        xaxis_title=metric.replace("_", " "),
        yaxis_title="Group (* insufficient sample)",
        height=max(330, len(valid) * 40),
    )
    st.plotly_chart(fig, width="stretch")
    with st.expander("Group calibration curves"):
        curves = table_artifact("reports/tables/subgroup_calibration.csv")
        if curves is not None:
            curves = curves[(curves.feature == feature) & (curves.analysis == analysis)]
            groups = curves.group.unique().tolist()
            if groups:
                chosen = st.selectbox("Adequately sized group", groups)
                curve = curves[curves.group == chosen]
                fig = go.Figure(
                    go.Scatter(
                        x=curve.mean_predicted,
                        y=curve.observed,
                        mode="lines+markers",
                        line_color=OXIDE,
                        name=f"{chosen} · n={int(curve.n.iloc[0]):,}",
                    )
                )
                fig.add_trace(
                    go.Scatter(x=[0, 1], y=[0, 1], line=dict(color=FOREST, dash="dash"), name="Perfect calibration")
                )
                fig.update_layout(
                    title="Subgroup probability reliability",
                    xaxis_title="Mean predicted probability",
                    yaxis_title="Observed readmission fraction",
                    height=350,
                )
                st.plotly_chart(fig, width="stretch")
    if info:
        st.write(info["discussion"])


def limitations():
    heading(
        "Scope / 06",
        "The limits of the archive.",
        "A retrospective research study can reveal predictive patterns. It cannot validate a clinical decision system.",
    )
    for title, text in [
        (
            "Historical records, limited transportability",
            "The source spans 1999–2008. Treatments, admission practices, access and coding have changed. Current external and prospective validation are absent.",
        ),
        (
            "No temporal or hospital validation",
            "Admission dates and hospital identifiers are unavailable. Patient grouping prevents patient overlap but cannot address hospital clustering or calendar drift.",
        ),
        (
            "Measurement and selection",
            "Diagnoses may be finalized after discharge. Missingness, recorded test ordering, coarse demographic categories and administrative processes may encode bias. Death/hospice exclusions alter the study population.",
        ),
        (
            "Prediction is not intervention",
            "Feature importance, SHAP and partial dependence are model descriptions. Correlation, case mix and proxies prevent causal interpretation. No medical recommendation follows from a model score.",
        ),
        (
            "Thresholds and subgroup trade-offs",
            "Costs are hypothetical, thresholds are selected on training data and imperfect calibration can persist. Demographic parity, equalized odds and calibration generally conflict when prevalence differs. Small groups and pointwise intervals limit conclusions.",
        ),
        (
            "Research and privacy boundary",
            "No real patient uploads are supported. The dashboard reads saved aggregate artifacts only. Anonymous explanation summaries contain no raw identifiers or full feature rows. Load only trusted model artifacts; a hash does not make an untrusted pickle safe.",
        ),
    ]:
        st.subheader(title)
        st.write(text)
        st.divider()
    st.markdown(
        '<div class="archive-note">Educational research only. This analysis does not show the model is safe or appropriate for clinical deployment.</div>',
        unsafe_allow_html=True,
    )
