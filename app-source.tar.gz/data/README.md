# Dataset provenance
UCI Diabetes 130-US Hospitals for Years 1999–2008, dataset 296.
License verified on UCI on 2026-10-25: **CC BY 4.0**; attribution required.
Source: https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999+2008
Dataset DOI: https://doi.org/10.24432/C5230J
Clore, Cios, DeShazo & Strack (2014). UCI Machine Learning Repository.
Study: Strack et al. (2014), BioMed Research International, Article 781670,
https://doi.org/10.1155/2014/781670 (citation verified against UCI).

Raw files are ignored. MANIFEST.json records locally calculated hashes and provenance.
Existing nested source files are preserved; working copies are validated at the raw root.
The ucimlrepo fallback obtains the original mapping from the verified official legacy ZIP,
https://archive.ics.uci.edu/ml/machine-learning-databases/00296/dataset_diabetes.zip.
The legacy member IDs_mapping.csv is normalized to the canonical IDS_mapping.csv filename.
Standalone mapping CSV endpoints return 404. The legacy CSV also checks per-encounter
restoration of literal None laboratory codes that ucimlrepo parses as missing. If the legacy ZIP is unavailable,
manual placement of both files is required. No mapping is guessed or reconstructed.
No patient-level data should be published; reports and dashboard contain aggregates only.
