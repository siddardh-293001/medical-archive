# Observed data dictionary

Generated from the validated source. Original definitions: UCI dataset 296. See FEATURE_AVAILABILITY.md and FEATURE_ENGINEERING.md for prediction-time use and derived features.

Literal None in laboratory fields means not tested. Prior visit counts describe the preceding year and are not adjusted. No patient-level rows are exported.

| Column | Observed dtype | Distinct values | Missing n | Missing rate |
|---|---|---:|---:|---:|
| encounter_id | int64 | 101,766 | 0 | 0.00% |
| patient_nbr | int64 | 71,518 | 0 | 0.00% |
| race | object | 5 | 2,273 | 2.23% |
| gender | object | 3 | 0 | 0.00% |
| age | object | 10 | 0 | 0.00% |
| weight | object | 9 | 98,569 | 96.86% |
| admission_type_id | int64 | 8 | 0 | 0.00% |
| discharge_disposition_id | int64 | 26 | 0 | 0.00% |
| admission_source_id | int64 | 17 | 0 | 0.00% |
| time_in_hospital | int64 | 14 | 0 | 0.00% |
| payer_code | object | 17 | 40,256 | 39.56% |
| medical_specialty | object | 72 | 49,949 | 49.08% |
| num_lab_procedures | int64 | 118 | 0 | 0.00% |
| num_procedures | int64 | 7 | 0 | 0.00% |
| num_medications | int64 | 75 | 0 | 0.00% |
| number_outpatient | int64 | 39 | 0 | 0.00% |
| number_emergency | int64 | 33 | 0 | 0.00% |
| number_inpatient | int64 | 21 | 0 | 0.00% |
| diag_1 | object | 716 | 21 | 0.02% |
| diag_2 | object | 748 | 358 | 0.35% |
| diag_3 | object | 789 | 1,423 | 1.40% |
| number_diagnoses | int64 | 16 | 0 | 0.00% |
| max_glu_serum | object | 4 | 0 | 0.00% |
| A1Cresult | object | 4 | 0 | 0.00% |
| metformin | object | 4 | 0 | 0.00% |
| repaglinide | object | 4 | 0 | 0.00% |
| nateglinide | object | 4 | 0 | 0.00% |
| chlorpropamide | object | 4 | 0 | 0.00% |
| glimepiride | object | 4 | 0 | 0.00% |
| acetohexamide | object | 2 | 0 | 0.00% |
| glipizide | object | 4 | 0 | 0.00% |
| glyburide | object | 4 | 0 | 0.00% |
| tolbutamide | object | 2 | 0 | 0.00% |
| pioglitazone | object | 4 | 0 | 0.00% |
| rosiglitazone | object | 4 | 0 | 0.00% |
| acarbose | object | 4 | 0 | 0.00% |
| miglitol | object | 4 | 0 | 0.00% |
| troglitazone | object | 2 | 0 | 0.00% |
| tolazamide | object | 3 | 0 | 0.00% |
| examide | object | 1 | 0 | 0.00% |
| citoglipton | object | 1 | 0 | 0.00% |
| insulin | object | 4 | 0 | 0.00% |
| glyburide-metformin | object | 4 | 0 | 0.00% |
| glipizide-metformin | object | 2 | 0 | 0.00% |
| glimepiride-pioglitazone | object | 2 | 0 | 0.00% |
| metformin-rosiglitazone | object | 2 | 0 | 0.00% |
| metformin-pioglitazone | object | 2 | 0 | 0.00% |
| change | object | 2 | 0 | 0.00% |
| diabetesMed | object | 2 | 0 | 0.00% |
| readmitted | object | 3 | 0 | 0.00% |
