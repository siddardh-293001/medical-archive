# Research decisions

- Prediction is at discharge; diagnoses may be finalized later, limiting prospective availability.
- Target is <30; >30 and NO are negatives. No causal or clinical utility claim is made.
- Preserve the existing nested raw files; validate working copies and manifest them as manual placement.
- Python 3.12 virtual environment; all seeds and experiment budgets live in config.yaml.
- Outer holdout is the first seeded StratifiedGroupKFold fold; inner CV is grouped as well.
- First encounter means the first record in supplied file order; dates are absent, so this is not a verified chronological first admission.
- Unknown/Invalid gender remains a separate category; no demographic rows are removed.
- Exclusions are determined by expired/hospice descriptions in the supplied mapping, not assumed numeric IDs.
- No resampling: compare balanced and unweighted logistic regression instead. Prior utilization counts remain unchanged.
- Near-constant removal is learned inside each training fold. Weight always drops; payer/specialty are compared as retained Unknown categories versus dropping both.
- Tune with a modest, fixed randomized budget; fit time and uncertainty are reported. No optimization toward a target score.
- Calibration uses nested group-aware training folds. Select calibration by OOF Brier score, then choose maximum-F1 threshold using training OOF only. Alternatives remain hypothetical.
- Select among models within 0.005 AP of the best by Brier score, favoring simple logistic regression on exact ties. This explicitly weighs calibration; stability and burden are reported for interpretation.
- Repeated test evaluation is guarded: evaluation reuses saved results after the first run; retraining explicitly invalidates downstream artifacts.
- Bootstrap resamples patients and includes all encounters. Invalid one-class replicates are skipped and counts are recorded.
- Fairness CIs are patient-cluster bootstrap, exploratory and pointwise, not simultaneous guarantees.
- No optional what-if UI: avoid encouraging patient data entry. Validated programmatic inference is provided for trusted local research.
- Environment repair: SciPy 1.15.3's macOS PROPACK extension failed to load. SciPy 1.14.1 with NumPy 2.2.6 imports successfully; the dependency ranges now retain that compatible family.
- Visual inspection of both protanopia and deuteranopia target-chart simulations confirmed the category labels and hatching remain distinguishable. This is a manual check, not an accessibility certification.

- Executed model selection: hist_gradient_boosting; see generated model_comparison.csv for AP, Brier, stability and burden. Numeric results are not hand-transcribed.
- Sigmoid calibration fits a logistic map of clipped log-odds of OOF probabilities, rather than assuming that every estimator exposes the same decision-function scale. Isotonic calibration is monotone and clips out-of-range scores. Calibration comparison is nested across patient groups.
- Hypothetical cost ratios are false-negative cost relative to false-positive cost; no clinical cost estimate is asserted. Recall-constrained selection may be infeasible, in which case the artifact explicitly records null.

- Frozen calibration: sigmoid; maximum-F1 training OOF threshold recorded in models/frozen_config.json. Sensitivities retain primary hyperparameters and threshold, with the selected calibration method refitted on each variant's training OOF predictions. Exact removed columns: reports/tables/feature_removal.json.

- Verified standalone UCI mapping CSV endpoints return 404. The ucimlrepo fallback now uses the official legacy dataset ZIP for mapping, with the same staged archive validation. Because ucimlrepo parses literal None lab codes as NaN, the fallback restores those codes only after per-encounter reconciliation with the official legacy CSV. No synthetic data or guessed mapping is used.
