# Render deployment

The dashboard runs as one Docker web service on Render's free compute plan.
`render.yaml` was validated against Render's current public JSON Schema.
The container binds to `0.0.0.0` and the supplied `PORT`; health checks use
`/_stcore/health`. No database, secret, disk, model retraining or raw-data download is needed.

`requirements-dashboard.txt` contains only the dashboard runtime dependencies.
The Docker build uses an explicit allowlist and excludes raw/processed encounter data,
joblib models, environment files and local verification logs. It includes saved aggregate
tables, metrics and figures. The dashboard remains educational research, not clinical software.

Current prerequisite: this new local repository has no Git remote. Render needs a
GitHub/GitLab/Bitbucket repository it can clone. After the source repository and Render
workspace are confirmed, push the source, create the service, monitor its build and verify
the public health endpoint and all six pages. No service has been created yet.

Local verification: 14 dashboard/privacy checks passed. Docker is not installed locally,
so an actual container build must be verified by the hosting build. No hosted deployment
or public URL is claimed at this stage.
