# Feature availability at discharge

Diagnosis coding may be finalized after discharge; availability is uncertain in live practice.

| Column | Available | Used | Reason |
|---|---|---|---|
| encounter_id | yes | no | Identifier/outcome excluded |
| patient_nbr | yes | no | Identifier/outcome excluded |
| race | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| gender | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| age | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| weight | yes | no | Overwhelming missingness |
| admission_type_id | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| discharge_disposition_id | yes | yes | Known at discharge; strong process-related feature; exclusion sensitivity run |
| admission_source_id | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| time_in_hospital | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| payer_code | yes | yes | Unknown versus dropping sensitivity comparison; payer may proxy access and demographics |
| medical_specialty | yes | yes | Unknown versus dropping sensitivity comparison; payer may proxy access and demographics |
| num_lab_procedures | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| num_procedures | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| num_medications | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| number_outpatient | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| number_emergency | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| number_inpatient | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| diag_1 | uncertain | yes | Research predictor; fold-specific near-constant filtering applies |
| diag_2 | uncertain | yes | Research predictor; fold-specific near-constant filtering applies |
| diag_3 | uncertain | yes | Research predictor; fold-specific near-constant filtering applies |
| number_diagnoses | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| max_glu_serum | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| A1Cresult | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| metformin | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| repaglinide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| nateglinide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| chlorpropamide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| glimepiride | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| acetohexamide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| glipizide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| glyburide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| tolbutamide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| pioglitazone | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| rosiglitazone | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| acarbose | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| miglitol | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| troglitazone | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| tolazamide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| examide | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| citoglipton | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| insulin | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| glyburide-metformin | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| glipizide-metformin | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| glimepiride-pioglitazone | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| metformin-rosiglitazone | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| metformin-pioglitazone | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| change | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| diabetesMed | yes | yes | Research predictor; fold-specific near-constant filtering applies |
| readmitted | no | no | Identifier/outcome excluded |
