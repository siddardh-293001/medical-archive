# Deterministic features and coding
All features describe information by discharge, with delayed diagnosis coding a caveat. Associations cannot identify causal effects.

| Feature | Definition / source | Rationale and limits |
|---|---|---|
| age_ordinal | Lower bracket bound divided by ten | Ordered decades; not exact age |
| total_prior_visits | outpatient + emergency + inpatient | Prior-year utilization; no subtraction |
| prior_inpatient_burden | number_inpatient > 0 | Any preceding inpatient use; loses intensity |
| prior_emergency_burden | number_emergency > 0 | Any preceding emergency use; access-related |
| stay_band | time_in_hospital: 1–3, 4–7, 8–14 days | Coarse encounter duration |
| medications_up/down | Counts of medication columns equal Up / Down | Recorded dose changes, not adherence |
| medication_change_count | Up + Down count | Treatment process association |
| A1C_tested | A1Cresult differs from literal None | Testing process; does not mean normal result |
| diagnosis groups | diag_1 / diag_2 / diag_3 separately | Broad ICD-9 groupings; code finalized after discharge possible |

ICD-9 grouping in `src.feature_engineering.diagnosis_group`: Diabetes 250.x; circulatory 390–459 or 785.x; respiratory 460–519 or 786.x; digestive 520–579 or 787.x; genitourinary 580–629 or 788.x; musculoskeletal 710–739; injury 800–999; neoplasms 140–239; V codes supplementary; E codes external; missing Unknown; remaining Other. This is a research grouping, not a diagnostic ontology.

Administrative code descriptions come from IDS_mapping.csv. NULL, Not Available, Not Mapped and Unknown/Invalid collapse to Unknown; remaining descriptions are preserved, with rare levels pooled by the fold-fitted one-hot encoder. No interactions are added without an empirical rationale. Weight drops unconditionally; near-constant features are selected within training folds. No target encoding.
