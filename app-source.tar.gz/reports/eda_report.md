# Exploratory analysis

Eligible discharge encounters only. Rates are associations, not causes. Intervals are encounter-level Wilson intervals for descriptive EDA; final model uncertainty uses patient clusters. Repeated encounters limit the independence assumptions of these exploratory tests.

- **age**: highest observed rate in [20-30), 14.3% (n=1,649, Wilson interval 12.7%–16.1%); Cramér's V=0.037. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **gender**: highest observed rate in Female, 11.5% (n=53,454, Wilson interval 11.2%–11.7%); Cramér's V=0.003. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **race**: highest observed rate in Caucasian, 11.5% (n=74,220, Wilson interval 11.3%–11.8%); Cramér's V=0.016. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **diag_1_group**: highest observed rate in Unknown, 25.0% (n=20, Wilson interval 11.2%–46.9%); Cramér's V=0.035. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **diag_2_group**: highest observed rate in Neoplasms, 16.2% (n=2,326, Wilson interval 14.8%–17.8%); Cramér's V=0.028. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **diag_3_group**: highest observed rate in Neoplasms, 15.5% (n=1,662, Wilson interval 13.8%–17.3%); Cramér's V=0.037. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **A1Cresult**: highest observed rate in None, 11.7% (n=82,509, Wilson interval 11.5%–11.9%); Cramér's V=0.021. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **max_glu_serum**: highest observed rate in >300, 15.1% (n=1,188, Wilson interval 13.1%–17.2%); Cramér's V=0.014. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **change**: highest observed rate in Ch, 12.0% (n=46,122, Wilson interval 11.7%–12.3%); Cramér's V=0.019. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **diabetesMed**: highest observed rate in Yes, 11.8% (n=76,719, Wilson interval 11.6%–12.1%); Cramér's V=0.026. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **admission_type_id**: highest observed rate in 1, 11.8% (n=52,371, Wilson interval 11.6%–12.1%); Cramér's V=0.018. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **discharge_disposition_id**: highest observed rate in 12, 66.7% (n=3, Wilson interval 20.8%–93.9%); Cramér's V=0.115. This descriptive comparison may reflect case mix, coding and repeated encounters.
- **time_in_hospital**: median 4 in positives versus 4 in comparisons; rank-biserial effect 0.095. Utilization and coding measures are candidate predictors, not intervention targets.
- **num_lab_procedures**: median 45 in positives versus 44 in comparisons; rank-biserial effect 0.044. Utilization and coding measures are candidate predictors, not intervention targets.
- **num_procedures**: median 1 in positives versus 1 in comparisons; rank-biserial effect -0.008. Utilization and coding measures are candidate predictors, not intervention targets.
- **num_medications**: median 16 in positives versus 15 in comparisons; rank-biserial effect 0.087. Utilization and coding measures are candidate predictors, not intervention targets.
- **number_outpatient**: median 0 in positives versus 0 in comparisons; rank-biserial effect 0.041. Utilization and coding measures are candidate predictors, not intervention targets.
- **number_emergency**: median 0 in positives versus 0 in comparisons; rank-biserial effect 0.064. Utilization and coding measures are candidate predictors, not intervention targets.
- **number_inpatient**: median 0 in positives versus 0 in comparisons; rank-biserial effect 0.215. Utilization and coding measures are candidate predictors, not intervention targets.
- **number_diagnoses**: median 9 in positives versus 8 in comparisons; rank-biserial effect 0.088. Utilization and coding measures are candidate predictors, not intervention targets.

Eligible prevalence is 11.39%; this is the PR baseline. Imbalance makes accuracy alone misleading.

Chi-square assumes independent observations and adequate expected counts; low expected cells are recorded. Mann–Whitney compares ranks and does not prove a median shift unless distribution shapes align. BH q-values correct this declared family of exploratory tests. Effect size, uncertainty and sampling structure matter more than significance at this sample size.

Missingness is summarized in data_quality.csv and by outcome in missingness_by_target.csv. Weight is dropped; payer and specialty retention are compared during modeling. Hypotheses: preceding utilization may add signal; administrative discharge information may contribute process-related signal; testing patterns may reflect measurement bias. These hypotheses require grouped validation.
