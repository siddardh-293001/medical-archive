# The Medical Archive
Predicting 30-Day Hospital Readmission Among Patients With Diabetes Using Machine Learning, Explainable AI, and Fairness Analysis
**Educational predictive research. Not a validated clinical decision-support system.**
Generated from saved artifacts at 2026-10-25T00:27:48.799386+00:00. The immutable experiment freeze is 2026-10-24T19:58:36.391812+00:00; test evaluation began 2026-10-24T19:58:38.440141+00:00. No metric was manually transcribed.
### Abstract
We studied discharge-time prediction of readmission within 30 days using the UCI historical diabetes encounter dataset. After mapping-verified death/hospice exclusions, the eligible cohort contained 99,343 encounters from 69,990 patients. A patient-disjoint holdout and grouped training validation compared simple utilization, logistic and tree-based models against a dummy baseline. The selected hist_gradient_boosting model used sigmoid calibration and a threshold selected from training OOF predictions. On 19,718 holdout encounters, ROC-AUC was 0.679 (95% cluster interval 0.664–0.694) and average precision 0.235 (95% cluster interval 0.214–0.257), with prevalence 0.111. At the frozen threshold, recall was 0.474, precision 0.209 and Brier score 0.0933. Explanations and subgroup analysis characterize associations and uncertainty; they do not establish causal effects, fairness, clinical utility or deployment safety.
### Introduction and research objectives
Hospital readmission is a meaningful retrospective outcome, but the information recorded during an encounter mixes disease burden, previous utilization, administrative practice and measurement processes. A predictive study must distinguish this information from knowledge available only after the outcome. The prediction setting here is discharge, not admission. The original dataset and Strack et al. study provide the source context [1,2]; their published study design and estimates are not treated as direct benchmarks for this experiment.
The objectives are to assess incremental signal beyond prior utilization, compare ranking with probability reliability, expose threshold-dependent error burdens, explain saved model behavior and describe uncertainty across demographic groups. None of these objectives is an intervention study. No treatment or care recommendation is generated from a score. A useful educational result may be modest performance accompanied by a clear account of what cannot be inferred.


## Dataset and methods
The UCI Diabetes 130-US Hospitals for Years 1999–2008 dataset [1] is licensed CC BY 4.0. The validated source contains 101,766 rows, 50 columns and 71,518 patients. Encounter identifiers are unique; observed duplicates: 0. The source file is checked against a locally calculated SHA-256 manifest on every load. The direct official ZIP route has retries, staged writes, CRC and member checks, fixed-name extraction and schema validation; ucimlrepo is a fallback, with manual placement required when the original mapping cannot be obtained.
The binary target is one for `<30` and zero for both `>30` and `NO`. The prediction unit is an encounter. Death/hospice discharges are excluded using descriptions in IDS_mapping.csv rather than unverified IDs. This removes 2,423 records; 101,766 minus 2,423 equals 99,343. The observed exclusion ledger is below.
| discharge_disposition_id | n | description |
| --- | --- | --- |
| 11 | 1642 | Expired |
| 13 | 399 | Hospice / home |
| 14 | 372 | Hospice / medical facility |
| 19 | 8 | Expired at home. Medicaid only, hospice. |
| 20 | 2 | Expired in a medical facility. Medicaid only, hospice. |
Literal `?` becomes missing before counting. Literal `None` in A1C/glucose fields remains not-tested, rather than being conflated with missing or normal. Weight missingness is 96.86%; payer-code missingness 39.56%; specialty missingness 49.08%. Weight is removed; payer and specialty retention with explicit Unknown is compared against dropping them. Race Unknown is retained, and 3 Unknown/Invalid gender rows are retained as a distinct category.
Every source column has a discharge-availability entry in docs/FEATURE_AVAILABILITY.md. Diagnoses may be finalized after discharge in practice, so their operational availability is uncertain. Discharge disposition is known at discharge but may encode process and access effects. Identifiers and the target never enter the feature matrix. Prior visit counts already cover the preceding year and are not decremented.
The outer split uses the first seeded StratifiedGroupKFold partition from 5 folds [3]. Inner model comparison uses 5 folds on training patients. Assertions prohibit overlap across patient groups. Training prevalence is 11.46%; holdout prevalence is 11.10%. Group stratification approximates, rather than guarantees, encounter-level balance. Dates and hospital IDs are absent: this is neither temporal validation nor hospital-cluster validation.


## Exploratory analysis
For age, descriptive groups meeting the encounter-count filter ranged from 1.9% ([0-10), n=160) to 14.3% ([20-30), n=1,649). For race, descriptive groups meeting the encounter-count filter ranged from 8.4% (Unknown, n=2,234) to 11.5% (Caucasian, n=74,220). For gender, descriptive groups meeting the encounter-count filter ranged from 11.3% (Male, n=45,886) to 11.5% (Female, n=53,454). These are unadjusted encounter-level comparisons; they can reflect case mix, utilization, coding, access and repeated encounters. They do not imply that demographic attributes cause readmission. The complete table includes smaller groups and Wilson intervals. Demographic summaries are a starting point for reliability assessment rather than a reason to exclude groups.
The EDA uses chi-square tests with Cramér's V for categorical features and Mann–Whitney U tests with rank-biserial effects for numeric features. Benjamini–Hochberg correction is applied across the declared family of 20 tests. The following are the largest observed absolute effects in that family; effect-size scales differ by test and should not be compared as identical quantities.
| feature | test | effect | effect_name | q_bh |
| --- | --- | --- | --- | --- |
| number_inpatient | Mann-Whitney U | 0.2145 | rank-biserial (+ = larger positive values) | 0.0000 |
| discharge_disposition_id | chi-square | 0.1153 | Cramers V | 0.0000 |
| time_in_hospital | Mann-Whitney U | 0.0954 | rank-biserial (+ = larger positive values) | 0.0000 |
Large sample size can make small associations statistically detectable. Chi-square assumes independent observations and adequate expected cells; the table records low expected-cell counts. Mann–Whitney is a rank/distribution comparison, not automatically a test of medians. Repeated encounters weaken independence assumptions. EDA Wilson intervals are therefore labeled descriptive; final model uncertainty uses patient clusters. Statistical significance alone does not select a feature or establish practical importance.
![Recorded utilization by outcome; subgroup encounter counts appear above bars.](figures/eda_utilization.png)
Prior utilization, diagnoses, length of stay, laboratory-test recording and treatment-change patterns are candidate predictive information. These variables are available during the discharge process, but each can reflect clinical complexity and care processes. The complete EDA report, numeric summaries, missingness by target and categorical cardinalities are saved separately. Missingness is not assumed to be random, and observed test ordering is not interpreted as a normal laboratory result.


## Modeling methodology
A scikit-learn Pipeline contains deterministic feature construction, fold-fitted near-constant filtering, a ColumnTransformer and the estimator. Numeric inputs receive median imputation; logistic models additionally use StandardScaler. Trees receive no scaling. Skew is retained rather than choosing an unvalidated transformation. Categorical inputs receive explicit Unknown handling and one-hot encoding with unseen-category tolerance and fold-fitted infrequent-category pooling. The strict inference API separately rejects unseen inputs to make extrapolation visible.
Engineered features include total prior visits, indicators of prior inpatient/emergency use, coarse length-of-stay bands, separate ICD-9 diagnosis groups, counts of recorded medication dose increases/decreases, total medication-change count and an A1C-tested indicator. Age brackets become ordered decades, not exact ages. V and E diagnosis codes are handled explicitly. Detailed definitions, code ranges, rationale and availability limits appear in docs/FEATURE_ENGINEERING.md. No target encoding or resampling is used. The final fitted removal list is: chlorpropamide, acetohexamide, tolbutamide, acarbose, miglitol, troglitazone, tolazamide, examide, citoglipton, glipizide-metformin, glimepiride-pioglitazone, metformin-rosiglitazone, metformin-pioglitazone.
Each non-dummy candidate receives a fixed randomized search budget of 2 configurations with average precision scoring. Full search spaces, chosen hyperparameters, fold metrics, fitting time and inference time are in the training artifact. Random forest depth/leaf constraints and histogram-boosting leaf/regularization constraints limit complexity. Balanced logistic regression is compared with its unweighted counterpart; weighting is not assumed to preserve probability calibration.
| model | average_precision | brier | fold_ap_sd | mean_train_ap |
| --- | --- | --- | --- | --- |
| dummy | 0.1126 | 0.1015 | 0.0030 | 0.1146 |
| prior_utilization | 0.1914 | 0.0989 | 0.0103 | 0.1847 |
| logistic | 0.2126 | 0.0975 | 0.0094 | 0.2192 |
| logistic_balanced | 0.2115 | 0.2267 | 0.0095 | 0.2170 |
| random_forest | 0.2138 | 0.0976 | 0.0123 | 0.2644 |
| hist_gradient_boosting | 0.2308 | 0.0965 | 0.0122 | 0.2907 |
| drop_payer_specialty | 0.2115 | 0.0976 | 0.0097 | 0.2166 |
At the default threshold, the explicit imbalance comparison is below. Class weighting changes the probability scale and error burden; it is not treated as calibration-preserving.
| model | precision | recall | brier | calibration_in_large |
| --- | --- | --- | --- | --- |
| logistic | 0.5128 | 0.0131 | 0.0975 | -0.0001 |
| logistic_balanced | 0.1815 | 0.5644 | 0.2267 | 0.3516 |
Selection considers models within the configured AP tolerance of the best and chooses the lowest Brier score, with a documented tie rule. The selected model's mean training AP is 0.291, versus OOF AP 0.231; its fold AP standard deviation is 0.012. This gap cautions against interpreting fitting performance as generalization. Search and OOF model comparison reuse training folds, so selection estimates remain optimistic even though patient leakage is prevented. The untouched holdout is the final evaluation; a fully nested model-search comparison would be a useful future extension.


## Calibration, thresholds and final results
Uncalibrated, sigmoid and isotonic probabilities are compared in nested grouped training validation [4]. For each outer training-validation fold, calibrators learn from inner OOF predictions; the outer validation labels are not available to that fitting step. The final calibrator uses full training OOF probabilities, and the underlying estimator is fitted on all training encounters. The selected calibration method is sigmoid.
| method | average_precision | brier |
| --- | --- | --- |
| uncalibrated | 0.2308 | 0.0965 |
| sigmoid | 0.2307 | 0.0965 |
| isotonic | 0.2272 | 0.0966 |
The maximum-F1 training rule freezes threshold 0.137823. Alternative rules target recall subject to a minimum precision or minimize hypothetical false-negative/false-positive costs. The latter sensitivity table is below; these ratios are parameters, not measured clinical costs. Feasibility of the constrained-recall rule is explicitly recorded in the calibration JSON. No rule is clinically optimal on this evidence.
| false_negative_cost_ratio | threshold | precision | recall | selection_rate |
| --- | --- | --- | --- | --- |
| 1 | 0.4686 | 0.5902 | 0.0172 | 0.0033 |
| 2 | 0.3076 | 0.4090 | 0.0833 | 0.0233 |
| 5 | 0.1750 | 0.2450 | 0.3206 | 0.1500 |
| 10 | 0.0860 | 0.1527 | 0.7816 | 0.5867 |
The final holdout comprises 19,718 encounters from 14,038 patients. ROC-AUC is 0.679 (95% cluster interval 0.664–0.694); average precision is 0.235 (95% cluster interval 0.214–0.257). AP is sklearn.metrics.average_precision_score [5], distinct from trapezoidal PR area; its no-skill prevalence reference is 0.111. Frozen-threshold recall is 0.474 (95% cluster interval 0.451–0.504), precision 0.209 (95% cluster interval 0.195–0.226), and Brier 0.093 (95% cluster interval 0.090–0.097). Intervals use 200 valid of 200 patient-cluster bootstrap replicates with seed 42. Each sampled patient brings all encounters; intervals are percentile, pointwise and conditional on the fitted selected model, not uncertainty over every modeling choice.
At 0.50, recall is 0.020 and precision 0.512. At the frozen threshold, 1,038 positive encounters are flagged, 1,150 are missed, and 3,921 comparison encounters are flagged. Selection rate is 25.1%. These counts make the burden visible; better recall is not automatically a useful decision policy.
![Holdout ROC, precision–recall and quantile-bin calibration curves.](figures/test_curves.png)
| analysis | n | average_precision | roc_auc | recall | precision | brier |
| --- | --- | --- | --- | --- | --- | --- |
| first_encounter | 14038 | 0.1847 | 0.6561 | 0.2637 | 0.2000 | 0.0766 |
| without_discharge | 19718 | 0.2094 | 0.6552 | 0.4090 | 0.1967 | 0.0947 |
| without_demographics | 19718 | 0.2356 | 0.6788 | 0.4644 | 0.2070 | 0.0933 |
Sensitivity models retain primary hyperparameters and threshold; the selected calibration method is fitted on each variant's training OOF predictions. First encounter means first eligible record in supplied file order, not verified chronology. Feature-removal differences describe dependence on information under this design; they do not identify a causal or fairness effect.


## Explainability
Original-feature permutation importance is evaluated on a seeded heldout sample of 1,500 encounters with 3 permutations. Each original column is permuted before feature construction, so all derived and one-hot consequences move together. The largest observed AP decreases are associated with number_inpatient, discharge_disposition_id, payer_code. This ranking is conditional on the fitted model, sample and correlated inputs; it does not imply that changing these variables would improve outcomes.
![Original-feature permutation importance; bars show permutation-repeat standard deviations.](figures/permutation_importance.png)
Penalized logistic coefficients and odds ratios are saved for standardized numeric and encoded categorical features. They are descriptive conditional associations. Inferential confidence intervals were not estimated because penalization, correlated engineered features and one-hot coding complicate a defensible interpretation; no unsupported significance claim is made.
Tree SHAP [6] uses 200 sampled heldout encounters and the uncalibrated histogram-boosting model. Contributions are in tree log-odds with a tree-path-dependent background. The sigmoid/isotonic mapping is not additively explained by those values; primary calibrated probabilities are presented separately. Three anonymous examples span the sampled predicted-probability ordering and show top contributions without source identifiers or raw feature rows.
Partial dependence and ICE vary prior inpatient visits, length of stay and diagnosis count while holding the sampled covariates fixed. These visualizations show model behavior, not interventions, and may create unusual covariate combinations. Correlated features can dilute permutation importance or redistribute SHAP attribution. Impurity importance is not used. Explanation agreement is not evidence of causal validity or clinical appropriateness.


## Fairness and reliability
Fairlearn MetricFrame [7] computes subgroup n, positives, prevalence, selection rate, recall, FPR, FNR, precision, specificity, ROC-AUC and calibration-in-the-large for age, gender and race. Unknown race is separate. Calibration-in-the-large is defined here as mean predicted probability minus observed prevalence; positive values indicate overprediction. Probability-calibration curves are generated only where support meets the configured encounter and positive-count thresholds. Every group has pointwise patient-cluster bootstrap intervals where estimable; invalid one-class resamples are skipped and their valid-replicate counts are recorded.
| group | n | positive_count | prevalence | recall | fpr | precision | small_group |
| --- | --- | --- | --- | --- | --- | --- | --- |
| AfricanAmerican | 3578.0000 | 410.0000 | 0.1146 | 0.4756 | 0.2222 | 0.2169 | False |
| Asian | 119.0000 | 12.0000 | 0.1008 | 0.4167 | 0.1963 | 0.1923 | True |
| Caucasian | 14825.0000 | 1652.0000 | 0.1114 | 0.4715 | 0.2271 | 0.2066 | False |
| Hispanic | 388.0000 | 51.0000 | 0.1314 | 0.6275 | 0.2077 | 0.3137 | False |
| Other | 314.0000 | 29.0000 | 0.0924 | 0.5172 | 0.2070 | 0.2027 | True |
| Unknown | 494.0000 | 34.0000 | 0.0688 | 0.3529 | 0.1630 | 0.1379 | False |
Across sufficiently supported primary groups, computed point-estimate ranges are age: recall range 0.417, FPR range 0.096; gender: recall range 0.026, FPR range 0.023; race: recall range 0.275, FPR range 0.064. These descriptive gaps are not adjusted causal disparities or simultaneous significance tests. Groups below 100 encounters or 30 positives are flagged rather than used to support strong conclusions. Undefined ROC/AP values are blank, and precision/recall use the explicitly documented zero-division convention.
Demographic parity asks about selection rates; equalized odds asks about conditional TPR/FPR; calibration asks whether scores correspond to observed outcomes. For imperfect predictors these criteria generally cannot all hold when prevalence differs. Choosing a criterion requires context and stakeholder judgments that this educational analysis cannot supply. Differences may reflect prevalence, sample size, historical access, measurement, coding and unmeasured severity.
The frozen model without race/gender is evaluated both overall and within the same groups. Removing those columns does not remove utilization, payer or discharge proxies. The comparison is an information-sensitivity analysis, not proof that either inclusion or omission is fair. Historical race categories are coarse, recorded during an earlier era and unsuitable for claims of biological causation. This analysis does not establish safety or appropriateness for deployment.


## Discussion, limitations and conclusion
The models contain predictive signal beyond a simple utilization benchmark under this patient-grouped design, while the final threshold exposes meaningful false-positive and missed-positive burdens. Probability reliability and precision–recall performance are more informative for the stated objective than accuracy alone. The results support a limited claim about retrospective prediction in this dataset, not a claim about better patient outcomes from model use.
Patient grouping prevents one patient's encounters appearing on both sides of a split, but does not address unmeasured hospital effects, unobserved calendar drift or dependence beyond recorded patient identity. The historical cohort may differ substantially from current practice. Diagnosis coding can be finalized after discharge, and some discharge fields may not be operationally available at the moment a real system would need them. Excluding death/hospice encounters creates a defined eligible population and limits transportability outside it.
Hyperparameter budgets are modest and selection estimates share training folds. Calibration selection and thresholds can still be unstable under new prevalence or practice patterns. Cluster bootstrap intervals condition on the chosen model and cannot capture dataset collection bias, unmeasured variables or all model-search uncertainty. The source lacks comprehensive socioeconomic and care-process information. Protected-attribute comparisons are coarse, pointwise and exploratory; small-group flags do not solve missing representation.
This repository is intended to make limitations inspectable: source hashes, seeds, package versions, availability decisions, removal logs, frozen metadata and test ordering are explicit. The dashboard reads only saved aggregate artifacts and never downloads data or retrains. Model files are local and ignored by Git. The inference loader checks SHA-256 before deserialization, rejects unseen categories and invalid ranges, and warns that trusted artifact provenance is still necessary because joblib can execute code.
Future work should begin with external, current and prospectively available data, a clearly specified decision context, patient and clinician input, and evaluation of operational burden and subgroup harms. A fully nested search comparison and stronger uncertainty over model selection could further qualify retrospective conclusions. No optional clinical deployment, causal estimate or fairness mitigation is claimed here. The current outcome is a reproducible educational analysis whose modest predictive results and uncertainty are reported without optimizing for an impressive score.
### References and provenance
- [1] Clore, J., Cios, K., DeShazo, J. & Strack, B. (2014). Diabetes 130-US Hospitals for Years 1999–2008. UCI Machine Learning Repository. [Dataset and CC BY 4.0 license](https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999+2008), [doi:10.24432/C5230J](https://doi.org/10.24432/C5230J).
- [2] Strack, B., DeShazo, J. P., Gennings, C., Olmo, J. L., Ventura, S., Cios, K. J. & Clore, J. N. (2014). Impact of HbA1c Measurement on Hospital Readmission Rates: Analysis of 70,000 Clinical Database Patient Records. BioMed Research International, 2014, Article 781670. [doi:10.1155/2014/781670](https://doi.org/10.1155/2014/781670).
- [3] scikit-learn documentation. [StratifiedGroupKFold](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.StratifiedGroupKFold.html).
- [4] scikit-learn documentation. [Probability calibration](https://scikit-learn.org/stable/modules/calibration.html).
- [5] scikit-learn documentation. [average_precision_score](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html).
- [6] SHAP documentation. [TreeExplainer](https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html).
- [7] Fairlearn documentation. [MetricFrame](https://fairlearn.org/main/api_reference/generated/fairlearn.metrics.MetricFrame.html).
All references above were checked against UCI, the publisher DOI page or official documentation during the build. Exact runtime versions are recorded in reports/metrics/test.json and requirements-lock.txt; online documentation can describe newer releases than the pinned runtime. API behavior was verified by execution against installed versions.

