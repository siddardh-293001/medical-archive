"""Nested grouped calibration comparison and pre-test freeze."""

import json
import joblib
import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.linear_model import LogisticRegression
from sklearn.isotonic import IsotonicRegression
from threadpoolctl import threadpool_limits
from src.config import ROOT, CONFIG
from src.splits import feature_matrix, grouped_folds
from src.quality import load_cohort
from src.validation import target
from src.train import oof_predict
from src.metrics import metrics
from src.thresholds import threshold_table, strategies
from src.utils import save_json, now, versions, log, sha256


class ProbabilityCalibrator(BaseEstimator):
    def __init__(self, method="uncalibrated"):
        self.method = method

    def fit(self, p, y):
        p = np.asarray(p)
        if self.method == "sigmoid":
            self.model_ = LogisticRegression(C=1e6, random_state=CONFIG["seed"]).fit(self._logit(p), y)
        elif self.method == "isotonic":
            self.model_ = IsotonicRegression(out_of_bounds="clip").fit(p, y)
        elif self.method != "uncalibrated":
            raise ValueError("Unknown calibration method")
        return self

    @staticmethod
    def _logit(p):
        p = np.clip(p, 1e-6, 1 - 1e-6)
        return np.log(p / (1 - p)).reshape(-1, 1)

    def predict(self, p):
        if self.method == "uncalibrated":
            return np.asarray(p)
        if self.method == "sigmoid":
            return self.model_.predict_proba(self._logit(p))[:, 1]
        return self.model_.predict(p)


class CalibratedPipeline(ClassifierMixin, BaseEstimator):
    def __init__(self, base, calibrator, threshold=0.5):
        self.base = base
        self.calibrator = calibrator
        self.threshold = threshold
        self.classes_ = np.array([0, 1])

    def fit(self, X, y=None):
        raise RuntimeError("Frozen calibrated artifact cannot be refitted; run make train")

    def predict_proba(self, X):
        p = np.clip(self.calibrator.predict(self.base.predict_proba(X)[:, 1]), 0, 1)
        return np.column_stack([1 - p, p])

    def predict(self, X):
        return (self.predict_proba(X)[:, 1] >= self.threshold).astype(int)

    def __sklearn_is_fitted__(self):
        return True


def schema(X):
    result = {}
    for c in X.drop(columns="weight", errors="ignore"):
        if X[c].dtype.kind in "iuf":
            result[c] = {
                "type": "integer",
                "minimum": int(X[c].min()),
                "maximum": int(X[c].max()),
                "missing_allowed": bool(X[c].isna().any()),
            }
        else:
            result[c] = {
                "type": "category",
                "values": sorted(X[c].dropna().astype(str).unique().tolist()),
                "missing_allowed": bool(X[c].isna().any()),
            }
    for c in ["admission_type_id", "admission_source_id", "discharge_disposition_id"]:
        if c in result:
            result[c]["allowed_values"] = sorted(X[c].dropna().astype(int).unique().tolist())
    return result


def main():
    if (ROOT / "reports/metrics/test.json").exists():
        raise RuntimeError("Test evaluation already exists. Run make train explicitly to start a new experiment.")
    training = json.loads((ROOT / "reports/metrics/training.json").read_text())
    chosen = training["selected_model"]
    d = load_cohort()
    train = np.load(ROOT / "data/processed/split.npz")["train"]
    train_df = d.iloc[train].reset_index(drop=True)
    X = feature_matrix(train_df)
    y = target(train_df)
    groups = train_df.patient_nbr.to_numpy()
    base = joblib.load(ROOT / "models/base.joblib")
    arrays = np.load(ROOT / "data/processed/training_oof.npz")
    raw_oof = arrays[chosen]
    methods = ["uncalibrated", "sigmoid", "isotonic"]
    nested = {method: np.zeros(len(X)) for method in methods}
    # Inner training OOF probabilities fit calibrators; outer predictions are disjoint.
    for fold, (a, b) in enumerate(grouped_folds(y, groups)):
        print(f"Nested calibration outer fold {fold + 1}/{CONFIG['cv_folds']}", flush=True)
        inner = grouped_folds(y.iloc[a], groups[a])
        inner_p, _ = oof_predict(base, X.iloc[a].reset_index(drop=True), y.iloc[a].reset_index(drop=True), inner)
        for method in methods:
            cal = ProbabilityCalibrator(method).fit(inner_p, y.iloc[a])
            nested[method][b] = cal.predict(raw_oof[b])
    results = {m: metrics(y, p) for m, p in nested.items()}
    method = min(methods, key=lambda m: results[m]["brier"])
    cal = ProbabilityCalibrator(method).fit(raw_oof, y)
    table = threshold_table(y, nested[method])
    rules = strategies(table)
    threshold = rules["maximum_f1"]["threshold"]
    table.to_csv(ROOT / "reports/tables/training_thresholds.csv", index=False)
    import pandas as pd

    pd.DataFrame(rules["hypothetical_costs"]).to_csv(ROOT / "reports/tables/cost_sensitivity.csv", index=False)
    save_json(
        "reports/metrics/calibration.json",
        {
            "methods": results,
            "chosen_method": method,
            "rules": rules,
            "versions": versions(),
            "seed": CONFIG["seed"],
            "cv": "Nested StratifiedGroupKFold",
        },
    )
    np.savez(ROOT / "data/processed/calibrated_oof.npz", y=y.to_numpy(), **nested)
    variants = {"primary": {"model": "pipeline.joblib", "rows": len(X), "threshold": threshold}}
    model = CalibratedPipeline(base, cal, threshold)
    joblib.dump(model, ROOT / "models/pipeline.joblib")
    for name, drops, first in [
        ("first_encounter", (), True),
        ("without_discharge", ("discharge_disposition_id",), False),
        ("without_demographics", ("race", "gender"), False),
    ]:
        print(f"Training frozen sensitivity: {name}", flush=True)
        subset = train_df.drop_duplicates("patient_nbr", keep="first") if first else train_df
        subX = feature_matrix(subset).reset_index(drop=True)
        suby = target(subset).reset_index(drop=True)
        estimator = clone(base)
        previous = tuple(estimator.named_steps["features"].drop_columns)
        estimator.set_params(features__drop_columns=tuple(set(previous + drops)))
        p, _ = oof_predict(estimator, subX, suby, grouped_folds(suby, subset.patient_nbr.to_numpy()))
        variant_cal = ProbabilityCalibrator(method).fit(p, suby)
        estimator.fit(subX, suby)
        variant = CalibratedPipeline(estimator, variant_cal, threshold)
        joblib.dump(variant, ROOT / f"models/{name}.joblib")
        variants[name] = {
            "model": f"{name}.joblib",
            "rows": len(subX),
            "threshold": threshold,
            "calibration": "Primary chosen method fitted on variant training OOF; primary threshold fixed; no retuning",
        }
    metadata = {
        "frozen_utc": now(),
        "model_version": now(),
        "model_type": chosen,
        "hyperparameters": training["models"][chosen]["best_params"],
        "target_definition": "1 if <30; >30 and NO are 0",
        "prediction_time": "discharge",
        "threshold": threshold,
        "calibration": method,
        "feature_schema": schema(X),
        "validation": "StratifiedGroupKFold outer holdout and training CV; nested calibration",
        "versions": versions(),
        "seeds": {"all": CONFIG["seed"]},
        "training_evaluation": results[method],
        "variants": variants,
        "model_sha256": sha256(ROOT / "models/pipeline.joblib"),
        "variant_hashes": {k: sha256(ROOT / "models" / v["model"]) for k, v in variants.items()},
        "raw_data_sha256": sha256(ROOT / "data/raw/diabetic_data.csv"),
        "split_sha256": sha256(ROOT / "data/processed/split.npz"),
    }
    save_json("models/metadata.json", metadata)
    save_json("models/frozen_config.json", metadata)
    removed = {
        "fixed": ["encounter_id", "patient_nbr", "readmitted", "weight"],
        "fold_fitted_final_removals": base.named_steps["features"].removed_,
        "final_features": base.named_steps["features"].columns_,
    }
    save_json("reports/tables/feature_removal.json", removed)
    with (ROOT / "docs/DECISIONS.md").open("a") as f:
        f.write(
            f"\n- Frozen calibration: {method}; maximum-F1 training OOF threshold recorded in models/frozen_config.json. Sensitivities retain primary hyperparameters and threshold, with the selected calibration method refitted on each variant's training OOF predictions. Exact removed columns: reports/tables/feature_removal.json.\n"
        )
    log(
        "Stage 6 — PASS",
        f"Nested grouped calibration comparison completed; selected {method}. Training-only threshold alternatives and cost table saved. Primary and all sensitivity models frozen with hashes and timestamp BEFORE the first test evaluation. No test outcomes were evaluated.",
    )


if __name__ == "__main__":
    from src.calibrate import main as run

    with threadpool_limits(limits=2):
        run()
