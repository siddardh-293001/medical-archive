"""Validated acquisition; no synthetic substitution. python -m src.data_loader download."""

import argparse
import csv
import json
from pathlib import Path
import shutil
import time
import warnings
import zipfile
import pandas as pd
import requests
from src.config import ROOT
from src.utils import now, sha256
from src.validation import read_data

SOURCE_URL = "https://archive.ics.uci.edu/static/public/296/diabetes+130-us+hospitals+for+years+1999-2008.zip"
LEGACY_SOURCE_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/00296/dataset_diabetes.zip"
PAGE_URL = "https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999+2008"
FILES = ("diabetic_data.csv", "IDS_mapping.csv")


class DatasetDownloadError(RuntimeError):
    pass


def read_mappings(path):
    mappings, current = {}, None
    for row in csv.reader(Path(path).open()):
        if len(row) < 2 or not row[0]:
            continue
        if row[0].endswith("_id"):
            current = row[0]
            mappings[current] = {}
        elif current:
            mappings[current][int(row[0])] = row[1].strip()
    if set(mappings) != {"admission_type_id", "discharge_disposition_id", "admission_source_id"}:
        raise ValueError("Mapping sections missing")
    return mappings


def manifest(raw, source):
    df = read_data(raw / FILES[0])
    read_mappings(raw / FILES[1])
    obj = {
        "source_url": source,
        "retrieved_utc": now(),
        "rows": len(df),
        "columns": len(df.columns),
        "files": {n: {"bytes": (raw / n).stat().st_size, "sha256": sha256(raw / n)} for n in FILES},
    }
    (raw / "MANIFEST.json").write_text(json.dumps(obj, indent=2))
    return raw / FILES[0]


def extract(archive, raw, legacy=False):
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError("Corrupt ZIP")
        members = {Path(n).name: n for n in z.namelist()}
        if legacy and "IDs_mapping.csv" in members:
            members["IDS_mapping.csv"] = members["IDs_mapping.csv"]
        if not set(FILES) <= members.keys():
            raise ValueError("Required ZIP members missing")
        payload = {name: z.read(members[name]) for name in FILES}
    # Validate in staging before replacing any destination file.
    import tempfile

    with tempfile.TemporaryDirectory() as temp:
        stage = Path(temp)
        for name, body in payload.items():
            (stage / name).write_bytes(body)
        read_data(stage / FILES[0])
        read_mappings(stage / FILES[1])
        for name in FILES:
            shutil.copyfile(stage / name, raw / (name + ".part"))
            (raw / (name + ".part")).replace(raw / name)


def download(raw, source_url=SOURCE_URL):
    part = raw / "dataset.zip.part"
    for attempt in range(4):
        try:
            with requests.get(
                source_url,
                stream=True,
                timeout=(15, 120),
                headers={"User-Agent": "MedicalArchiveResearch/1.0 (UCI296 reproducibility)"},
            ) as response:
                response.raise_for_status()
                with part.open("wb") as f:
                    for chunk in response.iter_content(65536):
                        f.write(chunk)
            extract(part, raw, legacy=source_url == LEGACY_SOURCE_URL)
            part.unlink(missing_ok=True)
            return
        except (requests.RequestException, ValueError, zipfile.BadZipFile, OSError):
            part.unlink(missing_ok=True)
            if attempt == 3:
                raise
            time.sleep(2**attempt)


def fallback(raw):
    from ucimlrepo import fetch_ucirepo

    result = fetch_ucirepo(id=296)
    df = pd.concat([result.data.ids, result.data.features, result.data.targets], axis=1)
    df.columns = df.columns.str.strip()
    # Standalone mapping endpoints return 404; the official legacy ZIP remains available.
    import tempfile

    with tempfile.TemporaryDirectory() as temp:
        stage = Path(temp)
        download(stage, source_url=LEGACY_SOURCE_URL)
        original = read_data(stage / FILES[0]).set_index("encounter_id")
        # ucimlrepo uses pandas defaults and converts literal None lab values to NaN.
        # Restore this known code only after checking it against the official CSV per encounter.
        for column in ["max_glu_serum", "A1Cresult"]:
            recovered = df[column].fillna("None").astype(str)
            reference = df.encounter_id.map(original[column]).astype(str)
            if not recovered.equals(reference):
                raise ValueError(f"ucimlrepo {column} does not reconcile with original lab codes")
            df[column] = recovered
        df.to_csv(stage / FILES[0], index=False)
        read_data(stage / FILES[0])
        read_mappings(stage / FILES[1])
        for name in FILES:
            shutil.copyfile(stage / name, raw / (name + ".part"))
            (raw / (name + ".part")).replace(raw / name)


def ensure_dataset(raw_dir="data/raw", force=False):
    raw = Path(raw_dir)
    if not raw.is_absolute():
        raw = ROOT / raw
    raw.mkdir(parents=True, exist_ok=True)
    saved = raw / "MANIFEST.json"
    if all((raw / n).exists() for n in FILES) and not force:
        if saved.exists():
            try:
                info = json.loads(saved.read_text())
                intact = all(
                    sha256(raw / n) == info["files"][n]["sha256"]
                    and (raw / n).stat().st_size == info["files"][n]["bytes"]
                    for n in FILES
                )
            except (ValueError, KeyError, TypeError):
                intact = False
            if not intact:
                warnings.warn("Cache disagrees with manifest; use download --force", stacklevel=2)
                raise DatasetDownloadError(
                    "Cache integrity check failed. Run python -m src.data_loader download --force"
                )
            frame = read_data(raw / FILES[0])
            if info.get("rows") != len(frame) or info.get("columns") != len(frame.columns):
                raise DatasetDownloadError("Manifest dimensions disagree; rerun download --force")
            read_mappings(raw / FILES[1])
            return raw / FILES[0]
        return manifest(raw, "manual placement; official source: " + SOURCE_URL)
    try:
        download(raw)
        return manifest(raw, SOURCE_URL)
    except Exception as primary:
        try:
            fallback(raw)
            return manifest(raw, "ucimlrepo id=296; mapping and lab-code validation from " + LEGACY_SOURCE_URL)
        except Exception as secondary:
            raise DatasetDownloadError(
                f"Automatic acquisition failed ({primary}; {secondary}). Download ZIP from {PAGE_URL} in a browser; place diabetic_data.csv and IDS_mapping.csv in {raw}, then rerun."
            ) from secondary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["download"])
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    print(ensure_dataset(force=args.force))
