"""Aggregated EDA, uncertainty and effect sizes. No patient rows are exported."""

import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, mannwhitneyu
from src.config import ROOT
from src.quality import load_cohort
from src.validation import target
from src.feature_engineering import diagnosis_group, NUMERIC
from src.theme import apply_mpl_style, save_figure, INK, OXIDE, FOREST, PAPER, contrast
from src.utils import log, save_json, versions


def wilson(k, n):
    z = 1.95996398454
    p = k / n
    den = 1 + z * z / n
    center = (p + z * z / (2 * n)) / den
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return center - half, center + half


def main():
    apply_mpl_style()
    import matplotlib.pyplot as plt

    d = load_cohort()
    d["target"] = target(d)
    for c in ["diag_1", "diag_2", "diag_3"]:
        d[c + "_group"] = d[c].map(diagnosis_group)
    categorical = [
        "age",
        "gender",
        "race",
        "diag_1_group",
        "diag_2_group",
        "diag_3_group",
        "A1Cresult",
        "max_glu_serum",
        "change",
        "diabetesMed",
        "admission_type_id",
        "discharge_disposition_id",
    ]
    aggregates = []
    tests = []
    narrative = [
        "# Exploratory analysis",
        "",
        "Eligible discharge encounters only. Rates are associations, not causes. Intervals are encounter-level Wilson intervals for descriptive EDA; final model uncertainty uses patient clusters. Repeated encounters limit the independence assumptions of these exploratory tests.",
        "",
    ]
    for c in categorical:
        group = d[c].fillna("Unknown").astype(str)
        table = (
            d.groupby(group)
            .target.agg(n="size", positive="sum", rate="mean")
            .reset_index()
            .rename(columns={c: "group"})
        )
        lo, hi = wilson(table.positive, table.n)
        table["ci_low"] = lo
        table["ci_high"] = hi
        table["feature"] = c
        aggregates.append(table)
        contingency = pd.crosstab(group, d.target)
        chi, p, _, expected = chi2_contingency(contingency)
        v = np.sqrt(chi / (contingency.to_numpy().sum() * min(contingency.shape[0] - 1, contingency.shape[1] - 1)))
        tests.append(
            {
                "feature": c,
                "test": "chi-square",
                "statistic": chi,
                "p": p,
                "effect": v,
                "effect_name": "Cramers V",
                "low_expected_cells": int((expected < 5).sum()),
            }
        )
        fig, ax = plt.subplots(figsize=(9, max(4, len(table) * 0.36)))
        y = np.arange(len(table))
        ax.errorbar(
            table.rate,
            y,
            xerr=[(table.rate - table.ci_low).clip(lower=0), (table.ci_high - table.rate).clip(lower=0)],
            fmt="o",
            color=OXIDE,
            capsize=2,
        )
        ax.set_yticks(y, [f"{g} (n={n:,})" for g, n in zip(table.group, table.n)])
        ax.set(
            xlabel="30-day readmission rate (Wilson 95% interval)",
            ylabel=c.replace("_", " "),
            title=f"Readmission by {c.replace('_', ' ')}",
        )
        ax.invert_yaxis()
        save_figure(fig, f"eda_{c}.png")
        plt.close(fig)
        top = table.loc[table.rate.idxmax()]
        narrative.append(
            f"- **{c}**: highest observed rate in {top['group']}, {top.rate:.1%} (n={int(top.n):,}, Wilson interval {top.ci_low:.1%}–{top.ci_high:.1%}); Cramér's V={v:.3f}. This descriptive comparison may reflect case mix, coding and repeated encounters."
        )
    pd.concat(aggregates, ignore_index=True).to_csv(ROOT / "reports/tables/eda_groups.csv", index=False)
    numeric = []
    for c in NUMERIC:
        a = d.loc[d.target == 1, c]
        b = d.loc[d.target == 0, c]
        u, p = mannwhitneyu(a, b, alternative="two-sided")
        effect = 2 * u / (len(a) * len(b)) - 1
        tests.append(
            {
                "feature": c,
                "test": "Mann-Whitney U",
                "statistic": u,
                "p": p,
                "effect": effect,
                "effect_name": "rank-biserial (+ = larger positive values)",
                "low_expected_cells": 0,
            }
        )
        for outcome, sub in d.groupby("target"):
            numeric.append(
                {
                    "feature": c,
                    "target": outcome,
                    "n": len(sub),
                    "mean": sub[c].mean(),
                    "median": sub[c].median(),
                    "q25": sub[c].quantile(0.25),
                    "q75": sub[c].quantile(0.75),
                }
            )
        narrative.append(
            f"- **{c}**: median {a.median():g} in positives versus {b.median():g} in comparisons; rank-biserial effect {effect:.3f}. Utilization and coding measures are candidate predictors, not intervention targets."
        )
    pd.DataFrame(numeric).to_csv(ROOT / "reports/tables/eda_numeric.csv", index=False)
    fig, axes = plt.subplots(2, 4, figsize=(14, 7))
    for ax, col in zip(axes.flat, NUMERIC):
        subset = pd.DataFrame(numeric).query("feature == @col").sort_values("target")
        ax.bar(["Comparison", "<30 days"], subset["mean"], color=[FOREST, OXIDE], hatch=["//", ""])
        ax.set(title=col.replace("_", " "), ylabel="Mean days" if col == "time_in_hospital" else "Mean count")
        ax.tick_params(axis="x", labelsize=8)
        for i, row in enumerate(subset.itertuples()):
            ax.text(i, row.mean, f"n={row.n:,}", ha="center", va="bottom", fontsize=7)
    fig.suptitle("Recorded utilization and encounter measures by outcome", x=0.08, ha="left")
    fig.tight_layout()
    save_figure(fig, "eda_utilization.png")
    plt.close(fig)
    t = pd.DataFrame(tests).sort_values("p").reset_index(drop=True)
    t["q_bh"] = np.minimum.accumulate((t.p * len(t) / (np.arange(len(t)) + 1))[::-1])[::-1].clip(upper=1)
    t.to_csv(ROOT / "reports/tables/eda_statistics.csv", index=False)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    counts = d.readmitted.value_counts().reindex(["NO", ">30", "<30"])
    axes[0].bar(counts.index, counts.values, color=[FOREST, FOREST, OXIDE], hatch=["//", "//", ""])
    axes[0].set(title="Original outcome", xlabel="Readmission category", ylabel="Encounter count (n)")
    for i, (g, n) in enumerate(counts.items()):
        axes[0].text(i, n, f"{n:,}", ha="center", va="bottom", fontsize=9)
    binary = d.target.value_counts().sort_index()
    axes[1].bar(["Comparison", "<30 days"], binary.values, color=[FOREST, OXIDE], hatch=["//", ""])
    axes[1].set(title="Binary research target", xlabel="Target definition", ylabel="Encounter count (n)")
    save_figure(fig, "eda_target.png")
    plt.close(fig)
    counts.rename("n").to_csv(ROOT / "reports/tables/target_distribution.csv")
    missing = (
        pd.read_csv(ROOT / "reports/tables/data_quality.csv").sort_values("missing_rate", ascending=False).head(12)
    )
    fig, ax = plt.subplots()
    ax.barh(missing.column, missing.missing_rate, color=INK)
    ax.set(title="Source-data missingness", xlabel="Fraction missing (? only)", ylabel="Source column")
    save_figure(fig, "eda_missingness.png")
    plt.close(fig)
    narrative.extend(
        [
            "",
            f"Eligible prevalence is {d.target.mean():.2%}; this is the PR baseline. Imbalance makes accuracy alone misleading.",
            "",
            "Chi-square assumes independent observations and adequate expected counts; low expected cells are recorded. Mann–Whitney compares ranks and does not prove a median shift unless distribution shapes align. BH q-values correct this declared family of exploratory tests. Effect size, uncertainty and sampling structure matter more than significance at this sample size.",
            "",
            "Missingness is summarized in data_quality.csv and by outcome in missingness_by_target.csv. Weight is dropped; payer and specialty retention are compared during modeling. Hypotheses: preceding utilization may add signal; administrative discharge information may contribute process-related signal; testing patterns may reflect measurement bias. These hypotheses require grouped validation.",
        ]
    )
    (ROOT / "reports/eda_report.md").write_text("\n".join(narrative) + "\n")
    save_json(
        "reports/metrics/theme_audit.json",
        {
            "contrast_on_paper": {c: contrast(c, PAPER) for c in [INK, OXIDE, FOREST]},
            "versions": versions(),
            "redundancy": "Direct labels, error markers, solid/dashed curves and hatched comparison bars",
        },
    )
    log(
        "Stage 3 — PASS",
        "Generated aggregate-only EDA tables, Wilson intervals, chi-square/Cramér V, Mann–Whitney/rank-biserial, BH corrections, interpreted report and themed figures. EDA intervals are explicitly descriptive and do not adjust for patient clustering.",
    )


if __name__ == "__main__":
    main()
