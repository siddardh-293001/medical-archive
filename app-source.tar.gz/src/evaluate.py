"""One frozen test evaluation. Existing results are reused, never used for tuning."""

import json
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, precision_recall_curve
from sklearn.calibration import calibration_curve
from threadpoolctl import threadpool_limits
from src.config import ROOT
from src.quality import load_cohort
from src.splits import feature_matrix
from src.validation import target
from src.metrics import metrics
from src.thresholds import threshold_table
from src.uncertainty import cluster_bootstrap
from src.utils import save_json, sha256, now, versions, log
from src.theme import apply_mpl_style, save_figure, OXIDE, FOREST, OCHRE, INK, PAPER, RULE


def frozen_metadata():
    meta = json.loads((ROOT / "models/frozen_config.json").read_text())
    for name, expected in [
        ("data/raw/diabetic_data.csv", meta["raw_data_sha256"]),
        ("data/processed/split.npz", meta["split_sha256"]),
    ]:
        if sha256(ROOT / name) != expected:
            raise ValueError(f"Frozen experiment mismatch: {name}; retrain explicitly")
    return meta


def test_cohort():
    d = load_cohort()
    split = np.load(ROOT / "data/processed/split.npz")
    test = d.iloc[split["test"]].reset_index(drop=True)
    train = d.iloc[split["train"]]
    assert not set(train.patient_nbr) & set(test.patient_nbr)
    return test


def plots(y, p, threshold, result):
    apply_mpl_style()
    import matplotlib.pyplot as plt

    fpr, tpr, _ = roc_curve(y, p)
    precision, recall, _ = precision_recall_curve(y, p)
    frac, mean = calibration_curve(y, p, n_bins=10, strategy="quantile")
    pd.DataFrame({"mean_predicted": mean, "observed": frac}).to_csv(
        ROOT / "reports/tables/test_calibration.csv", index=False
    )
    grid = np.linspace(0, 1, 201)
    pd.DataFrame({"fpr": grid, "tpr": np.interp(grid, fpr, tpr)}).to_csv(
        ROOT / "reports/tables/test_roc.csv", index=False
    )
    pd.DataFrame({"recall": grid, "precision": np.interp(grid, recall[::-1], precision[::-1])}).to_csv(
        ROOT / "reports/tables/test_pr.csv", index=False
    )
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    axes[0].plot(fpr, tpr, color=OXIDE, label="Frozen model", linestyle="-")
    axes[0].plot([0, 1], [0, 1], color=FOREST, linestyle="--", label="Chance")
    axes[0].set(title="Discrimination · ROC", xlabel="False positive rate", ylabel="True positive rate")
    axes[1].plot(recall, precision, color=OXIDE, label="Frozen model")
    axes[1].axhline(np.mean(y), color=FOREST, linestyle="--", label=f"Prevalence {np.mean(y):.1%}")
    axes[1].set(title="Precision–recall", xlabel="Recall", ylabel="Precision")
    axes[2].plot(mean, frac, color=OXIDE, marker="o", label="Frozen model")
    axes[2].plot([0, 1], [0, 1], color=FOREST, linestyle="--", label="Perfect calibration")
    axes[2].set(
        title="Reliability · quantile bins", xlabel="Mean predicted probability", ylabel="Observed readmission fraction"
    )
    for ax in axes:
        ax.legend(frameon=False, fontsize=8)
        ax.grid(alpha=0.5)
    fig.suptitle(f"Patient-disjoint holdout · n={len(y):,}", x=0.08, ha="left")
    fig.tight_layout()
    save_figure(fig, "test_curves.png")
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, key, label in zip(axes, ["default", "frozen"], ["Default 0.50", "Frozen threshold"]):
        cm = np.array(result[key]["confusion_matrix"])
        for i in range(2):
            for j in range(2):
                ax.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1, facecolor=PAPER, edgecolor=RULE))
                ax.text(j, i, f"{cm[i, j]:,}", ha="center", va="center", color=OXIDE if i == 1 else FOREST, fontsize=22)
        ax.set(
            xlim=(-0.5, 1.5),
            ylim=(1.5, -0.5),
            xticks=[0, 1],
            yticks=[0, 1],
            xticklabels=["Comparison", "Positive"],
            yticklabels=["Comparison", "Positive"],
            xlabel="Predicted outcome",
            ylabel="Observed outcome",
            title=label,
        )
    fig.tight_layout()
    save_figure(fig, "test_confusion.png")
    plt.close(fig)
    table = threshold_table(y, p)
    table.to_csv(ROOT / "reports/tables/test_thresholds.csv", index=False)
    fig, ax = plt.subplots()
    ax.plot(table.threshold, table.precision, color=INK, linestyle="--", label="Precision")
    ax.plot(table.threshold, table.recall, color=OXIDE, label="Recall")
    ax.plot(table.threshold, table.f1, color=INK, linestyle=":", label="F1")
    ax.axvline(threshold, color=OCHRE, linewidth=2, label="Frozen training threshold")
    ax.set(
        title=f"Descriptive holdout trade-offs · n={len(y):,}",
        xlabel="Probability threshold (not retuned on test)",
        ylabel="Metric value",
    )
    ax.legend(frameon=False)
    save_figure(fig, "test_thresholds.png")
    plt.close(fig)
    comparison = pd.read_csv(ROOT / "reports/model_comparison.csv").sort_values("average_precision")
    fig, ax = plt.subplots()
    ax.barh(comparison.model, comparison.average_precision, color=INK)
    ax.axvline(comparison.prevalence.iloc[0], color=FOREST, linestyle="--", label="Training prevalence")
    ax.set(
        title=f"Training OOF comparison · n={int(comparison.n.iloc[0]):,}",
        xlabel="Average precision (sklearn)",
        ylabel="Candidate model",
    )
    ax.legend(frameon=False)
    save_figure(fig, "model_comparison.png")
    plt.close(fig)


def main():
    meta = frozen_metadata()
    existing = ROOT / "reports/metrics/test.json"
    if existing.exists():
        result = json.loads(existing.read_text())
        if result["model_sha256"] != meta["model_sha256"]:
            raise ValueError("Existing test results belong to a different frozen model")
        print("Using existing frozen test evaluation; no new predictions.")
        return
    started = now()
    assert meta["frozen_utc"] < started
    d = test_cohort()
    y = target(d)
    results = {}
    predictions = {}
    for name, variant in meta["variants"].items():
        path = ROOT / "models" / variant["model"]
        if sha256(path) != meta["variant_hashes"][name]:
            raise ValueError("Model hash mismatch")
        model = joblib.load(path)
        subset = d.drop_duplicates("patient_nbr", keep="first") if name == "first_encounter" else d
        yy = target(subset)
        pp = model.predict_proba(feature_matrix(subset))[:, 1]
        results[name] = {
            "default": metrics(yy, pp, 0.5),
            "frozen": metrics(yy, pp, meta["threshold"]),
            "uncertainty_frozen": cluster_bootstrap(yy, pp, subset.patient_nbr, meta["threshold"]),
        }
        if name == "primary":
            results[name]["uncertainty_default"] = cluster_bootstrap(yy, pp, subset.patient_nbr, 0.5)
        predictions[name] = pp
    result = {
        "evaluation_started_utc": started,
        "completed_utc": now(),
        "frozen_utc": meta["frozen_utc"],
        "model_sha256": meta["model_sha256"],
        "versions": versions(),
        "primary": results["primary"],
        "sensitivity": {k: v for k, v in results.items() if k != "primary"},
        "test_patients": int(d.patient_nbr.nunique()),
        "threshold": meta["threshold"],
        "training_prevalence": json.loads((ROOT / "reports/metrics/training.json").read_text())["train_prevalence"],
    }
    save_json("reports/metrics/test.json", result)
    # Private predictions support explanation/fairness without rerunning test evaluation.
    np.savez(ROOT / "data/processed/test_predictions.npz", **predictions)
    plots(y, predictions["primary"], meta["threshold"], results["primary"])
    table = []
    for name, values in results.items():
        for rule in ["default", "frozen"]:
            table.append(
                {"analysis": name, "rule": rule, **{k: v for k, v in values[rule].items() if k != "confusion_matrix"}}
            )
    pd.DataFrame(table).to_csv(ROOT / "reports/tables/test_metrics.csv", index=False)
    # Add results to deployment metadata without changing the immutable frozen configuration.
    published = json.loads((ROOT / "models/metadata.json").read_text())
    published["evaluation_results"] = result
    save_json("models/metadata.json", published)
    log(
        "Stage 7 — PASS",
        "Frozen timestamp verified before evaluation. Primary and pre-frozen sensitivities evaluated once; default/frozen metrics, patient-cluster CIs, curves and aggregate tables saved. Private prediction arrays are ignored by Git. AP, recall/precision burden and calibration are emphasized; no clinical utility claim.",
    )
    print(json.dumps(results["primary"]["frozen"], indent=2))


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
