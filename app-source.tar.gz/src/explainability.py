"""Saved-model explanations: associations and model behavior, never causal effects."""

import json
import joblib
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from threadpoolctl import threadpool_limits
from src.config import ROOT, CONFIG
from src.evaluate import test_cohort
from src.splits import feature_matrix
from src.validation import target
from src.theme import apply_mpl_style, save_figure, INK, OXIDE, FOREST, tint
from src.utils import save_json, sha256, versions, log


def main():
    if not (ROOT / "reports/metrics/test.json").exists():
        raise RuntimeError("Run make evaluate first")
    meta = json.loads((ROOT / "models/metadata.json").read_text())
    assert sha256(ROOT / "models/pipeline.joblib") == meta["model_sha256"]
    primary = joblib.load(ROOT / "models/pipeline.joblib")
    d = test_cohort()
    sample = d.sample(n=min(1500, len(d)), random_state=CONFIG["seed"])
    X = feature_matrix(sample)
    y = target(sample)
    apply_mpl_style()
    import matplotlib.pyplot as plt

    importance = permutation_importance(
        primary, X, y, scoring="average_precision", n_repeats=3, random_state=CONFIG["seed"], n_jobs=1
    )
    imp = pd.DataFrame(
        {"feature": X.columns, "ap_decrease": importance.importances_mean, "repeat_sd": importance.importances_std}
    ).sort_values("ap_decrease", ascending=False)
    imp = imp[~imp.feature.isin(["weight"])]
    imp.to_csv(ROOT / "reports/tables/permutation_importance.csv", index=False)
    top = imp.head(15).sort_values("ap_decrease")
    fig, ax = plt.subplots(figsize=(9, 6))
    ax.barh(top.feature, top.ap_decrease, xerr=top.repeat_sd, color=INK)
    ax.set(
        title=f"Original-feature permutation importance · n={len(X):,}",
        xlabel="Decrease in average precision (repeat SD bars)",
        ylabel="Original feature",
    )
    save_figure(fig, "permutation_importance.png")
    plt.close(fig)
    logistic = joblib.load(ROOT / "models/logistic.joblib")
    names = logistic.named_steps["preprocess"].get_feature_names_out()
    beta = logistic.named_steps["model"].coef_[0]
    coefs = pd.DataFrame({"feature": names, "coefficient": beta, "odds_ratio": np.exp(beta)})
    coefs.to_csv(ROOT / "reports/tables/logistic_coefficients.csv", index=False)
    top = coefs.iloc[np.argsort(np.abs(beta))[-20:]].sort_values("coefficient")
    fig, ax = plt.subplots(figsize=(9, 7))
    ax.barh(top.feature, top.coefficient, color=[OXIDE if b > 0 else FOREST for b in top.coefficient])
    ax.axvline(0, color=INK, linewidth=0.5)
    ax.set(
        title="Penalized logistic associations",
        xlabel="Log-odds coefficient (numeric inputs standardized)",
        ylabel="Encoded feature (sign labels via axis)",
    )
    save_figure(fig, "logistic_coefficients.png")
    plt.close(fig)
    tree = joblib.load(ROOT / "models/hist_gradient_boosting.joblib")
    shap_X = X.iloc[:200]
    engineered = tree.named_steps["features"].transform(shap_X)
    encoded = tree.named_steps["preprocess"].transform(engineered)
    encoded_names = tree.named_steps["preprocess"].get_feature_names_out()
    import shap

    explainer = shap.TreeExplainer(tree.named_steps["model"], feature_perturbation="tree_path_dependent")
    values = explainer.shap_values(encoded)
    if isinstance(values, list):
        values = values[1]
    if values.ndim == 3:
        values = values[:, :, 1]
    contributions = pd.DataFrame(values, columns=encoded_names)
    mean_abs = contributions.abs().mean().sort_values(ascending=False)
    pd.DataFrame({"encoded_feature": mean_abs.index, "mean_absolute_logodds_shap": mean_abs.values}).to_csv(
        ROOT / "reports/tables/shap_importance.csv", index=False
    )
    fig, ax = plt.subplots(figsize=(9, 6))
    shown = mean_abs.head(15).sort_values()
    ax.barh(shown.index, shown.values, color=INK)
    ax.set(
        title=f"Tree SHAP · sampled heldout encounters n={len(shap_X)}",
        xlabel="Mean absolute contribution (tree log-odds)",
        ylabel="Encoded feature",
    )
    save_figure(fig, "shap_importance.png")
    plt.close(fig)
    local = []
    positions = np.argsort(primary.predict_proba(shap_X)[:, 1])[[0, len(shap_X) // 2, -1]]
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    for j, (ax, pos) in enumerate(zip(axes, positions), 1):
        row = contributions.iloc[pos]
        important = row.abs().nlargest(6).index
        contributions_top = row[important].sort_values()
        probability = float(primary.predict_proba(shap_X.iloc[[pos]])[0, 1])
        local.append(
            {
                "example": j,
                "primary_probability": probability,
                "threshold": meta["threshold"],
                "tree_probability": float(tree.predict_proba(shap_X.iloc[[pos]])[0, 1]),
                "top_contributions_logodds": contributions_top.to_dict(),
                "notice": "Anonymous sampled example; no raw identifiers or raw feature rows published. SHAP explains the uncalibrated tree, not the calibration mapping; associations are not causes.",
            }
        )
        # Shorten labels for legibility; full labels are in the JSON artifact.
        ax.barh(
            [n.split("__", 1)[-1][:30] for n in contributions_top.index],
            contributions_top.values,
            color=[OXIDE if v > 0 else FOREST for v in contributions_top.values],
        )
        ax.set(
            title=f"Example {j} · p={probability:.1%}",
            xlabel="SHAP log-odds (+ increases score)",
            ylabel="Top encoded contributions",
        )
        ax.axvline(0, color=INK, linewidth=0.5)
    fig.tight_layout()
    save_figure(fig, "local_explanations.png")
    plt.close(fig)
    effect_rows = []
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))
    for ax, col in zip(axes, ["number_inpatient", "time_in_hospital", "number_diagnoses"]):
        grid = np.unique(np.quantile(X[col], np.linspace(0.05, 0.95, 12)).round().astype(int))
        predictions = []
        for value in grid:
            counter = shap_X.copy()
            counter[col] = value
            pp = primary.predict_proba(counter)[:, 1]
            predictions.append(pp)
            effect_rows.append(
                {"feature": col, "value": int(value), "mean_probability": float(pp.mean()), "n": len(pp)}
            )
        matrix = np.array(predictions)
        ax.plot(grid, matrix[:, :20], color=tint(OXIDE, 0.75), linewidth=0.5)
        ax.plot(grid, matrix.mean(axis=1), color=OXIDE, linewidth=2, label="Mean partial dependence")
        ax.set(
            title=col.replace("_", " "),
            xlabel="Days" if col == "time_in_hospital" else "Recorded count",
            ylabel="Predicted readmission probability",
        )
        ax.legend(frameon=False, fontsize=7)
    fig.suptitle(f"Model behavior, not causal effects · n={len(shap_X)}; first 20 ICE curves", x=0.08, ha="left")
    fig.tight_layout()
    save_figure(fig, "feature_effects.png")
    plt.close(fig)
    pd.DataFrame(effect_rows).to_csv(ROOT / "reports/tables/partial_dependence.csv", index=False)
    save_json(
        "reports/metrics/explanations.json",
        {
            "versions": versions(),
            "seed": CONFIG["seed"],
            "permutation_sample_n": len(X),
            "permutation_repeats": 3,
            "shap_sample_n": len(shap_X),
            "shap_scale": "Uncalibrated histogram gradient boosting log-odds; tree-path-dependent background",
            "local_examples": local,
            "coefficient_uncertainty": "No inferential CIs estimated: penalization and correlated one-hot/engineered features complicate inference; coefficients and odds ratios are descriptive.",
            "limitations": "Correlated features share or obscure importance. Permutation may create implausible combinations; PDP/ICE average over observed covariates and are not interventions. No impurity-based importance used.",
            "model_sha256": meta["model_sha256"],
        },
    )
    log(
        "Stage 8 — PASS",
        "Original-column permutation importance, penalized logistic odds ratios, sampled tree SHAP, three anonymous contribution-only examples and PDP/ICE generated from saved models. No raw feature rows or identifiers exported. Penalized coefficient confidence intervals not estimated; limits stated in artifact.",
    )


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
