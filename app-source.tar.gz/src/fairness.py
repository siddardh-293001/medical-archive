"""Exploratory subgroup reliability; no deployment-safety conclusion."""

from functools import partial
import json
import numpy as np
import pandas as pd
from fairlearn.metrics import MetricFrame
from sklearn.calibration import calibration_curve
from src.config import ROOT, CONFIG
from src.evaluate import test_cohort
from src.validation import target
from src.metrics import metrics
from src.uncertainty import cluster_bootstrap, BOOT_METRICS
from src.theme import apply_mpl_style, save_figure, OXIDE
from src.utils import save_json, log, versions


def metric_value(y_true, y_pred, key, threshold):
    value = metrics(y_true, y_pred, threshold)[key]
    return np.nan if value is None else value


def subgroup_table(y, p, groups, patients, threshold, bootstrap=True):
    keys = ["n", "positive_count", *BOOT_METRICS]
    functions = {key: partial(metric_value, key=key, threshold=threshold) for key in keys}
    frame = MetricFrame(metrics=functions, y_true=np.asarray(y), y_pred=np.asarray(p), sensitive_features=groups)
    table = frame.by_group.rename_axis("group").reset_index()
    table["small_group"] = (table.n < CONFIG["min_group_encounters"]) | (
        table.positive_count < CONFIG["min_group_positives"]
    )
    for i, row in table.iterrows():
        if not bootstrap:
            continue
        take = np.asarray(groups) == row["group"]
        ci = cluster_bootstrap(np.asarray(y)[take], np.asarray(p)[take], np.asarray(patients)[take], threshold)
        table.loc[i, "valid_bootstrap_replicates"] = ci["valid_replicates"]
        for key, interval in ci["intervals"].items():
            table.loc[i, key + "_low"] = interval["low"] if interval else np.nan
            table.loc[i, key + "_high"] = interval["high"] if interval else np.nan
    return table


def main():
    evaluation = json.loads((ROOT / "reports/metrics/test.json").read_text())
    frozen = json.loads((ROOT / "models/frozen_config.json").read_text())
    if evaluation["model_sha256"] != frozen["model_sha256"]:
        raise ValueError("Run make evaluate for the current frozen model first")
    d = test_cohort()
    y = target(d)
    predictions = np.load(ROOT / "data/processed/test_predictions.npz")
    threshold = json.loads((ROOT / "models/frozen_config.json").read_text())["threshold"]
    tables = []
    curves = []
    for analysis in ["primary", "without_demographics"]:
        p = predictions[analysis]
        for column in ["age", "gender", "race"]:
            group = d[column].fillna("Unknown").astype(str)
            print(f"Subgroup bootstrap: {analysis} / {column}", flush=True)
            table = subgroup_table(y, p, group, d.patient_nbr, threshold)
            table["feature"] = column
            table["analysis"] = analysis
            tables.append(table)
            for _, row in table.iterrows():
                if row.small_group:
                    continue
                take = group == row["group"]
                observed, mean = calibration_curve(y[take], p[take], n_bins=5, strategy="quantile")
                for a, b in zip(mean, observed):
                    curves.append(
                        {
                            "analysis": analysis,
                            "feature": column,
                            "group": row["group"],
                            "n": int(row.n),
                            "mean_predicted": a,
                            "observed": b,
                        }
                    )
    table = pd.concat(tables, ignore_index=True)
    table.to_csv(ROOT / "reports/tables/subgroup_metrics.csv", index=False)
    pd.DataFrame(curves).to_csv(ROOT / "reports/tables/subgroup_calibration.csv", index=False)
    apply_mpl_style()
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 3, figsize=(16, 6))
    for ax, column in zip(axes, ["age", "gender", "race"]):
        sub = table[(table.feature == column) & (table.analysis == "primary")].sort_values("group")
        pos = np.arange(len(sub))
        lo = (sub.recall - sub.recall_low).clip(lower=0).fillna(0)
        hi = (sub.recall_high - sub.recall).clip(lower=0).fillna(0)
        ax.errorbar(sub.recall, pos, xerr=[lo, hi], fmt="o", color=OXIDE, capsize=2)
        ax.set_yticks(
            pos,
            [
                f"{r.group}{' *' if r.small_group else ''} (n={int(r.n):,}; +={int(r.positive_count):,})"
                for r in sub.itertuples()
            ],
        )
        ax.set(
            title=column.capitalize(),
            xlabel="Recall · patient-cluster 95% interval",
            ylabel="Group (* insufficient sample)",
            xlim=(0, 1),
        )
        ax.invert_yaxis()
    fig.tight_layout()
    save_figure(fig, "fairness_recall.png")
    plt.close(fig)
    stable = table[(table.analysis == "primary") & (~table.small_group)]
    gaps = {
        c: {m: float(s[m].max() - s[m].min()) for m in ["recall", "fpr", "selection_rate", "calibration_in_large"]}
        for c, s in stable.groupby("feature")
    }
    save_json(
        "reports/metrics/fairness.json",
        {
            "model_sha256": evaluation["model_sha256"],
            "versions": versions(),
            "seed": CONFIG["seed"],
            "bootstrap_replicates": CONFIG["bootstrap_replicates"],
            "minimum_encounters": CONFIG["min_group_encounters"],
            "minimum_positives": CONFIG["min_group_positives"],
            "flagged_group_rows": int(table.small_group.sum()),
            "adequately_sized_primary_gaps": gaps,
            "precision_convention": "Precision and recall use zero_division=0; groups without positive support are flagged, ROC/AP undefined values are blank; invalid bootstrap replicates are counted.",
            "discussion": "Demographic parity concerns selection rates; equalized odds concerns TPR and FPR conditional on outcome; calibration concerns probability reliability. When prevalence differs these criteria generally cannot all be satisfied by imperfect predictors. Coarse historical race categories, coding and measurement bias, unequal access, prevalence and sample size can explain or mask differences. Race/gender inclusion is compared explicitly; omitting them does not remove proxies such as payer, utilization and discharge disposition. Pointwise intervals do not provide simultaneous inference. This analysis does not establish safety or appropriateness for clinical deployment.",
        },
    )
    (ROOT / "reports/fairness_report.md").write_text(
        "# Fairness and reliability\n\n"
        + json.loads((ROOT / "reports/metrics/fairness.json").read_text())["discussion"]
        + "\n\nAll computed group metrics, n, positives, pointwise cluster intervals and flags are in tables/subgroup_metrics.csv. Calibration curves appear only for groups meeting configured sample thresholds. The model without race/gender uses the primary frozen hyperparameters and threshold, with its calibrator fitted on training-only OOF predictions. No fairness mitigation is claimed.\n"
    )
    log(
        "Stage 9 — PASS",
        "Fairlearn MetricFrame subgroup metrics and patient-cluster intervals generated for age, gender and race (Unknown separate), for primary and without-demographics models. Small-group flags, calibration curves and trade-off discussion saved. No safety or fairness certification claimed.",
    )


if __name__ == "__main__":
    main()
