"""Deterministic discharge-time transformations; learned decisions stay in the pipeline."""

import re
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from src.validation import MEDICATIONS

NUMERIC = "time_in_hospital num_lab_procedures num_procedures num_medications number_outpatient number_emergency number_inpatient number_diagnoses".split()
CODES = ["admission_type_id", "admission_source_id", "discharge_disposition_id"]


def diagnosis_group(value):
    if pd.isna(value) or str(value) in ["?", "Unknown", ""]:
        return "Unknown"
    text = str(value).upper()
    if text.startswith("V"):
        return "Supplementary V"
    if text.startswith("E"):
        return "External E"
    try:
        code = float(text)
    except ValueError:
        return "Other"
    if 250 <= code < 251:
        return "Diabetes"
    if 390 <= code < 460 or int(code) == 785:
        return "Circulatory"
    if 460 <= code < 520 or int(code) == 786:
        return "Respiratory"
    if 520 <= code < 580 or int(code) == 787:
        return "Digestive"
    if 580 <= code < 630 or int(code) == 788:
        return "Genitourinary"
    if 710 <= code < 740:
        return "Musculoskeletal"
    if 800 <= code < 1000:
        return "Injury"
    if 140 <= code < 240:
        return "Neoplasms"
    return "Other"


class FeatureBuilder(BaseEstimator, TransformerMixin):
    def __init__(self, mappings=None, drop_columns=(), utilization_only=False, near_constant=0.995):
        self.mappings = mappings
        self.drop_columns = drop_columns
        self.utilization_only = utilization_only
        self.near_constant = near_constant

    def _build(self, X):
        d = X.drop(
            columns=["encounter_id", "patient_nbr", "readmitted", "weight", *self.drop_columns], errors="ignore"
        ).copy()
        if self.utilization_only:
            return d[["number_inpatient", "number_emergency", "number_outpatient"]].astype(float)
        d["age_ordinal"] = d.age.map(
            lambda x: int(re.search(r"\d+", str(x)).group()) // 10 if re.search(r"\d+", str(x)) else np.nan
        )
        d = d.drop(columns="age")
        for col in ["diag_1", "diag_2", "diag_3"]:
            d[col + "_group"] = d[col].map(diagnosis_group)
            d = d.drop(columns=col)
        for col in CODES:
            if col not in d:
                continue
            mapping = (self.mappings or {}).get(col, {})

            def collapse(x):
                if pd.isna(x):
                    return "Unknown"
                text = mapping.get(int(x), str(x))
                return "Unknown" if text.lower() in ["null", "not available", "not mapped", "unknown/invalid"] else text

            d[col] = d[col].map(collapse)
        d["total_prior_visits"] = d[["number_inpatient", "number_emergency", "number_outpatient"]].sum(axis=1)
        d["prior_inpatient_burden"] = (d.number_inpatient > 0).astype(int)
        d["prior_emergency_burden"] = (d.number_emergency > 0).astype(int)
        d["stay_band"] = pd.cut(d.time_in_hospital, [0, 3, 7, 14], labels=["1–3 days", "4–7 days", "8–14 days"]).astype(
            str
        )
        available = [c for c in MEDICATIONS if c in d]
        d["medications_up"] = (d[available] == "Up").sum(axis=1)
        d["medications_down"] = (d[available] == "Down").sum(axis=1)
        d["medication_change_count"] = d.medications_up + d.medications_down
        d["A1C_tested"] = (d.A1Cresult != "None").astype(int)
        for col in d.select_dtypes(include=["object", "string"]):
            d[col] = d[col].fillna("Unknown").astype(str)
        return d

    def fit(self, X, y=None):
        built = self._build(X)
        self.removed_ = [
            c for c in built if built[c].value_counts(normalize=True, dropna=False).iloc[0] >= self.near_constant
        ]
        self.columns_ = [c for c in built if c not in self.removed_]
        self.feature_names_in_ = np.array(X.columns)
        return self

    def transform(self, X):
        return self._build(X)[self.columns_]

    def get_feature_names_out(self, input_features=None):
        return np.array(self.columns_)
