"""Strict local research inference. Load only trusted joblib artifacts."""

import json
from numbers import Real
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from src.config import ROOT
from src.utils import sha256

NOTICE = "Experimental, not for clinical use. No medical recommendation."


def load_model(model_dir=None):
    directory = Path(model_dir) if model_dir else ROOT / "models"
    meta = json.loads((directory / "metadata.json").read_text())
    path = directory / "pipeline.joblib"
    if sha256(path) != meta["model_sha256"]:
        raise ValueError("Model SHA-256 mismatch: refusing to deserialize")
    return joblib.load(path), meta


def validate_record(record, schema):
    if not isinstance(record, dict):
        raise ValueError("Encounter must be a dictionary")
    missing = set(schema) - set(record)
    extra = set(record) - set(schema)
    if missing or extra:
        raise ValueError(
            f"Missing fields: {sorted(missing)}; unexpected fields: {sorted(extra)}. IDs and outcomes are prohibited."
        )
    result = {}
    for name, rule in schema.items():
        value = record[name]
        if value is None:
            if not rule["missing_allowed"]:
                raise ValueError(f"{name}: missing is not allowed")
            result[name] = np.nan
            continue
        if rule["type"] == "integer":
            if isinstance(value, bool) or not isinstance(value, Real) or not np.isfinite(value) or int(value) != value:
                raise ValueError(f"{name}: expected a finite integer")
            if not rule["minimum"] <= value <= rule["maximum"]:
                raise ValueError(f"{name}: outside training envelope [{rule['minimum']}, {rule['maximum']}]")
            if "allowed_values" in rule and int(value) not in rule["allowed_values"]:
                raise ValueError(
                    f"{name}: unseen administrative code {value}; permitted codes: {rule['allowed_values']}"
                )
            result[name] = int(value)
        else:
            if not isinstance(value, str) or value not in rule["values"]:
                raise ValueError(f"{name}: unseen category {value!r}; permitted categories: {rule['values']}")
            result[name] = value
    return pd.DataFrame([result])


def predict_encounter(record: dict, model_dir=None):
    model, meta = load_model(model_dir)
    frame = validate_record(record, meta["feature_schema"])
    probability = float(model.predict_proba(frame)[0, 1])
    if not 0 <= probability <= 1:
        raise ValueError("Model returned an invalid probability")
    return {
        "probability": probability,
        "class": int(probability >= meta["threshold"]),
        "threshold": meta["threshold"],
        "model_version": meta["model_version"],
        "notice": NOTICE,
    }
