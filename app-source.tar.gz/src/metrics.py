import numpy as np
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    precision_score,
    recall_score,
    f1_score,
    brier_score_loss,
    confusion_matrix,
)


def metrics(y, p, t=0.5):
    y = np.asarray(y)
    p = np.asarray(p)
    pred = (p >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()

    def divide(a, b):
        return float(a / b) if b else None

    return {
        "n": len(y),
        "positive_count": int(y.sum()),
        "prevalence": float(y.mean()),
        "roc_auc": float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else None,
        "average_precision": float(average_precision_score(y, p)) if y.sum() else None,
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "specificity": divide(tn, tn + fp),
        "fpr": divide(fp, tn + fp),
        "fnr": divide(fn, fn + tp),
        "selection_rate": float(pred.mean()),
        "brier": float(brier_score_loss(y, p)),
        "calibration_in_large": float(p.mean() - y.mean()),
        "confusion_matrix": [[int(tn), int(fp)], [int(fn), int(tp)]],
        "threshold": float(t),
    }
