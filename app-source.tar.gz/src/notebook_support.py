"""Narrative notebook views. All computation lives in src; only aggregate artifacts display."""

import json
import pandas as pd
from src.config import ROOT
from src.data_loader import ensure_dataset

ARTIFACTS = {
    "01_understanding": "reports/tables/data_quality.json",
    "02_exploration": "reports/tables/eda_groups.csv",
    "03_preprocessing": "reports/tables/feature_removal.json",
    "04_validation": "reports/metrics/training.json",
    "05_modeling": "reports/model_comparison.csv",
    "06_evaluation": "reports/tables/test_metrics.csv",
    "07_explainability_fairness": "reports/tables/subgroup_metrics.csv",
}


def show_stage(name):
    ensure_dataset()
    path = ROOT / ARTIFACTS[name]
    if not path.exists():
        raise RuntimeError("Saved study artifacts missing. Run make all first.")
    if path.suffix == ".csv":
        return pd.read_csv(path)
    return json.loads(path.read_text())
