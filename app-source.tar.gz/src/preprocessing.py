from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from src.feature_engineering import FeatureBuilder
from src.config import CONFIG


def pipeline(model, mappings, scale=False, drop_columns=(), utilization_only=False):
    numeric = [("impute", SimpleImputer(strategy="median", keep_empty_features=True))]
    if scale:
        numeric.append(("scale", StandardScaler()))
    categorical = Pipeline(
        [
            ("impute", SimpleImputer(strategy="constant", fill_value="Unknown")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", min_frequency=0.005, sparse_output=False)),
        ]
    )
    pre = ColumnTransformer(
        [
            ("numeric", Pipeline(numeric), make_column_selector(dtype_include="number")),
            ("category", categorical, make_column_selector(dtype_exclude="number")),
        ],
        sparse_threshold=0,
    )
    return Pipeline(
        [
            ("features", FeatureBuilder(mappings, drop_columns, utilization_only, CONFIG["near_constant_fraction"])),
            ("preprocess", pre),
            ("model", model),
        ]
    )
