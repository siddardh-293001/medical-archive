"""Quality tables and eligibility accounting, all from validated real data."""

import pandas as pd
from src.config import ROOT
from src.data_loader import ensure_dataset, read_mappings
from src.validation import read_data, target
from src.utils import save_json, log, versions


def eligible(df, mappings):
    descriptions = mappings["discharge_disposition_id"]
    excluded_ids = [k for k, v in descriptions.items() if "expired" in v.lower() or "hospice" in v.lower()]
    if not excluded_ids:
        raise ValueError("No expired/hospice descriptions in mapping: inspect source")
    excluded = df.discharge_disposition_id.isin(excluded_ids)
    return df.loc[~excluded].copy(), df.loc[excluded].groupby("discharge_disposition_id").size().rename(
        "n"
    ).reset_index().assign(description=lambda d: d.discharge_disposition_id.map(descriptions))


def load_cohort():
    path = ensure_dataset()
    return eligible(read_data(path), read_mappings(path.parent / "IDS_mapping.csv"))[0]


def main():
    (ROOT / "reports/tables").mkdir(parents=True, exist_ok=True)
    path = ensure_dataset()
    df = read_data(path)
    mappings = read_mappings(path.parent / "IDS_mapping.csv")
    cohort, excluded = eligible(df, mappings)
    assert len(df) - excluded.n.sum() == len(cohort)
    excluded.to_csv(ROOT / "reports/tables/exclusions.csv", index=False)
    quality = pd.DataFrame(
        {
            "column": df.columns,
            "dtype": df.dtypes.astype(str).values,
            "missing_n": df.isna().sum().values,
            "missing_rate": df.isna().mean().values,
            "cardinality": df.nunique().values,
        }
    )
    quality.to_csv(ROOT / "reports/tables/data_quality.csv", index=False)
    df.assign(binary=target(df)).groupby("binary").apply(lambda x: x.isna().mean(), include_groups=False).to_csv(
        ROOT / "reports/tables/missingness_by_target.csv"
    )
    df.groupby("patient_nbr").size().value_counts().sort_index().rename_axis("encounters_per_patient").rename(
        "patients"
    ).to_csv(ROOT / "reports/tables/encounter_distribution.csv")
    summary = {
        "raw_rows": len(df),
        "columns": len(df.columns),
        "unique_patients": df.patient_nbr.nunique(),
        "unique_encounters": df.encounter_id.nunique(),
        "duplicates": df.encounter_id.duplicated().sum(),
        "excluded": int(excluded.n.sum()),
        "modeling_rows": len(cohort),
        "modeling_patients": cohort.patient_nbr.nunique(),
        "invalid_gender_n": int((df.gender == "Unknown/Invalid").sum()),
        "target_counts": df.readmitted.value_counts().to_dict(),
        "raw_prevalence": target(df).mean(),
        "eligible_prevalence": target(cohort).mean(),
        "versions": versions(),
    }
    invalid = {}
    for c in [
        "time_in_hospital",
        "num_lab_procedures",
        "num_procedures",
        "num_medications",
        "number_outpatient",
        "number_emergency",
        "number_inpatient",
        "number_diagnoses",
    ]:
        invalid[c] = int((pd.to_numeric(df[c], errors="coerce").isna() | (df[c] < 0)).sum())
    invalid["time_in_hospital_outside_1_14"] = int((~df.time_in_hospital.between(1, 14)).sum())
    for c in mappings:
        invalid[c + "_unmapped"] = int((~df[c].isin(mappings[c])).sum())
    summary["invalid_values"] = invalid
    save_json("reports/tables/data_quality.json", summary)
    rows = [
        "# Feature availability at discharge",
        "",
        "Diagnosis coding may be finalized after discharge; availability is uncertain in live practice.",
        "",
        "| Column | Available | Used | Reason |",
        "|---|---|---|---|",
    ]
    for c in df:
        used = c not in ["encounter_id", "patient_nbr", "readmitted", "weight"]
        reason = (
            "Research predictor; fold-specific near-constant filtering applies"
            if used
            else "Identifier/outcome excluded"
            if c != "weight"
            else "Overwhelming missingness"
        )
        if c in ["payer_code", "medical_specialty"]:
            reason = "Unknown versus dropping sensitivity comparison; payer may proxy access and demographics"
        if c == "discharge_disposition_id":
            reason = "Known at discharge; strong process-related feature; exclusion sensitivity run"
        rows.append(
            f"| {c} | {'uncertain' if c.startswith('diag_') else 'no' if c == 'readmitted' else 'yes'} | {'yes' if used else 'no'} | {reason} |"
        )
    (ROOT / "docs/FEATURE_AVAILABILITY.md").write_text("\n".join(rows) + "\n")
    dictionary = [
        "# Observed data dictionary",
        "",
        "Generated from the validated source. Original definitions: UCI dataset 296. See FEATURE_AVAILABILITY.md and FEATURE_ENGINEERING.md for prediction-time use and derived features.",
        "",
        "Literal None in laboratory fields means not tested. Prior visit counts describe the preceding year and are not adjusted. No patient-level rows are exported.",
        "",
        "| Column | Observed dtype | Distinct values | Missing n | Missing rate |",
        "|---|---|---:|---:|---:|",
    ]
    for row in quality.itertuples(index=False):
        dictionary.append(
            f"| {row.column} | {row.dtype} | {row.cardinality:,} | {row.missing_n:,} | {row.missing_rate:.2%} |"
        )
    (ROOT / "docs/DATA_DICTIONARY.md").write_text("\n".join(dictionary) + "\n")
    log(
        "Stage 2 — PASS",
        "Generated data-quality, missingness, cardinality, invalid-value and encounter-distribution tables. Exclusion accounting reconciles exactly. Feature availability documented per source column.",
    )
    print(summary)


if __name__ == "__main__":
    main()
