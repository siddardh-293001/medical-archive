"""Generate prose and publication tables only from saved, executed artifacts."""

import html
import json
import re
import pandas as pd
from src.config import ROOT, CONFIG
from src.theme import INK, PAPER, AGED_PAPER, RULE, OCHRE
from src.utils import log, save_json, versions, now


def read(path):
    return json.loads((ROOT / path).read_text())


def md_table(frame, columns=None):
    frame = frame[columns] if columns else frame

    def cell(v):
        if isinstance(v, float):
            return f"{v:.4f}"
        return str(v).replace("|", "/")

    return "\n".join(
        [
            "| " + " | ".join(frame.columns) + " |",
            "| " + " | ".join(["---"] * len(frame.columns)) + " |",
            *["| " + " | ".join(cell(v) for v in row) + " |" for row in frame.itertuples(index=False, name=None)],
        ]
    )


def inline(text):
    text = html.escape(text)
    text = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"`(.*?)`", r"<code>\1</code>", text)
    return re.sub(r"\[(.*?)\]\((.*?)\)", r'<a href="\2">\1</a>', text)


def render_html(markdown):
    lines = markdown.splitlines()
    out = []
    in_table = False
    in_list = False
    for line in lines:
        if line.startswith("| "):
            if not in_table:
                out.append("<table>")
                in_table = True
                tag = "th"
            else:
                tag = "td"
            if set(line.replace("|", "").replace("-", "").strip()) == set():
                continue
            out.append(
                "<tr>" + "".join(f"<{tag}>{inline(v.strip())}</{tag}>" for v in line.strip("|").split("|")) + "</tr>"
            )
            continue
        if in_table:
            out.append("</table>")
            in_table = False
        if line.startswith("- "):
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append("<li>" + inline(line[2:]) + "</li>")
            continue
        if in_list:
            out.append("</ul>")
            in_list = False
        if line.startswith("!["):
            match = re.match(r"!\[(.*?)\]\((.*?)\)", line)
            out.append(
                f'<figure><img alt="{html.escape(match[1])}" src="{html.escape(match[2])}"><figcaption>{html.escape(match[1])}</figcaption></figure>'
            )
        elif line.startswith("#"):
            n = len(line) - len(line.lstrip("#"))
            out.append(f"<h{n}>{inline(line[n:].strip())}</h{n}>")
        elif line.strip():
            out.append("<p>" + inline(line) + "</p>")
    if in_table:
        out.append("</table>")
    if in_list:
        out.append("</ul>")
    css = f"""body{{background:{PAPER};color:{INK};font:16px/1.55 Georgia,serif;max-width:960px;margin:50px auto;padding:0 24px}}h1{{font-size:42px;font-weight:400;line-height:1.1}}h2{{border-top:1px solid {RULE};padding-top:20px;font-weight:400}}h3{{font-weight:400}}table{{border-collapse:collapse;width:100%;font:12px/1.5 monospace;margin:20px 0}}th{{background:{AGED_PAPER};text-align:left}}td,th{{border-bottom:1px solid {RULE};padding:7px}}td:not(:first-child){{text-align:right}}a{{color:{INK};text-decoration-color:{OCHRE}}}img{{width:100%;height:auto}}figcaption{{font:12px monospace}}code{{font-family:monospace}}@page{{size:A4;margin:16mm}}@media print{{body{{margin:0;padding:0;font-size:10.5pt;line-height:1.45}}h1{{font-size:28pt}}h2{{break-before:page;padding-top:0;border-top:0}}h3,figure,table{{break-inside:avoid}}img{{max-height:72mm;object-fit:contain}}a{{text-decoration:none}}}}"""
    return (
        '<!doctype html><html lang="en"><meta charset="utf-8"><title>The Medical Archive · Technical report</title><style>'
        + css
        + "</style><body>"
        + "\n".join(out)
        + "</body></html>"
    )


def main():
    q = read("reports/tables/data_quality.json")
    test = read("reports/metrics/test.json")
    train = read("reports/metrics/training.json")
    cal = read("reports/metrics/calibration.json")
    explain = read("reports/metrics/explanations.json")
    fair = read("reports/metrics/fairness.json")
    meta = read("models/metadata.json")
    removal = read("reports/tables/feature_removal.json")
    m = test["primary"]["frozen"]
    default = test["primary"]["default"]
    ci = test["primary"]["uncertainty_frozen"]
    comparison = pd.read_csv(ROOT / "reports/model_comparison.csv")
    selected = comparison.set_index("model").loc[train["selected_model"]]
    missing = pd.read_csv(ROOT / "reports/tables/data_quality.csv").set_index("column")
    statistics = pd.read_csv(ROOT / "reports/tables/eda_statistics.csv")
    imp = pd.read_csv(ROOT / "reports/tables/permutation_importance.csv")
    subgroup = pd.read_csv(ROOT / "reports/tables/subgroup_metrics.csv")
    exclusions = pd.read_csv(ROOT / "reports/tables/exclusions.csv")
    groups = pd.read_csv(ROOT / "reports/tables/eda_groups.csv")
    costs = pd.read_csv(ROOT / "reports/tables/cost_sensitivity.csv")

    def interval(k):
        r = ci["intervals"][k]
        return f"{m[k]:.3f} (95% cluster interval {r['low']:.3f}–{r['high']:.3f})"

    blocks = []
    blocks.append(f"""# The Medical Archive
Predicting 30-Day Hospital Readmission Among Patients With Diabetes Using Machine Learning, Explainable AI, and Fairness Analysis
**Educational predictive research. Not a validated clinical decision-support system.**
Generated from saved artifacts at {now()}. The immutable experiment freeze is {test["frozen_utc"]}; test evaluation began {test["evaluation_started_utc"]}. No metric was manually transcribed.
### Abstract
We studied discharge-time prediction of readmission within 30 days using the UCI historical diabetes encounter dataset. After mapping-verified death/hospice exclusions, the eligible cohort contained {q["modeling_rows"]:,} encounters from {q["modeling_patients"]:,} patients. A patient-disjoint holdout and grouped training validation compared simple utilization, logistic and tree-based models against a dummy baseline. The selected {train["selected_model"]} model used {cal["chosen_method"]} calibration and a threshold selected from training OOF predictions. On {m["n"]:,} holdout encounters, ROC-AUC was {interval("roc_auc")} and average precision {interval("average_precision")}, with prevalence {m["prevalence"]:.3f}. At the frozen threshold, recall was {m["recall"]:.3f}, precision {m["precision"]:.3f} and Brier score {m["brier"]:.4f}. Explanations and subgroup analysis characterize associations and uncertainty; they do not establish causal effects, fairness, clinical utility or deployment safety.
### Introduction and research objectives
Hospital readmission is a meaningful retrospective outcome, but the information recorded during an encounter mixes disease burden, previous utilization, administrative practice and measurement processes. A predictive study must distinguish this information from knowledge available only after the outcome. The prediction setting here is discharge, not admission. The original dataset and Strack et al. study provide the source context [1,2]; their published study design and estimates are not treated as direct benchmarks for this experiment.
The objectives are to assess incremental signal beyond prior utilization, compare ranking with probability reliability, expose threshold-dependent error burdens, explain saved model behavior and describe uncertainty across demographic groups. None of these objectives is an intervention study. No treatment or care recommendation is generated from a score. A useful educational result may be modest performance accompanied by a clear account of what cannot be inferred.
""")
    blocks.append(f"""## Dataset and methods
The UCI Diabetes 130-US Hospitals for Years 1999–2008 dataset [1] is licensed CC BY 4.0. The validated source contains {q["raw_rows"]:,} rows, {q["columns"]} columns and {q["unique_patients"]:,} patients. Encounter identifiers are unique; observed duplicates: {q["duplicates"]}. The source file is checked against a locally calculated SHA-256 manifest on every load. The direct official ZIP route has retries, staged writes, CRC and member checks, fixed-name extraction and schema validation; ucimlrepo is a fallback, with manual placement required when the original mapping cannot be obtained.
The binary target is one for `<30` and zero for both `>30` and `NO`. The prediction unit is an encounter. Death/hospice discharges are excluded using descriptions in IDS_mapping.csv rather than unverified IDs. This removes {q["excluded"]:,} records; {q["raw_rows"]:,} minus {q["excluded"]:,} equals {q["modeling_rows"]:,}. The observed exclusion ledger is below.
{md_table(exclusions)}
Literal `?` becomes missing before counting. Literal `None` in A1C/glucose fields remains not-tested, rather than being conflated with missing or normal. Weight missingness is {missing.loc["weight", "missing_rate"]:.2%}; payer-code missingness {missing.loc["payer_code", "missing_rate"]:.2%}; specialty missingness {missing.loc["medical_specialty", "missing_rate"]:.2%}. Weight is removed; payer and specialty retention with explicit Unknown is compared against dropping them. Race Unknown is retained, and {q["invalid_gender_n"]} Unknown/Invalid gender rows are retained as a distinct category.
Every source column has a discharge-availability entry in docs/FEATURE_AVAILABILITY.md. Diagnoses may be finalized after discharge in practice, so their operational availability is uncertain. Discharge disposition is known at discharge but may encode process and access effects. Identifiers and the target never enter the feature matrix. Prior visit counts already cover the preceding year and are not decremented.
The outer split uses the first seeded StratifiedGroupKFold partition from {CONFIG["test_folds"]} folds [3]. Inner model comparison uses {CONFIG["cv_folds"]} folds on training patients. Assertions prohibit overlap across patient groups. Training prevalence is {test["training_prevalence"]:.2%}; holdout prevalence is {m["prevalence"]:.2%}. Group stratification approximates, rather than guarantees, encounter-level balance. Dates and hospital IDs are absent: this is neither temporal validation nor hospital-cluster validation.
""")
    eda_lines = []
    for col in ["age", "race", "gender"]:
        s = groups[(groups.feature == col) & (groups.n >= CONFIG["min_group_encounters"])]
        low = s.loc[s.rate.idxmin()]
        high = s.loc[s.rate.idxmax()]
        eda_lines.append(
            f"For {col}, descriptive groups meeting the encounter-count filter ranged from {low.rate:.1%} ({low['group']}, n={int(low.n):,}) to {high.rate:.1%} ({high['group']}, n={int(high.n):,})."
        )
    top_effect = statistics.loc[statistics.effect.abs().nlargest(3).index]
    blocks.append(f"""## Exploratory analysis
{" ".join(eda_lines)} These are unadjusted encounter-level comparisons; they can reflect case mix, utilization, coding, access and repeated encounters. They do not imply that demographic attributes cause readmission. The complete table includes smaller groups and Wilson intervals. Demographic summaries are a starting point for reliability assessment rather than a reason to exclude groups.
The EDA uses chi-square tests with Cramér's V for categorical features and Mann–Whitney U tests with rank-biserial effects for numeric features. Benjamini–Hochberg correction is applied across the declared family of {len(statistics)} tests. The following are the largest observed absolute effects in that family; effect-size scales differ by test and should not be compared as identical quantities.
{md_table(top_effect, ["feature", "test", "effect", "effect_name", "q_bh"])}
Large sample size can make small associations statistically detectable. Chi-square assumes independent observations and adequate expected cells; the table records low expected-cell counts. Mann–Whitney is a rank/distribution comparison, not automatically a test of medians. Repeated encounters weaken independence assumptions. EDA Wilson intervals are therefore labeled descriptive; final model uncertainty uses patient clusters. Statistical significance alone does not select a feature or establish practical importance.
![Recorded utilization by outcome; subgroup encounter counts appear above bars.](figures/eda_utilization.png)
Prior utilization, diagnoses, length of stay, laboratory-test recording and treatment-change patterns are candidate predictive information. These variables are available during the discharge process, but each can reflect clinical complexity and care processes. The complete EDA report, numeric summaries, missingness by target and categorical cardinalities are saved separately. Missingness is not assumed to be random, and observed test ordering is not interpreted as a normal laboratory result.
""")
    blocks.append(f"""## Modeling methodology
A scikit-learn Pipeline contains deterministic feature construction, fold-fitted near-constant filtering, a ColumnTransformer and the estimator. Numeric inputs receive median imputation; logistic models additionally use StandardScaler. Trees receive no scaling. Skew is retained rather than choosing an unvalidated transformation. Categorical inputs receive explicit Unknown handling and one-hot encoding with unseen-category tolerance and fold-fitted infrequent-category pooling. The strict inference API separately rejects unseen inputs to make extrapolation visible.
Engineered features include total prior visits, indicators of prior inpatient/emergency use, coarse length-of-stay bands, separate ICD-9 diagnosis groups, counts of recorded medication dose increases/decreases, total medication-change count and an A1C-tested indicator. Age brackets become ordered decades, not exact ages. V and E diagnosis codes are handled explicitly. Detailed definitions, code ranges, rationale and availability limits appear in docs/FEATURE_ENGINEERING.md. No target encoding or resampling is used. The final fitted removal list is: {", ".join(removal["fold_fitted_final_removals"])}.
Each non-dummy candidate receives a fixed randomized search budget of {CONFIG["tuning_iterations"]} configurations with average precision scoring. Full search spaces, chosen hyperparameters, fold metrics, fitting time and inference time are in the training artifact. Random forest depth/leaf constraints and histogram-boosting leaf/regularization constraints limit complexity. Balanced logistic regression is compared with its unweighted counterpart; weighting is not assumed to preserve probability calibration.
{md_table(comparison, ["model", "average_precision", "brier", "fold_ap_sd", "mean_train_ap"])}
At the default threshold, the explicit imbalance comparison is below. Class weighting changes the probability scale and error burden; it is not treated as calibration-preserving.
{md_table(comparison[comparison.model.isin(["logistic", "logistic_balanced"])], ["model", "precision", "recall", "brier", "calibration_in_large"])}
Selection considers models within the configured AP tolerance of the best and chooses the lowest Brier score, with a documented tie rule. The selected model's mean training AP is {selected.mean_train_ap:.3f}, versus OOF AP {selected.average_precision:.3f}; its fold AP standard deviation is {selected.fold_ap_sd:.3f}. This gap cautions against interpreting fitting performance as generalization. Search and OOF model comparison reuse training folds, so selection estimates remain optimistic even though patient leakage is prevented. The untouched holdout is the final evaluation; a fully nested model-search comparison would be a useful future extension.
""")
    calframe = pd.DataFrame(cal["methods"]).T.reset_index().rename(columns={"index": "method"})
    sensitivity = []
    for name, values in test["sensitivity"].items():
        sensitivity.append(
            {
                "analysis": name,
                **{
                    k: values["frozen"][k]
                    for k in ["n", "average_precision", "roc_auc", "recall", "precision", "brier"]
                },
            }
        )
    blocks.append(f"""## Calibration, thresholds and final results
Uncalibrated, sigmoid and isotonic probabilities are compared in nested grouped training validation [4]. For each outer training-validation fold, calibrators learn from inner OOF predictions; the outer validation labels are not available to that fitting step. The final calibrator uses full training OOF probabilities, and the underlying estimator is fitted on all training encounters. The selected calibration method is {cal["chosen_method"]}.
{md_table(calframe, ["method", "average_precision", "brier"])}
The maximum-F1 training rule freezes threshold {meta["threshold"]:.6f}. Alternative rules target recall subject to a minimum precision or minimize hypothetical false-negative/false-positive costs. The latter sensitivity table is below; these ratios are parameters, not measured clinical costs. Feasibility of the constrained-recall rule is explicitly recorded in the calibration JSON. No rule is clinically optimal on this evidence.
{md_table(costs, ["false_negative_cost_ratio", "threshold", "precision", "recall", "selection_rate"])}
The final holdout comprises {m["n"]:,} encounters from {test["test_patients"]:,} patients. ROC-AUC is {interval("roc_auc")}; average precision is {interval("average_precision")}. AP is sklearn.metrics.average_precision_score [5], distinct from trapezoidal PR area; its no-skill prevalence reference is {m["prevalence"]:.3f}. Frozen-threshold recall is {interval("recall")}, precision {interval("precision")}, and Brier {interval("brier")}. Intervals use {ci["valid_replicates"]} valid of {ci["requested_replicates"]} patient-cluster bootstrap replicates with seed {ci["seed"]}. Each sampled patient brings all encounters; intervals are percentile, pointwise and conditional on the fitted selected model, not uncertainty over every modeling choice.
At 0.50, recall is {default["recall"]:.3f} and precision {default["precision"]:.3f}. At the frozen threshold, {m["confusion_matrix"][1][1]:,} positive encounters are flagged, {m["confusion_matrix"][1][0]:,} are missed, and {m["confusion_matrix"][0][1]:,} comparison encounters are flagged. Selection rate is {m["selection_rate"]:.1%}. These counts make the burden visible; better recall is not automatically a useful decision policy.
![Holdout ROC, precision–recall and quantile-bin calibration curves.](figures/test_curves.png)
{md_table(pd.DataFrame(sensitivity))}
Sensitivity models retain primary hyperparameters and threshold; the selected calibration method is fitted on each variant's training OOF predictions. First encounter means first eligible record in supplied file order, not verified chronology. Feature-removal differences describe dependence on information under this design; they do not identify a causal or fairness effect.
""")
    blocks.append(f"""## Explainability
Original-feature permutation importance is evaluated on a seeded heldout sample of {explain["permutation_sample_n"]:,} encounters with {explain["permutation_repeats"]} permutations. Each original column is permuted before feature construction, so all derived and one-hot consequences move together. The largest observed AP decreases are associated with {", ".join(imp.head(3).feature)}. This ranking is conditional on the fitted model, sample and correlated inputs; it does not imply that changing these variables would improve outcomes.
![Original-feature permutation importance; bars show permutation-repeat standard deviations.](figures/permutation_importance.png)
Penalized logistic coefficients and odds ratios are saved for standardized numeric and encoded categorical features. They are descriptive conditional associations. Inferential confidence intervals were not estimated because penalization, correlated engineered features and one-hot coding complicate a defensible interpretation; no unsupported significance claim is made.
Tree SHAP [6] uses {explain["shap_sample_n"]} sampled heldout encounters and the uncalibrated histogram-boosting model. Contributions are in tree log-odds with a tree-path-dependent background. The sigmoid/isotonic mapping is not additively explained by those values; primary calibrated probabilities are presented separately. Three anonymous examples span the sampled predicted-probability ordering and show top contributions without source identifiers or raw feature rows.
Partial dependence and ICE vary prior inpatient visits, length of stay and diagnosis count while holding the sampled covariates fixed. These visualizations show model behavior, not interventions, and may create unusual covariate combinations. Correlated features can dilute permutation importance or redistribute SHAP attribution. Impurity importance is not used. Explanation agreement is not evidence of causal validity or clinical appropriateness.
""")
    races = subgroup[(subgroup.analysis == "primary") & (subgroup.feature == "race")]
    gap_text = "; ".join(
        f"{name}: recall range {vals['recall']:.3f}, FPR range {vals['fpr']:.3f}"
        for name, vals in fair["adequately_sized_primary_gaps"].items()
    )
    blocks.append(f"""## Fairness and reliability
Fairlearn MetricFrame [7] computes subgroup n, positives, prevalence, selection rate, recall, FPR, FNR, precision, specificity, ROC-AUC and calibration-in-the-large for age, gender and race. Unknown race is separate. Calibration-in-the-large is defined here as mean predicted probability minus observed prevalence; positive values indicate overprediction. Probability-calibration curves are generated only where support meets the configured encounter and positive-count thresholds. Every group has pointwise patient-cluster bootstrap intervals where estimable; invalid one-class resamples are skipped and their valid-replicate counts are recorded.
{md_table(races, ["group", "n", "positive_count", "prevalence", "recall", "fpr", "precision", "small_group"])}
Across sufficiently supported primary groups, computed point-estimate ranges are {gap_text}. These descriptive gaps are not adjusted causal disparities or simultaneous significance tests. Groups below {fair["minimum_encounters"]} encounters or {fair["minimum_positives"]} positives are flagged rather than used to support strong conclusions. Undefined ROC/AP values are blank, and precision/recall use the explicitly documented zero-division convention.
Demographic parity asks about selection rates; equalized odds asks about conditional TPR/FPR; calibration asks whether scores correspond to observed outcomes. For imperfect predictors these criteria generally cannot all hold when prevalence differs. Choosing a criterion requires context and stakeholder judgments that this educational analysis cannot supply. Differences may reflect prevalence, sample size, historical access, measurement, coding and unmeasured severity.
The frozen model without race/gender is evaluated both overall and within the same groups. Removing those columns does not remove utilization, payer or discharge proxies. The comparison is an information-sensitivity analysis, not proof that either inclusion or omission is fair. Historical race categories are coarse, recorded during an earlier era and unsuitable for claims of biological causation. This analysis does not establish safety or appropriateness for deployment.
""")
    blocks.append("""## Discussion, limitations and conclusion
The models contain predictive signal beyond a simple utilization benchmark under this patient-grouped design, while the final threshold exposes meaningful false-positive and missed-positive burdens. Probability reliability and precision–recall performance are more informative for the stated objective than accuracy alone. The results support a limited claim about retrospective prediction in this dataset, not a claim about better patient outcomes from model use.
Patient grouping prevents one patient's encounters appearing on both sides of a split, but does not address unmeasured hospital effects, unobserved calendar drift or dependence beyond recorded patient identity. The historical cohort may differ substantially from current practice. Diagnosis coding can be finalized after discharge, and some discharge fields may not be operationally available at the moment a real system would need them. Excluding death/hospice encounters creates a defined eligible population and limits transportability outside it.
Hyperparameter budgets are modest and selection estimates share training folds. Calibration selection and thresholds can still be unstable under new prevalence or practice patterns. Cluster bootstrap intervals condition on the chosen model and cannot capture dataset collection bias, unmeasured variables or all model-search uncertainty. The source lacks comprehensive socioeconomic and care-process information. Protected-attribute comparisons are coarse, pointwise and exploratory; small-group flags do not solve missing representation.
This repository is intended to make limitations inspectable: source hashes, seeds, package versions, availability decisions, removal logs, frozen metadata and test ordering are explicit. The dashboard reads only saved aggregate artifacts and never downloads data or retrains. Model files are local and ignored by Git. The inference loader checks SHA-256 before deserialization, rejects unseen categories and invalid ranges, and warns that trusted artifact provenance is still necessary because joblib can execute code.
Future work should begin with external, current and prospectively available data, a clearly specified decision context, patient and clinician input, and evaluation of operational burden and subgroup harms. A fully nested search comparison and stronger uncertainty over model selection could further qualify retrospective conclusions. No optional clinical deployment, causal estimate or fairness mitigation is claimed here. The current outcome is a reproducible educational analysis whose modest predictive results and uncertainty are reported without optimizing for an impressive score.
### References and provenance
- [1] Clore, J., Cios, K., DeShazo, J. & Strack, B. (2014). Diabetes 130-US Hospitals for Years 1999–2008. UCI Machine Learning Repository. [Dataset and CC BY 4.0 license](https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999+2008), [doi:10.24432/C5230J](https://doi.org/10.24432/C5230J).
- [2] Strack, B., DeShazo, J. P., Gennings, C., Olmo, J. L., Ventura, S., Cios, K. J. & Clore, J. N. (2014). Impact of HbA1c Measurement on Hospital Readmission Rates: Analysis of 70,000 Clinical Database Patient Records. BioMed Research International, 2014, Article 781670. [doi:10.1155/2014/781670](https://doi.org/10.1155/2014/781670).
- [3] scikit-learn documentation. [StratifiedGroupKFold](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.StratifiedGroupKFold.html).
- [4] scikit-learn documentation. [Probability calibration](https://scikit-learn.org/stable/modules/calibration.html).
- [5] scikit-learn documentation. [average_precision_score](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html).
- [6] SHAP documentation. [TreeExplainer](https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html).
- [7] Fairlearn documentation. [MetricFrame](https://fairlearn.org/main/api_reference/generated/fairlearn.metrics.MetricFrame.html).
All references above were checked against UCI, the publisher DOI page or official documentation during the build. Exact runtime versions are recorded in reports/metrics/test.json and requirements-lock.txt; online documentation can describe newer releases than the pinned runtime. API behavior was verified by execution against installed versions.
""")
    markdown = "\n\n".join(blocks)
    (ROOT / "reports/final_report.md").write_text(markdown + "\n")
    (ROOT / "reports/final_report.html").write_text(render_html(markdown))
    summary = f"""<!-- GENERATED RESULTS -->
## Executed results
Generated from `reports/metrics/test.json`; patient-disjoint holdout n={m["n"]:,}, prevalence {m["prevalence"]:.3f}.

| Metric | Frozen holdout estimate and patient-cluster interval |
|---|---|
| ROC-AUC | {interval("roc_auc")} |
| Average precision | {interval("average_precision")} |
| Recall | {interval("recall")} |
| Precision | {interval("precision")} |
| Brier | {interval("brier")} |

Selected model: `{train["selected_model"]}`; calibration: `{cal["chosen_method"]}`; frozen training threshold: {meta["threshold"]:.6f}. False positives: {m["confusion_matrix"][0][1]:,}; false negatives: {m["confusion_matrix"][1][0]:,}. These research results do not establish clinical utility or deployment safety.

Read [the technical report](reports/final_report.md), [the themed HTML report](reports/final_report.html), [EDA](reports/eda_report.md), [fairness](reports/fairness_report.md), and [decisions](docs/DECISIONS.md). The dashboard is at [localhost:8501](http://127.0.0.1:8501) while `make dashboard` runs.

## Notebook order
After `make all`, read `01_understanding`, `02_exploration`, `03_preprocessing`, `04_validation`, `05_modeling`, `06_evaluation`, `07_explainability_fairness`. They call `src.notebook_support` and display saved aggregates; none contains unique modeling logic. Install `requirements-dev.txt` to run `pytest --nbmake notebooks -o addopts=''`.

## Reproducibility notes
Use `requirements-lock.txt` for the exact tested environment; `requirements.txt` gives compatible ranges. A first full run takes longer than opening the artifact-only dashboard. `make train` includes nested calibration and pre-test freezing. Repeated `make evaluate` reuses the saved result; explicitly retrain to begin a new experiment. Clean-copy verification evidence and any unverified scope are in `STATUS.md`.
"""
    readme = ROOT / "README.md"
    readme.write_text(readme.read_text().split("<!-- GENERATED RESULTS -->")[0].rstrip() + "\n\n" + summary)
    save_json(
        "reports/metrics/publication.json",
        {
            "generated_utc": now(),
            "versions": versions(),
            "model_sha256": meta["model_sha256"],
            "source_artifacts": [
                "test.json",
                "training.json",
                "calibration.json",
                "explanations.json",
                "fairness.json",
            ],
            "report_words": len(markdown.split()),
        },
    )
    log(
        "Stage 12 — publication generated",
        "README results and technical Markdown/HTML reports generated from saved artifacts. Source references verified. Full clean-source/new-environment walkthrough follows; no completed clean-clone claim yet.",
    )


if __name__ == "__main__":
    main()
