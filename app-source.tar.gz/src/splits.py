import numpy as np
from sklearn.model_selection import StratifiedGroupKFold
from src.config import CONFIG


def grouped_folds(y, groups, n_splits=None):
    cv = StratifiedGroupKFold(n_splits=n_splits or CONFIG["cv_folds"], shuffle=True, random_state=CONFIG["seed"])
    folds = list(cv.split(np.zeros(len(y)), y, groups))
    for a, b in folds:
        assert not set(np.asarray(groups)[a]) & set(np.asarray(groups)[b])
    return folds


def outer_split(df, y):
    train, test = grouped_folds(y, df.patient_nbr, CONFIG["test_folds"])[0]
    assert not set(df.iloc[train].patient_nbr) & set(df.iloc[test].patient_nbr)
    return train, test


def feature_matrix(df):
    X = df.drop(columns=["encounter_id", "patient_nbr", "readmitted"], errors="ignore")
    assert not {"encounter_id", "patient_nbr", "readmitted"} & set(X)
    return X
