"""Medical Archive palette, accessible chart conventions and offline typography."""

import numpy as np

INK = "#202321"
PAPER = "#F2EBDD"
AGED_PAPER = "#E3D8C3"
OXIDE = "#963F43"
FOREST = "#34594B"
OCHRE = "#C59A52"
SLATE = "#747A75"
RULE = "#C9C2B4"
SEQUENTIAL = [PAPER, OCHRE, OXIDE]
DIVERGING = [FOREST, PAPER, OXIDE]


def rgb(color):
    return np.array([int(color[i : i + 2], 16) / 255 for i in (1, 3, 5)])


def contrast(a, b):
    def luminance(c):
        c = rgb(c)
        c = np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
        return c @ [0.2126, 0.7152, 0.0722]

    x, y = sorted([luminance(a), luminance(b)])
    return (y + 0.05) / (x + 0.05)


def tint(color, fraction=0.7):
    c = rgb(color) * (1 - fraction) + rgb(PAPER) * fraction
    return "#" + "".join(f"{round(v * 255):02x}" for v in c)


def apply_mpl_style():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "figure.facecolor": PAPER,
            "axes.facecolor": PAPER,
            "savefig.facecolor": PAPER,
            "text.color": INK,
            "axes.labelcolor": INK,
            "xtick.color": INK,
            "ytick.color": INK,
            "axes.edgecolor": RULE,
            "grid.color": RULE,
            "grid.linewidth": 0.5,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "font.family": "serif",
            "font.serif": ["Georgia", "DejaVu Serif"],
            "figure.figsize": (9, 5),
            "savefig.dpi": 220,
            "axes.titlelocation": "left",
            "axes.titlepad": 16,
        }
    )


def register_plotly():
    import plotly.graph_objects as go
    import plotly.io as pio

    pio.templates["medical_archive"] = go.layout.Template(
        layout={
            "paper_bgcolor": PAPER,
            "plot_bgcolor": PAPER,
            "font": {"family": "Georgia, serif", "color": INK},
            "colorway": [INK],
            "xaxis": {"gridcolor": RULE, "zerolinecolor": RULE},
            "yaxis": {"gridcolor": RULE, "zerolinecolor": RULE},
            "margin": {"t": 55, "b": 45, "l": 45, "r": 25},
        }
    )
    pio.templates.default = "medical_archive"


def streamlit_css():
    return f"""<style>
    .stApp {{background:{PAPER}; color:{INK};}}
    h1,h2,h3 {{font-family:Georgia,'Times New Roman',serif; font-weight:400;}}
    h1 {{font-size:3.6rem; line-height:1.08; letter-spacing:-.04em;}}
    [data-testid=stSidebar] {{background:{AGED_PAPER}; border-right:1px solid {RULE};}}
    [data-testid=stMetric] {{border-top:1px solid {RULE}; padding:18px 0;}}
    [data-testid=stMetricValue] {{font-family:Georgia,serif; color:{INK};}}
    [data-testid=stMetricLabel] {{font-family:monospace; text-transform:uppercase; letter-spacing:.08em;}}
    .archive-label {{font:12px monospace; letter-spacing:.12em; text-transform:uppercase; color:{INK};}}
    .archive-rule {{border-top:1px solid {RULE}; margin:24px 0;}}
    .archive-note {{border-left:3px solid {OCHRE}; padding:14px 20px; background:{AGED_PAPER};}}
    [data-testid=stMetricLabel] p {{font-size:10px; white-space:normal;}}
    [data-testid=stCaptionContainer] {{color:{INK};}}
    .stDataFrame {{font-family:monospace;}}
    [data-testid=stMainBlockContainer] {{max-width:1200px; padding-top:3rem;}}
    button {{border-radius:2px!important;}}
    </style>"""


def save_figure(fig, name):
    from src.config import ROOT

    (ROOT / "reports/figures").mkdir(parents=True, exist_ok=True)
    fig.savefig(ROOT / "reports/figures" / name, facecolor=PAPER, bbox_inches="tight", dpi=220)


# Full-severity linear RGB approximations from Machado et al. (2009).
CVD = {
    "deuteranopia": np.array(
        [[0.367322, 0.860646, -0.227968], [0.280085, 0.672501, 0.047413], [-0.01182, 0.04294, 0.968881]]
    ),
    "protanopia": np.array(
        [[0.152286, 1.052583, -0.204868], [0.114503, 0.786281, 0.099216], [-0.003882, -0.048116, 1.051998]]
    ),
}


def simulate_cvd(image, kind):
    a = np.asarray(image).astype(float) / 255
    c = a[..., :3]
    linear = np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
    transformed = np.clip(linear @ CVD[kind].T, 0, 1)
    corrected = np.where(transformed <= 0.0031308, transformed * 12.92, 1.055 * transformed ** (1 / 2.4) - 0.055)
    return np.uint8(np.clip(corrected, 0, 1) * 255)
