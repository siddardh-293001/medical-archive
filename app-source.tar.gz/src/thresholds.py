import numpy as np
import pandas as pd
from src.config import CONFIG


def threshold_table(y, p):
    y = np.asarray(y)
    p = np.asarray(p)
    rows = []
    for t in np.unique(np.r_[0, np.quantile(p, np.linspace(0, 1, 301)), 0.5, 1]):
        pred = p >= t
        tp = int((pred & (y == 1)).sum())
        fp = int((pred & (y == 0)).sum())
        fn = int((~pred & (y == 1)).sum())
        precision = tp / (tp + fp) if tp + fp else 0
        recall = tp / (tp + fn) if tp + fn else 0
        rows.append(
            {
                "threshold": float(t),
                "precision": precision,
                "recall": recall,
                "f1": 2 * precision * recall / (precision + recall) if precision + recall else 0,
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "selection_rate": float(pred.mean()),
            }
        )
    return pd.DataFrame(rows)


def strategies(table):
    f1 = table.sort_values(["f1", "threshold"], ascending=[False, False]).iloc[0].to_dict()
    feasible = table[(table.recall >= CONFIG["recall_target"]) & (table.precision >= CONFIG["minimum_precision"])]
    constrained = feasible.sort_values("precision", ascending=False).iloc[0].to_dict() if len(feasible) else None
    costs = []
    for ratio in CONFIG["cost_ratios"]:
        cost = table.fp + ratio * table.fn
        row = table.loc[cost.idxmin()].to_dict()
        row.update(false_negative_cost_ratio=ratio, total_hypothetical_cost=float(cost.min()))
        costs.append(row)
    return {
        "maximum_f1": f1,
        "recall_constrained": constrained,
        "hypothetical_costs": costs,
        "notice": "Hypothetical research rules; no threshold is clinically optimal.",
    }
