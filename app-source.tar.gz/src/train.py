"""Training-only comparison; test outcomes are not evaluated here."""

import time
import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits
from src.config import ROOT, CONFIG
from src.data_loader import read_mappings
from src.quality import load_cohort
from src.validation import target
from src.splits import outer_split, grouped_folds, feature_matrix
from src.preprocessing import pipeline
from src.metrics import metrics
from src.tune import tune
from src.utils import save_json, versions, log, now


def candidates(mappings):
    seed = CONFIG["seed"]
    return {
        "dummy": (pipeline(DummyClassifier(strategy="prior"), mappings, utilization_only=True), {}),
        "prior_utilization": (
            pipeline(LogisticRegression(max_iter=600, random_state=seed), mappings, scale=True, utilization_only=True),
            {"model__C": [0.1, 1, 10]},
        ),
        "logistic": (
            pipeline(LogisticRegression(max_iter=600, random_state=seed), mappings, scale=True),
            {"model__C": [0.1, 1, 10]},
        ),
        "logistic_balanced": (
            pipeline(
                LogisticRegression(max_iter=600, random_state=seed, class_weight="balanced"), mappings, scale=True
            ),
            {"model__C": [0.1, 1, 10]},
        ),
        "random_forest": (
            pipeline(
                RandomForestClassifier(n_estimators=80, max_depth=10, min_samples_leaf=30, n_jobs=2, random_state=seed),
                mappings,
            ),
            {"model__max_depth": [8, 12], "model__min_samples_leaf": [20, 50]},
        ),
        "hist_gradient_boosting": (
            pipeline(
                HistGradientBoostingClassifier(
                    max_iter=100, max_leaf_nodes=15, min_samples_leaf=40, early_stopping=False, random_state=seed
                ),
                mappings,
            ),
            {"model__learning_rate": [0.05, 0.1], "model__l2_regularization": [1.0, 10.0]},
        ),
        "drop_payer_specialty": (
            pipeline(
                LogisticRegression(max_iter=600, random_state=seed),
                mappings,
                scale=True,
                drop_columns=("payer_code", "medical_specialty"),
            ),
            {"model__C": [0.1, 1, 10]},
        ),
    }


def oof_predict(estimator, X, y, folds):
    out = np.zeros(len(X))
    rows = []
    for fold, (a, b) in enumerate(folds):
        fitted = clone(estimator)
        start = time.perf_counter()
        fitted.fit(X.iloc[a], y.iloc[a])
        fit_s = time.perf_counter() - start
        start = time.perf_counter()
        p = fitted.predict_proba(X.iloc[b])[:, 1]
        inference_s = time.perf_counter() - start
        out[b] = p
        m = metrics(y.iloc[b], p)
        m.update(
            fold=fold,
            fit_seconds=fit_s,
            inference_seconds=inference_s,
            train_ap=metrics(y.iloc[a], fitted.predict_proba(X.iloc[a])[:, 1])["average_precision"],
        )
        rows.append(m)
    return out, rows


def main():
    for folder in ["data/processed", "reports/metrics", "reports/tables", "models"]:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    d = load_cohort()
    y = target(d)
    train, test = outer_split(d, y)
    np.savez(ROOT / "data/processed/split.npz", train=train, test=test)
    X = feature_matrix(d.iloc[train]).reset_index(drop=True)
    yt = y.iloc[train].reset_index(drop=True)
    groups = d.iloc[train].patient_nbr.to_numpy()
    folds = grouped_folds(yt, groups)
    mappings = read_mappings(ROOT / "data/raw/IDS_mapping.csv")
    rows = []
    detail = {}
    fitted_models = {}
    oof = {}
    # Explicit retraining invalidates the downstream evaluation and publication artifacts.
    for name in ["test.json", "fairness.json", "explanations.json"]:
        (ROOT / "reports/metrics" / name).unlink(missing_ok=True)
    for name, (estimator, space) in candidates(mappings).items():
        print(f"Training {name}", flush=True)
        start = time.perf_counter()
        best, params, trials = tune(estimator, space, X, yt, folds)
        p, fold_metrics = oof_predict(best, X, yt, folds)
        summary = metrics(yt, p)
        summary.pop("confusion_matrix")
        summary.update(
            model=name,
            total_seconds=time.perf_counter() - start,
            fold_ap_sd=np.std([m["average_precision"] for m in fold_metrics]),
            mean_train_ap=np.mean([m["train_ap"] for m in fold_metrics]),
            fit_seconds=sum(m["fit_seconds"] for m in fold_metrics),
            inference_seconds=sum(m["inference_seconds"] for m in fold_metrics),
        )
        rows.append(summary)
        detail[name] = {"search_space": space, "best_params": params, "trials": trials, "folds": fold_metrics}
        best.fit(X, yt)
        fitted_models[name] = best
        oof[name] = p
        if name in ["logistic", "hist_gradient_boosting"]:
            joblib.dump(best, ROOT / f"models/{name}.joblib")
        print(f"  OOF AP={summary['average_precision']:.4f}; Brier={summary['brier']:.4f}", flush=True)
    comparison = pd.DataFrame(rows)
    comparison.to_csv(ROOT / "reports/model_comparison.csv", index=False)
    best_ap = comparison.average_precision.max()
    finalists = comparison[(comparison.average_precision >= best_ap - 0.005) & (comparison.model != "dummy")]
    chosen = finalists.sort_values(["brier", "model"]).iloc[0].model
    joblib.dump(fitted_models[chosen], ROOT / "models/base.joblib")
    # Local private OOF arrays; never committed or used directly by the dashboard.
    np.savez(ROOT / "data/processed/training_oof.npz", y=yt.to_numpy(), groups=groups, **oof)
    save_json(
        "reports/metrics/training.json",
        {
            "created_utc": now(),
            "selected_model": chosen,
            "training_rows": len(X),
            "training_patients": len(set(groups)),
            "train_prevalence": float(yt.mean()),
            "config": CONFIG,
            "versions": versions(),
            "models": detail,
            "selection_rule": "Within 0.005 of best AP, choose lowest Brier; compare burden and stability in model_comparison.csv",
            "caveat": "Hyperparameter search and OOF model comparison reuse grouped training folds; selection estimates are optimistic. Only the untouched holdout is final.",
        },
    )
    with (ROOT / "docs/DECISIONS.md").open("a") as f:
        f.write(
            f"\n- Executed model selection: {chosen}; see generated model_comparison.csv for AP, Brier, stability and burden. Numeric results are not hand-transcribed.\n"
        )
    log(
        "Stage 5 — PASS",
        f"All required models, balanced logistic and payer/specialty-drop comparison completed on grouped training OOF predictions. Selected {chosen}. Search spaces, parameters, train/validation gaps and times saved. Test outcomes not evaluated. Hyperparameter-selection optimism is documented.",
    )


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
