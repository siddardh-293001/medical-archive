from sklearn.model_selection import RandomizedSearchCV
from src.config import CONFIG


def tune(estimator, space, X, y, folds):
    if not space:
        return estimator, {}, []
    search = RandomizedSearchCV(
        estimator,
        space,
        n_iter=CONFIG["tuning_iterations"],
        scoring="average_precision",
        cv=folds,
        random_state=CONFIG["seed"],
        n_jobs=1,
        return_train_score=True,
        error_score="raise",
    )
    search.fit(X, y)
    cv = search.cv_results_
    trials = [
        {"params": p, "train_ap": float(a), "validation_ap": float(b), "validation_sd": float(s)}
        for p, a, b, s in zip(cv["params"], cv["mean_train_score"], cv["mean_test_score"], cv["std_test_score"])
    ]
    return search.best_estimator_, search.best_params_, trials
