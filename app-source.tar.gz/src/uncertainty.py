"""Patient-cluster percentile bootstrap; all encounters in sampled patients are retained."""

import numpy as np
from src.config import CONFIG
from src.metrics import metrics

BOOT_METRICS = [
    "roc_auc",
    "average_precision",
    "recall",
    "precision",
    "brier",
    "specificity",
    "fpr",
    "fnr",
    "selection_rate",
    "prevalence",
    "calibration_in_large",
]


def cluster_bootstrap(y, p, groups, threshold, n_boot=None, seed=None):
    y = np.asarray(y)
    p = np.asarray(p)
    groups = np.asarray(groups)
    n_boot = n_boot or CONFIG["bootstrap_replicates"]
    seed = CONFIG["seed"] if seed is None else seed
    rng = np.random.default_rng(seed)
    _, inverse = np.unique(groups, return_inverse=True)
    order = np.argsort(inverse, kind="stable")
    locations = np.split(order, np.cumsum(np.bincount(inverse))[:-1])
    values = {k: [] for k in BOOT_METRICS}
    valid = 0
    for _ in range(n_boot):
        sample = np.concatenate([locations[i] for i in rng.integers(0, len(locations), len(locations))])
        if len(np.unique(y[sample])) < 2:
            continue
        m = metrics(y[sample], p[sample], threshold)
        valid += 1
        for k in values:
            if m[k] is not None:
                values[k].append(m[k])
    intervals = {
        k: {"low": float(np.quantile(v, 0.025)), "high": float(np.quantile(v, 0.975))} if v else None
        for k, v in values.items()
    }
    return {
        "method": "patient-cluster percentile bootstrap",
        "requested_replicates": n_boot,
        "valid_replicates": valid,
        "seed": seed,
        "intervals": intervals,
    }
