import hashlib
import importlib.metadata
import json
from datetime import datetime, timezone
from pathlib import Path
import platform
import numpy as np
from src.config import ROOT


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def versions():
    names = ["numpy", "pandas", "scipy", "scikit-learn", "shap", "fairlearn", "streamlit"]
    return {"python": platform.python_version(), **{n: importlib.metadata.version(n) for n in names}}


def now():
    return datetime.now(timezone.utc).isoformat()


def save_json(path, obj):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)

    def convert(x):
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, np.generic):
            return x.item()
        return str(x)

    p.write_text(json.dumps(obj, indent=2, default=convert, allow_nan=False))


def log(stage, message):
    with (ROOT / "STATUS.md").open("a") as f:
        f.write(f"\n## {stage} — {now()}\n{message}\n")
