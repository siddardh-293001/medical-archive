import warnings
import pandas as pd

MEDICATIONS = "metformin repaglinide nateglinide chlorpropamide glimepiride acetohexamide glipizide glyburide tolbutamide pioglitazone rosiglitazone acarbose miglitol troglitazone tolazamide examide citoglipton insulin glyburide-metformin glipizide-metformin glimepiride-pioglitazone metformin-rosiglitazone metformin-pioglitazone".split()
REQUIRED = (
    "encounter_id patient_nbr race gender age admission_type_id discharge_disposition_id admission_source_id time_in_hospital num_lab_procedures num_procedures num_medications number_outpatient number_emergency number_inpatient diag_1 diag_2 diag_3 number_diagnoses max_glu_serum A1Cresult change diabetesMed readmitted".split()
    + MEDICATIONS
)


def validate(df, expected=True):
    missing = set(REQUIRED) - set(df)
    if missing:
        raise ValueError(f"Required columns missing: {sorted(missing)}")
    if df.empty or df["patient_nbr"].isna().any():
        raise ValueError("Empty data or missing patient IDs")
    if not df.readmitted.isin(["<30", ">30", "NO"]).all():
        raise ValueError("Invalid readmission labels")
    duplicates = int(df.encounter_id.duplicated().sum())
    if duplicates or df.encounter_id.isna().any():
        raise ValueError(f"Duplicate encounters: {duplicates}; missing IDs are also prohibited")
    if expected:
        for name, actual, reference in [
            ("rows", len(df), 101766),
            ("columns", len(df.columns), 50),
            ("patients", df.patient_nbr.nunique(), 71500),
        ]:
            if abs(actual - reference) / reference > 0.05:
                warnings.warn(f"Unexpected {name}: {actual}; reference about {reference}", stacklevel=2)
    return df


def read_data(path, expected=True):
    # Keep literal 'None': it means not tested for A1C / glucose, not missing.
    return validate(
        pd.read_csv(path, na_values=["?"], keep_default_na=False, low_memory=False).replace("", float("nan")), expected
    )


def target(df):
    if not df.readmitted.isin(["<30", ">30", "NO"]).all():
        raise ValueError("Invalid target")
    return (df.readmitted == "<30").astype(int)
