import pandas as pd
import pytest
from src.validation import REQUIRED, MEDICATIONS


@pytest.fixture
def tiny():
    rows = []
    for i in range(30):
        row = dict.fromkeys(REQUIRED, "No")
        row.update(dict.fromkeys(MEDICATIONS, "No"))
        row.update(
            encounter_id=i,
            patient_nbr=i // 2,
            race="Unknown",
            gender="Female",
            age="[50-60)",
            admission_type_id=1,
            admission_source_id=1,
            discharge_disposition_id=1,
            time_in_hospital=i % 14 + 1,
            num_lab_procedures=20,
            num_procedures=1,
            num_medications=4,
            number_outpatient=0,
            number_emergency=0,
            number_inpatient=i % 3,
            diag_1="250.2",
            diag_2="V10",
            diag_3="E999",
            number_diagnoses=3,
            max_glu_serum="None",
            A1Cresult="None",
            change="No",
            diabetesMed="Yes",
            readmitted=["NO", ">30", "<30"][i % 3],
        )
        rows.append(row)
    return pd.DataFrame(rows)


@pytest.fixture
def mapping_text():
    return "admission_type_id,description\n1,Emergency\n\ndischarge_disposition_id,description\n1,Home\n11,Expired\n13,Hospice / home\n\nadmission_source_id,description\n1,Referral\n"
