# Offline fixtures
`tests/conftest.py` constructs a tiny synthetic schema fixture and ZIP payloads in memory.
These are only unit-test inputs. They are never used for research, plots, training or dashboard results.
The optional network test uses a separate temporary directory and the real official dataset.
