import numpy as np
import pytest
from src.calibrate import ProbabilityCalibrator
from src.thresholds import threshold_table, strategies


@pytest.mark.parametrize("method", ["uncalibrated", "sigmoid", "isotonic"])
def test_calibration_bounds_and_reproducibility(method):
    p = np.array([0.01, 0.2, 0.3, 0.5, 0.8, 0.99])
    y = np.array([0, 0, 1, 0, 1, 1])
    a = ProbabilityCalibrator(method).fit(p, y).predict(p)
    b = ProbabilityCalibrator(method).fit(p, y).predict(p)
    np.testing.assert_array_equal(a, b)
    assert np.all((a >= 0) & (a <= 1))


def test_thresholds_training_rules():
    table = threshold_table([0, 0, 1, 1], [0.1, 0.2, 0.8, 0.9])
    rules = strategies(table)
    assert rules["maximum_f1"]["f1"] == 1
    assert rules["maximum_f1"]["fp"] == 0
    assert len(rules["hypothetical_costs"]) > 1


def test_saved_wrapper_loads_in_fresh_process(tiny, tmp_path):
    import joblib
    import subprocess
    import sys
    from sklearn.linear_model import LogisticRegression
    from src.preprocessing import pipeline
    from src.splits import feature_matrix
    from src.validation import target
    from src.calibrate import CalibratedPipeline

    X = feature_matrix(tiny)
    y = target(tiny)
    base = pipeline(LogisticRegression(max_iter=500), {}, scale=True, utilization_only=True).fit(X, y)
    wrapper = CalibratedPipeline(base, ProbabilityCalibrator().fit(base.predict_proba(X)[:, 1], y), 0.2)
    path = tmp_path / "model.joblib"
    joblib.dump(wrapper, path)
    subprocess.run(
        [
            sys.executable,
            "-c",
            "import joblib,sys; m=joblib.load(sys.argv[1]); assert type(m).__module__=='src.calibrate'",
            str(path),
        ],
        check=True,
    )


def test_frozen_wrapper_supports_sklearn_inspection(tiny):
    from sklearn.linear_model import LogisticRegression
    from sklearn.inspection import permutation_importance
    from src.preprocessing import pipeline
    from src.splits import feature_matrix
    from src.validation import target
    from src.calibrate import CalibratedPipeline

    X = feature_matrix(tiny)
    y = target(tiny)
    base = pipeline(LogisticRegression(max_iter=500), {}, scale=True, utilization_only=True).fit(X, y)
    wrapper = CalibratedPipeline(base, ProbabilityCalibrator().fit(base.predict_proba(X)[:, 1], y), 0.2)
    result = permutation_importance(wrapper, X, y, scoring="average_precision", n_repeats=1, random_state=42)
    assert result.importances_mean.shape == (len(X.columns),)
    with pytest.raises(RuntimeError, match="Frozen"):
        wrapper.fit(X, y)
