import streamlit as st
import pytest
from streamlit.testing.v1 import AppTest
from dashboard import artifacts
from src.config import ROOT

PAGES = [ROOT / "dashboard/app.py", *sorted((ROOT / "dashboard/pages").glob("*.py"))]


@pytest.mark.parametrize("page", PAGES, ids=lambda p: p.stem)
def test_pages_real_artifacts(page):
    if not (ROOT / "reports/metrics/test.json").exists():
        pytest.skip("Real aggregate artifacts unavailable; missing-artifact behavior tested separately")
    app = AppTest.from_file(str(page), default_timeout=30).run()
    assert not app.exception, [e.message for e in app.exception]


@pytest.mark.parametrize("page", PAGES, ids=lambda p: p.stem)
def test_pages_missing_artifacts(page, tmp_path, monkeypatch):
    monkeypatch.setattr(artifacts, "ARTIFACT_ROOT", tmp_path)
    st.cache_data.clear()
    app = AppTest.from_file(str(page), default_timeout=30).run()
    assert not app.exception, [e.message for e in app.exception]
    if page.stem != "05_Limitations":
        assert app.info
    st.cache_data.clear()


def test_artifact_loader_does_not_require_raw(tmp_path):
    assert artifacts.read_json("reports/metrics/test.json", root=tmp_path) is None
    assert artifacts.read_table("reports/model_comparison.csv", root=tmp_path) is None
    assert artifacts.figure_path("missing.png", root=tmp_path) is None
