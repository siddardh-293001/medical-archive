import io
import zipfile
from unittest.mock import patch, MagicMock
import pandas as pd
import pytest
from src import data_loader as dl
from src.validation import read_data, target, validate


def archive(tiny, mapping_text, missing=False):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w") as z:
        z.writestr("nested/diabetic_data.csv", tiny.to_csv(index=False))
        if not missing:
            z.writestr("../IDS_mapping.csv", mapping_text)
    return stream.getvalue()


def response(body):
    r = MagicMock()
    r.__enter__.return_value = r
    r.iter_content.return_value = [body]
    return r


def test_download_cache(tiny, mapping_text, tmp_path):
    with patch.object(dl.requests, "get", return_value=response(archive(tiny, mapping_text))) as get:
        path = dl.ensure_dataset(tmp_path)
        assert len(read_data(path, expected=False)) == 30
        dl.ensure_dataset(tmp_path)
        assert get.call_count == 1
        path.write_text("tampered")
        with pytest.raises(dl.DatasetDownloadError, match="integrity"):
            dl.ensure_dataset(tmp_path)


def test_retry(tiny, mapping_text, tmp_path):
    import requests

    with (
        patch.object(
            dl.requests, "get", side_effect=[requests.ConnectionError(), response(archive(tiny, mapping_text))]
        ) as get,
        patch.object(dl.time, "sleep"),
    ):
        dl.download(tmp_path)
        assert get.call_count == 2
        assert not (tmp_path / "dataset.zip.part").exists()


@pytest.mark.parametrize("body", [b"bad zip", None])
def test_invalid_zip(tiny, mapping_text, tmp_path, body):
    stream = io.BytesIO(body if body else archive(tiny, mapping_text, missing=True))
    with pytest.raises((ValueError, zipfile.BadZipFile)):
        dl.extract(stream, tmp_path)
    assert not (tmp_path / "diabetic_data.csv").exists()


def test_manual(tiny, mapping_text, tmp_path):
    tiny.to_csv(tmp_path / "diabetic_data.csv", index=False)
    (tmp_path / "IDS_mapping.csv").write_text(mapping_text)
    with patch.object(dl.requests, "get", side_effect=AssertionError("network")):
        assert dl.ensure_dataset(tmp_path).exists()


def test_failure_instructions(tmp_path):
    with (
        patch.object(dl, "download", side_effect=RuntimeError("offline")),
        patch.object(dl, "fallback", side_effect=RuntimeError("offline")),
    ):
        with pytest.raises(dl.DatasetDownloadError, match="browser"):
            dl.ensure_dataset(tmp_path)


def test_schema_and_target(tiny, tmp_path):
    assert target(tiny).tolist()[:3] == [0, 0, 1]
    with pytest.raises(ValueError):
        validate(tiny.drop(columns="patient_nbr"), expected=False)
    duplicate = pd.concat([tiny, tiny.iloc[:1]])
    with pytest.raises(ValueError, match="Duplicate"):
        validate(duplicate, expected=False)
    tiny.loc[0, "race"] = "?"
    tiny.to_csv(tmp_path / "data.csv", index=False)
    loaded = read_data(tmp_path / "data.csv", expected=False)
    assert pd.isna(loaded.loc[0, "race"])
    assert loaded.loc[0, "A1Cresult"] == "None"


@pytest.mark.network
def test_real_download(tmp_path):
    assert dl.ensure_dataset(tmp_path, force=True).exists()


def test_corrupt_member_crc(tiny, mapping_text, tmp_path):
    body = bytearray(archive(tiny, mapping_text))
    start = body.index(b"encounter_id")
    body[start] = ord("X")
    with pytest.raises(ValueError, match="Corrupt"):
        dl.extract(io.BytesIO(body), tmp_path)


def test_fallback_route_is_validated(tiny, mapping_text, tmp_path):
    def fake_fallback(raw):
        tiny.to_csv(raw / "diabetic_data.csv", index=False)
        (raw / "IDS_mapping.csv").write_text(mapping_text)

    with (
        patch.object(dl, "download", side_effect=RuntimeError("primary unavailable")),
        patch.object(dl, "fallback", side_effect=fake_fallback),
    ):
        assert dl.ensure_dataset(tmp_path).exists()
        assert "ucimlrepo" in (tmp_path / "MANIFEST.json").read_text()


def test_ucimlrepo_recombination_and_none_codes(tiny, mapping_text, tmp_path):
    from types import SimpleNamespace

    api = tiny.copy()
    api["max_glu_serum"] = float("nan")
    api["A1Cresult"] = float("nan")
    result = SimpleNamespace(
        data=SimpleNamespace(
            ids=api[["encounter_id", "patient_nbr"]],
            targets=api[["readmitted"]],
            features=api.drop(columns=["encounter_id", "patient_nbr", "readmitted"]),
        )
    )

    def legacy(stage, source_url):
        assert source_url == dl.LEGACY_SOURCE_URL
        tiny.to_csv(stage / "diabetic_data.csv", index=False)
        (stage / "IDS_mapping.csv").write_text(mapping_text)

    with patch("ucimlrepo.fetch_ucirepo", return_value=result), patch.object(dl, "download", side_effect=legacy):
        dl.fallback(tmp_path)
    data = read_data(tmp_path / "diabetic_data.csv", expected=False)
    assert data.A1Cresult.eq("None").all()
    assert data.max_glu_serum.eq("None").all()
    assert data.patient_nbr.tolist() == tiny.patient_nbr.tolist()


def test_three_retries_and_backoff(tmp_path):
    import requests

    with (
        patch.object(dl.requests, "get", side_effect=requests.ConnectionError("offline")) as get,
        patch.object(dl.time, "sleep") as sleep,
    ):
        with pytest.raises(requests.ConnectionError):
            dl.download(tmp_path)
        assert get.call_count == 4
        assert [call.args[0] for call in sleep.call_args_list] == [1, 2, 4]
    assert not (tmp_path / "dataset.zip.part").exists()


def test_malformed_manifest_has_force_guidance(tiny, mapping_text, tmp_path):
    tiny.to_csv(tmp_path / "diabetic_data.csv", index=False)
    (tmp_path / "IDS_mapping.csv").write_text(mapping_text)
    (tmp_path / "MANIFEST.json").write_text("{broken json")
    with patch.object(dl.requests, "get", side_effect=AssertionError("network")):
        with pytest.raises(dl.DatasetDownloadError, match="--force"):
            dl.ensure_dataset(tmp_path)


def test_verified_legacy_member_case(tiny, mapping_text, tmp_path):
    body = io.BytesIO()
    with zipfile.ZipFile(body, "w") as z:
        z.writestr("dataset_diabetes/diabetic_data.csv", tiny.to_csv(index=False))
        z.writestr("dataset_diabetes/IDs_mapping.csv", mapping_text)
    with pytest.raises(ValueError, match="members missing"):
        dl.extract(io.BytesIO(body.getvalue()), tmp_path)
    dl.extract(io.BytesIO(body.getvalue()), tmp_path, legacy=True)
    assert (tmp_path / "IDS_mapping.csv").exists()
