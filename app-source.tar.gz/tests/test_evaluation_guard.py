import json
from src import evaluate


def test_evaluation_reuses_existing_result(tmp_path, monkeypatch):
    folder = tmp_path / "reports/metrics"
    folder.mkdir(parents=True)
    saved = {"model_sha256": "fixture_hash"}
    path = folder / "test.json"
    path.write_text(json.dumps(saved))
    monkeypatch.setattr(evaluate, "ROOT", tmp_path)
    monkeypatch.setattr(evaluate, "frozen_metadata", lambda: {"model_sha256": "fixture_hash"})

    def forbidden():
        raise AssertionError("Holdout must not be loaded again")

    monkeypatch.setattr(evaluate, "test_cohort", forbidden)
    before = path.read_bytes()
    evaluate.main()
    assert path.read_bytes() == before
