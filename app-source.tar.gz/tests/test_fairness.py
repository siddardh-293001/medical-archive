import numpy as np
from src.fairness import subgroup_table


def test_metricframe_counts_unknown_and_flags():
    table = subgroup_table(
        np.array([0, 1, 0, 1]),
        np.array([0.1, 0.8, 0.9, 0.7]),
        np.array(["Unknown", "Unknown", "A", "A"]),
        np.array([1, 1, 2, 2]),
        0.5,
        bootstrap=False,
    )
    assert set(table.group) == {"Unknown", "A"}
    assert table.n.sum() == 4
    assert table.positive_count.sum() == 2
    assert table.small_group.all()
    a = table.set_index("group").loc["A"]
    assert a.fpr == 1
    assert a.recall == 1
    assert a.precision == 0.5
