import json
import joblib
import pytest
import pandas as pd
from sklearn.dummy import DummyClassifier
from src.inference import load_model, predict_encounter, validate_record
from src.utils import sha256


@pytest.fixture
def model_dir(tmp_path):
    frame = pd.DataFrame({"time_in_hospital": [1, 2]})
    model = DummyClassifier(strategy="prior").fit(frame, [0, 1])
    path = tmp_path / "pipeline.joblib"
    joblib.dump(model, path)
    meta = {
        "model_sha256": sha256(path),
        "threshold": 0.4,
        "model_version": "unit-test",
        "feature_schema": {
            "time_in_hospital": {"type": "integer", "minimum": 1, "maximum": 14, "missing_allowed": False}
        },
    }
    (tmp_path / "metadata.json").write_text(json.dumps(meta))
    return tmp_path


def test_predict_and_hash(model_dir):
    result = predict_encounter({"time_in_hospital": 2}, model_dir=model_dir)
    assert result["probability"] == 0.5 and result["class"] == 1
    assert "not for clinical use" in result["notice"]
    (model_dir / "pipeline.joblib").write_bytes(b"tampered")
    with pytest.raises(ValueError, match="SHA-256"):
        load_model(model_dir)


@pytest.mark.parametrize("value", ["2", 1.2, -1, 15, None, True, float("nan")])
def test_invalid_types_ranges(model_dir, value):
    with pytest.raises(ValueError):
        predict_encounter({"time_in_hospital": value}, model_dir=model_dir)


def test_missing_and_extra(model_dir):
    for record in [{}, {"time_in_hospital": 2, "patient_nbr": 123}]:
        with pytest.raises(ValueError, match="Missing fields"):
            predict_encounter(record, model_dir=model_dir)


def test_unseen_category_is_clear():
    schema = {"race": {"type": "category", "values": ["Unknown", "Other"], "missing_allowed": True}}
    with pytest.raises(ValueError, match="unseen category"):
        validate_record({"race": "unseen"}, schema)
    assert pd.isna(validate_record({"race": None}, schema).iloc[0, 0])


def test_unseen_administrative_code():
    schema = {
        "admission_type_id": {
            "type": "integer",
            "minimum": 1,
            "maximum": 8,
            "allowed_values": [1, 2, 3, 8],
            "missing_allowed": False,
        }
    }
    with pytest.raises(ValueError, match="unseen administrative code"):
        validate_record({"admission_type_id": 5}, schema)
