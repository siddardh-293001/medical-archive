import numpy as np
from src.metrics import metrics


def test_threshold_classification_and_probability_metrics():
    y = np.array([0, 0, 1, 1])
    p = np.array([0.1, 0.4, 0.4, 0.9])
    result = metrics(y, p, 0.4)
    assert result["confusion_matrix"] == [[1, 1], [0, 2]]
    assert result["recall"] == 1
    assert result["specificity"] == 0.5
    assert result["precision"] == 2 / 3
    assert 0 <= result["brier"] <= 1


def test_single_class_is_explicit():
    result = metrics([0, 0], [0.1, 0.2])
    assert result["roc_auc"] is None
    assert result["average_precision"] is None
