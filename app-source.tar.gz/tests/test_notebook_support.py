import pandas as pd
from src import notebook_support


def test_csv_view_uses_csv_parser(tmp_path, monkeypatch):
    path = tmp_path / "aggregate.csv"
    pd.DataFrame({"group": ["synthetic fixture"], "n": [2]}).to_csv(path, index=False)
    monkeypatch.setattr(notebook_support, "ROOT", tmp_path)
    monkeypatch.setattr(notebook_support, "ARTIFACTS", {"fixture": "aggregate.csv"})
    monkeypatch.setattr(notebook_support, "ensure_dataset", lambda: None)
    result = notebook_support.show_stage("fixture")
    assert isinstance(result, pd.DataFrame)
    assert result.n.sum() == 2
