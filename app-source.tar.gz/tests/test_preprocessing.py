import numpy as np
from sklearn.linear_model import LogisticRegression
from src.preprocessing import pipeline
from src.splits import grouped_folds, feature_matrix
from src.validation import target
from src.quality import eligible
from src.feature_engineering import diagnosis_group


def test_discharge_exclusions(tiny):
    tiny.loc[0, "discharge_disposition_id"] = 11
    tiny.loc[1, "discharge_disposition_id"] = 13
    kept, excluded = eligible(tiny, {"discharge_disposition_id": {1: "Home", 11: "Expired", 13: "Hospice / home"}})
    assert len(kept) == 28 and excluded.n.sum() == 2


def test_diagnoses():
    for code, want in [
        ("250.2", "Diabetes"),
        ("V10", "Supplementary V"),
        ("E999", "External E"),
        ("401", "Circulatory"),
        ("?", "Unknown"),
    ]:
        assert diagnosis_group(code) == want


def test_group_separation_determinism(tiny):
    y = target(tiny)
    first = grouped_folds(y, tiny.patient_nbr, 3)
    second = grouped_folds(y, tiny.patient_nbr, 3)
    for (a, b), (c, d) in zip(first, second):
        assert not set(tiny.iloc[a].patient_nbr) & set(tiny.iloc[b].patient_nbr)
        np.testing.assert_array_equal(a, c)
        np.testing.assert_array_equal(b, d)


def test_pipeline_train_only_unknown_and_bounds(tiny):
    X = feature_matrix(tiny)
    X["race"] = ["A", "B"] * (len(X) // 2)
    y = target(tiny)
    p = pipeline(LogisticRegression(max_iter=500), {}, scale=True)
    p.fit(X.iloc[:24], y.iloc[:24])
    test = X.iloc[24:].copy()
    test["race"] = "Never observed"
    test["time_in_hospital"] = 10000
    before = p.named_steps["preprocess"].named_transformers_["numeric"].named_steps["impute"].statistics_.copy()
    probabilities = p.predict_proba(test)
    after = p.named_steps["preprocess"].named_transformers_["numeric"].named_steps["impute"].statistics_
    np.testing.assert_array_equal(before, after)
    assert probabilities.shape == (6, 2)
    assert np.all((probabilities >= 0) & (probabilities <= 1))
    assert not {"encounter_id", "patient_nbr", "readmitted", "weight"} & set(p.named_steps["features"].columns_)
