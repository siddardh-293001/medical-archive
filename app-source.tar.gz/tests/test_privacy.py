import ast
from src.config import ROOT


def test_dashboard_has_no_raw_loader_or_training_imports():
    for path in (ROOT / "dashboard").rglob("*.py"):
        tree = ast.parse(path.read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                assert node.module not in [
                    "src.data_loader",
                    "src.train",
                    "src.quality",
                    "src.evaluate",
                    "src.inference",
                ]
        assert "data/raw" not in path.read_text()
