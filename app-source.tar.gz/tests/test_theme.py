import numpy as np
from src import theme


def test_palette_and_contrast():
    expected = dict(
        INK="#202321",
        PAPER="#F2EBDD",
        AGED_PAPER="#E3D8C3",
        OXIDE="#963F43",
        FOREST="#34594B",
        OCHRE="#C59A52",
        SLATE="#747A75",
        RULE="#C9C2B4",
    )
    for name, value in expected.items():
        assert getattr(theme, name) == value
    for color in [theme.INK, theme.OXIDE, theme.FOREST]:
        assert theme.contrast(color, theme.PAPER) >= 4.5
    assert theme.contrast(theme.OCHRE, theme.PAPER) < 4.5


def test_cvd_transforms():
    pixels = np.uint8([[theme.rgb(c) * 255 for c in [theme.PAPER, theme.OXIDE, theme.FOREST]]])
    for kind in theme.CVD:
        transformed = theme.simulate_cvd(pixels, kind)
        assert transformed.shape == pixels.shape
        assert not np.array_equal(pixels, transformed)
