import numpy as np
from sklearn.linear_model import LogisticRegression
from src.preprocessing import pipeline
from src.splits import feature_matrix, grouped_folds
from src.train import oof_predict
from src.validation import target


def test_oof_predictions_and_fold_isolation(tiny):
    X = feature_matrix(tiny)
    y = target(tiny)
    folds = grouped_folds(y, tiny.patient_nbr, 3)
    model = pipeline(LogisticRegression(random_state=42, max_iter=500), {}, scale=True, utilization_only=True)
    first, details = oof_predict(model, X, y, folds)
    second, _ = oof_predict(model, X, y, folds)
    np.testing.assert_allclose(first, second)
    assert len(details) == 3
    assert sum(m["n"] for m in details) == len(y)
    assert np.all((first >= 0) & (first <= 1))
    assert not hasattr(model.named_steps["features"], "columns_")
