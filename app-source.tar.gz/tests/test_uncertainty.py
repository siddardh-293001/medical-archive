import numpy as np
from src.uncertainty import cluster_bootstrap


def test_cluster_bootstrap_deterministic():
    y = np.array([0, 1, 0, 1, 0, 1])
    p = np.array([0.2, 0.8, 0.1, 0.9, 0.3, 0.7])
    groups = np.array([1, 1, 2, 2, 3, 3])
    a = cluster_bootstrap(y, p, groups, 0.5, n_boot=20, seed=8)
    b = cluster_bootstrap(y, p, groups, 0.5, n_boot=20, seed=8)
    assert a == b
    assert a["valid_replicates"] == 20
    assert a["intervals"]["roc_auc"] == {"low": 1.0, "high": 1.0}


def test_bootstrap_undefined_groups_are_explicit():
    a = cluster_bootstrap([0, 0], [0.1, 0.2], [1, 1], 0.5, n_boot=5)
    assert a["valid_replicates"] == 0
    assert a["intervals"]["roc_auc"] is None
